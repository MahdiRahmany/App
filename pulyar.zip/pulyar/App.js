import React, { useEffect, useState } from 'react';
import { I18nManager, AppState, Platform } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts, Vazirmatn_400Regular, Vazirmatn_700Bold, Vazirmatn_800ExtraBold } from '@expo-google-fonts/vazirmatn';
import { StoreProvider, useStore } from './src/store/Store';
import RootNav from './src/navigation/RootNav';
import LockScreen from './src/components/LockScreen';
import OnboardingScreen from './src/screens/OnboardingScreen';
import { Toast } from './src/components/ui';
import PulyarSms from './modules/expo-pulyar-sms';
import { parseBankSms } from './src/utils/smsParser';
import { uid } from './src/utils/format';

I18nManager.allowRTL(true);
I18nManager.forceRTL(true);

function Shell() {
  const { st, dispatch, msg } = useStore();
  const [unlocked, setUnlocked] = useState(!st.pin);

  // خواندن پیامک‌های رسیده از گیرنده Native (فقط اندروید، dev build)
  useEffect(() => {
    const sync = async () => {
      try {
        const pending = await PulyarSms.pending();
        (pending || []).forEach(s => {
          const r = parseBankSms(s.body);
          if (r) dispatch({
            t: 'addTx',
            tx: { id: uid(), ...r, cat: r.type === 'income' ? 'income' : 'other', d: 0, src: 'sms', intoCash: true },
          });
        });
      } catch (e) { /* Expo Go یا iOS — ماژول موجود نیست */ }
    };
    sync();
    const sub = AppState.addEventListener('change', s => { if (s === 'active') sync(); });
    return () => sub.remove();
  }, []);

  if (!st.onboarded) return <><OnboardingScreen /><Toast msg={msg} /></>;
  if (!unlocked) return <><LockScreen onUnlock={() => setUnlocked(true)} /><Toast msg={msg} /></>;
  return <><RootNav /><Toast msg={msg} /></>;
}

export default function App() {
  const [fonts] = useFonts({
    Vazirmatn_400Regular,
    Vazirmatn_700Bold,
    Vazirmatn_800ExtraBold,
  });
  if (!fonts) return null;
  return (
    <SafeAreaProvider>
      <StoreProvider>
        <Shell />
      </StoreProvider>
    </SafeAreaProvider>
  );
}
