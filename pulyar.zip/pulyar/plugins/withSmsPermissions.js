const { withAndroidManifest, createRunOncePlugin } = require('@expo/config-plugins');

const withSmsPermissions = config =>
  withAndroidManifest(config, config2 => {
    const man = config2.modResults;
    man.manifest['uses-permission'] = man.manifest['uses-permission'] || [];
    ['android.permission.RECEIVE_SMS', 'android.permission.READ_SMS'].forEach(p => {
      if (!man.manifest['uses-permission'].some(x => x.$['android:name'] === p))
        man.manifest['uses-permission'].push({ $: { 'android:name': p } });
    });
    return config2;
  });

module.exports = createRunOncePlugin(withSmsPermissions, 'withSmsPermissions', '1.0.0');
