package expo.modules.pulyarsms

import android.content.Context
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import org.json.JSONArray

class PulyarSmsModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("PulyarSms")

    // پیامک‌های صف‌شده را برمی‌گرداند و صف را خالی می‌کند
    Function("pending") {
      val ctx = appContext.reactContext ?: return@Function emptyList<Map<String, Any>>()
      val prefs = ctx.getSharedPreferences("pulyar_sms", Context.MODE_PRIVATE)
      val arr = JSONArray(prefs.getString("items", "[]"))
      val out = ArrayList<Map<String, Any>>()
      for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        out.add(mapOf("sender" to o.optString("sender"), "body" to o.optString("body")))
      }
      prefs.edit().remove("items").apply()
      out
    }
  }
}
