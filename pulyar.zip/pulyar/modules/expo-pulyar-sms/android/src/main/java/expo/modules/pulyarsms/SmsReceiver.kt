package expo.modules.pulyarsms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject

/**
 * پیامک‌های ورودی را دریافت و در SharedPreferences صف می‌کند.
 * جاوااسکریپت هنگام باز بودن اپ، با فراخوانی PulyarSms.pending() صف را می‌خواند و پاک می‌کند.
 */
class SmsReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
    val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
    val prefs = context.getSharedPreferences("pulyar_sms", Context.MODE_PRIVATE)
    val arr = JSONArray(prefs.getString("items", "[]"))
    for (m in msgs) {
      val o = JSONObject()
      o.put("sender", m.originatingAddress ?: "")
      o.put("body", m.messageBody ?: "")
      o.put("ts", m.timestampMillis)
      arr.put(o)
    }
    prefs.edit().putString("items", arr.toString()).apply()
  }
}
