import React, { createContext, useContext, useReducer, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'pulyar_v1';
const uid = () => 'x' + Math.random().toString(36).slice(2, 9);

const CATS0 = [
  { id: 'food', name: 'خوراک', icon: 'restaurant', color: '#FF6B47' },
  { id: 'transport', name: 'حمل‌ونقل', icon: 'car', color: '#5B4BC4' },
  { id: 'bills', name: 'قبض', icon: 'receipt', color: '#E8A13D' },
  { id: 'shopping', name: 'خرید', icon: 'bag-handle', color: '#2E8B8B' },
  { id: 'fun', name: 'تفریح', icon: 'film', color: '#C94F7C' },
  { id: 'health', name: 'سلامت', icon: 'pulse', color: '#2E7D32' },
  { id: 'income', name: 'درآمد', icon: 'trending-up', color: '#1B1447' },
  { id: 'other', name: 'سایر', icon: 'pricetag', color: '#8B87A0' },
];

const mulberry32 = a => () => {
  a |= 0; a = (a + 0x6D2B79F5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const TPL = [
  ['اسنپ', 'transport', 28, 95, .5], ['تپسی', 'transport', 45, 140, .2],
  ['نان‌وایی محله', 'food', 80, 350, .5], ['هایپراستار', 'food', 450, 1800, .25],
  ['افق کوروش', 'food', 250, 900, .3], ['کافه لمیز', 'fun', 95, 260, .25],
  ['رستوران شمیران', 'food', 900, 2600, .1], ['دیجی‌کالا', 'shopping', 350, 4200, .15],
  ['فیلو', 'fun', 65, 180, .2], ['سینما پروژه', 'fun', 180, 320, .08],
  ['قبض برق — شرکت توزیع', 'bills', 180, 620, .05], ['اینترنت ایرانسل', 'bills', 89, 189, .1],
  ['داروخانه دکتر رحیمی', 'health', 120, 780, .06], ['باشگاه آفتاب', 'health', 450, 450, .04],
];

function seedTx() {
  const R = mulberry32(1403); const tx = []; let n = 1;
  for (let d = 63; d >= 0; d--)
    TPL.forEach(t => {
      if (R() < t[4] * .4) {
        const amt = Math.round((t[2] + R() * (t[3] - t[2])) / 1000) * 1000;
        tx.push({ id: 't' + (n++), type: 'expense', cat: t[1], note: t[0], amount: amt, d, src: R() < .85 ? 'sms' : 'manual' });
      }
    });
  const inc = (note, amt, d) => tx.push({ id: 't' + (n++), type: 'income', cat: 'income', note, amount: amt, d, src: 'sms' });
  inc('حقوق ماهانه — شرکت پارس‌تله‌کام', 28500000, 33);
  inc('حقوق ماهانه — شرکت پارس‌تله‌کام', 28500000, 3);
  inc('پروژه فریلنس طراحی رابط کاربری', 6800000, 44);
  inc('سود سپرده — بانک ملت', 940000, 35);
  inc('سود سپرده — بانک ملت', 940000, 5);
  tx.sort((a, b) => a.d - b.d);
  return tx;
}

function seed() {
  const R = mulberry32(777); let pv = 208e6; const hist = [];
  for (let i = 0; i < 30; i++) { pv *= 1 + (R() - .44) * .022; hist.push(Math.round(pv)); }
  return {
    v: 1, onboarded: false, pin: null, bio: true, pro: false,
    reminder: { on: true, freq: 'day', hour: 21 },
    cats: CATS0,
    tx: seedTx(),
    budgets: [
      { cat: 'food', limit: 5000000 }, { cat: 'transport', limit: 2000000 },
      { cat: 'shopping', limit: 4000000 }, { cat: 'fun', limit: 1500000 },
      { cat: 'bills', limit: 2500000 }, { cat: 'health', limit: 1500000 }],
    cash: { bank: 'بانک ملت', amount: 18500000 },
    assets: [
      { id: 'a1', name: 'سکه امامی', unit: '۰٫۸۵ عدد', icon: 'diamond', color: '#E8A13D', value: 86500000 },
      { id: 'a2', name: 'طلای ۱۸ عیار', unit: '۱۲٫۴ گرم', icon: 'diamond', color: '#FF6B47', value: 42100000 },
      { id: 'a3', name: 'بیت‌کوین', unit: '۰٫۰۲۱ BTC', icon: 'logo-bitcoin', color: '#E8A13D', value: 68200000 },
      { id: 'a4', name: 'تتر', unit: '۱۴۰ USDT', icon: 'cash', color: '#2E8B8B', value: 14100000 }],
    hist,
    loans: [
      { id: 'l1', dir: 'pay', name: 'وام مسکن — بانک مسکن', total: 360000000, paid: 96000000, monthly: 12000000, due: 12, remain: 22 },
      { id: 'l2', dir: 'pay', name: 'وام خودرو — بانک ملی', total: 180000000, paid: 90000000, monthly: 7500000, due: 3, remain: 12 },
      { id: 'l3', dir: 'recv', name: 'وام به حسین کریمی', total: 20000000, paid: 6000000, monthly: 2000000, due: 25, remain: 7 }],
    people: [
      { id: 'p1', name: 'علی رضایی', balance: 2400000, note: 'سهم سفر شمال' },
      { id: 'p2', name: 'مریم احمدی', balance: -1500000, note: 'قرض برای لپ‌تاپ' },
      { id: 'p3', name: 'شرکت پارس‌تله‌کام', balance: 8500000, note: 'اضافه‌کاری خرداد' }],
    checks: [
      { id: 'c1', dir: 'pay', amount: 45000000, due: 6, bank: 'بانک ملت', no: '۲۴۹**۸۸۱' },
      { id: 'c2', dir: 'recv', amount: 12000000, due: 14, bank: 'بانک صادرات', no: '۷۷۱**۲۰۳' },
      { id: 'c3', dir: 'pay', amount: 18000000, due: 28, bank: 'بانک ملی', no: '۳۳۴**۵۵۹' }],
  };
}

function reducer(s, a) {
  switch (a.t) {
    case 'set': return { ...s, ...a.p };
    case 'addTx': return { ...s, tx: [a.tx, ...s.tx],
      cash: a.tx.intoCash ? { ...s.cash, amount: s.cash.amount + (a.tx.type === 'income' ? a.tx.amount : -a.tx.amount) } : s.cash };
    case 'delTx': return { ...s, tx: s.tx.filter(t => t.id !== a.id) };
    case 'addBudget': return { ...s, budgets: [...s.budgets.filter(b => b.cat !== a.b.cat), a.b] };
    case 'delBudget': return { ...s, budgets: s.budgets.filter(b => b.cat !== a.id) };
    case 'addCat': return { ...s, cats: [...s.cats, a.c] };
    case 'delCat': return { ...s, cats: s.cats.filter(c => c.id !== a.id), tx: s.tx.map(t => t.cat === a.id ? { ...t, cat: 'other' } : t) };
    case 'addPerson': return { ...s, people: [...s.people, a.p] };
    case 'personTx': return { ...s, people: s.people.map(p => p.id === a.id ? { ...p, balance: p.balance + (a.dir === 'pay' ? a.amount : -a.amount) } : p) };
    case 'payLoan': return { ...s, loans: s.loans.map(l => l.id === a.id ? { ...l, paid: Math.min(l.total, l.paid + l.monthly), due: l.due + 30, remain: Math.max(0, l.remain - 1) } : l) };
    case 'addCheck': return { ...s, checks: [...s.checks, a.c] };
    default: return s;
  }
}

const Ctx = createContext(null);

export function StoreProvider({ children }) {
  const [st, dispatch] = useReducer(reducer, null, seed);
  const [ready, setReady] = useState(false);
  const [msg, setMsg] = useState(null);
  const tr = useRef();

  useEffect(() => {
    AsyncStorage.getItem(KEY).then(r => {
      if (r) { try { dispatch({ t: 'set', p: JSON.parse(r) }); } catch (e) {} }
      setReady(true);
    });
  }, []);
  useEffect(() => {
    if (ready) AsyncStorage.setItem(KEY, JSON.stringify(st)).catch(() => {});
  }, [st, ready]);

  const toast = m => { setMsg(m); clearTimeout(tr.current); tr.current = setTimeout(() => setMsg(null), 2600); };
  const catById = id => st.cats.find(c => c.id === id) || { id: 'other', name: 'سایر', icon: 'pricetag', color: '#8B87A0' };

  return <Ctx.Provider value={{ st, dispatch, toast, msg, catById }}>{children}</Ctx.Provider>;
}
export const useStore = () => useContext(Ctx);
