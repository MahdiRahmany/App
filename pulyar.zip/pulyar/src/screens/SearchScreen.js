import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { money, moneySign, fa } from '../utils/format';
import { jFull } from '../utils/jalali';
import { Card, Seg, Chip, Btn, Sheet, StackHeader, Empty } from '../components/ui';
import TxRow from '../components/TxRow';

export default function SearchScreen({ navigation, route }) {
  const { st, dispatch, toast, catById } = useStore();
  const [q, setQ] = useState(''), [type, setType] = useState('all'), [cats, setCats] = useState([]);
  const [open, setOpen] = useState(route.params?.open ? st.tx.find(t => t.id === route.params.open) : null);

  const res = st.tx.filter(t => {
    if (type !== 'all' && t.type !== type) return false;
    if (cats.length && !cats.includes(t.cat)) return false;
    if (q) {
      const c = catById(t.cat);
      if (!(t.note || '').includes(q) && !c.name.includes(q) && !String(t.amount).includes(q)) return false;
    }
    return true;
  });
  const net = res.reduce((s, t) => s + (t.type === 'income' ? t.amount : -t.amount), 0);

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StackHeader title="جستجوی تراکنش‌ها" onBack={navigation.goBack}
        right={<TouchableOpacity onPress={() => navigation.navigate('newtx')} style={ss.add}>
          <Ionicons name="add" size={20} color="#fff" /></TouchableOpacity>} />
      <View style={ss.searchBar}>
        <Ionicons name="search" size={17} color={C.tx2} />
        <TextInput style={ss.inp} value={q} onChangeText={setQ} placeholder="نام، دسته یا مبلغ…" placeholderTextColor={C.tx2} />
        {!!q && <TouchableOpacity onPress={() => setQ('')}><Ionicons name="close-circle" size={17} color={C.tx2} /></TouchableOpacity>}
      </View>
      <View style={{ paddingHorizontal: 16, marginTop: 10 }}>
        <Seg v={type} set={setType} opts={[{ v: 'all', t: 'همه' }, { v: 'expense', t: 'خرج' }, { v: 'income', t: 'درآمد' }]} />
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: 16, paddingVertical: 12 }}>
        {st.cats.filter(c => !(c.id === 'income' && type === 'expense')).map(c =>
          <Chip key={c.id} on={cats.includes(c.id)} color={c.color}
            onPress={() => setCats(v => v.includes(c.id) ? v.filter(x => x !== c.id) : [...v, c.id])}>{c.name}</Chip>)}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 6 }}>
        <Text style={ss.meta}>{fa(res.length)} نتیجه</Text>
        <Text style={ss.meta}>جمع خالص: <Text style={{ fontFamily: F.b, color: net >= 0 ? C.ok : C.dn }}>{money(net)} تومان</Text></Text>
      </View>
      <FlatList data={res} keyExtractor={t => t.id} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 30 }}
        renderItem={({ item }) => <Card><TxRow tx={item} cat={catById(item.cat)} onPress={() => setOpen(item)} /></Card>}
        ListEmptyComponent={<Empty icon="search" text="چیزی پیدا نشد — فیلترها را عوض کن" />} />

      <Sheet open={!!open} onClose={() => setOpen(null)} title="جزئیات تراکنش">
        {open && <View>
          <Text style={[ss.big, { color: open.type === 'income' ? C.ok : C.dn }]}>
            {moneySign(open.amount, open.type === 'income')} <Text style={{ fontSize: 12 }}>تومان</Text></Text>
          <Text style={ss.note}>{open.note || catById(open.cat).name}</Text>
          {[['دسته', catById(open.cat).name], ['تاریخ', jFull(open.d)],
            ['منبع', open.src === 'sms' ? 'خودکار از پیامک بانک' : 'ثبت دستی']].map(r =>
            <View key={r[0]} style={ss.drow}>
              <Text style={ss.dk}>{r[0]}</Text><Text style={ss.dv}>{r[1]}</Text>
            </View>)}
          <Btn icon="trash" title="حذف تراکنش" style={{ backgroundColor: C.dnSoft, marginTop: 16 }} txtStyle={{ color: C.dn }}
            onPress={() => { dispatch({ t: 'delTx', id: open.id }); toast('تراکنش حذف شد'); setOpen(null); }} />
        </View>}
      </Sheet>
    </View>
  );
}
const ss = StyleSheet.create({
  add: { width: 36, height: 36, borderRadius: 11, backgroundColor: C.acc, alignItems: 'center', justifyContent: 'center' },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#fff', borderRadius: 16, paddingHorizontal: 14, paddingVertical: 11, margin: 16, marginBottom: 0, elevation: 2 },
  inp: { flex: 1, fontFamily: F.r, fontSize: 13.5, color: C.tx, padding: 0 },
  meta: { fontFamily: F.r, fontSize: 11.5, color: C.tx2 },
  big: { fontFamily: F.xb, fontSize: 24, textAlign: 'center', marginTop: 6 },
  note: { fontFamily: F.b, fontSize: 13.5, color: C.tx, textAlign: 'center', marginTop: 6, marginBottom: 12 },
  drow: { flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: C.line, paddingVertical: 11 },
  dk: { fontFamily: F.r, fontSize: 13, color: C.tx2 }, dv: { fontFamily: F.b, fontSize: 13, color: C.tx },
});
