import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { Card, Sw, Btn, Keypad, Dots, StackHeader, Row } from '../components/ui';

export default function SecurityScreen({ navigation }) {
  const { st, dispatch, toast } = useStore();
  const [mode, setMode] = useState(null), [p1, setP1] = useState(''), [p2, setP2] = useState('');
  const cur = mode === 1 ? p1 : p2;

  const onKey = k => {
    if (k === 'del') { mode === 1 ? setP1(p => p.slice(0, -1)) : setP2(p => p.slice(0, -1)); return; }
    if (cur.length >= 4) return;
    const p = cur + k;
    if (mode === 1) { setP1(p); if (p.length === 4) setMode(2); }
    else {
      setP2(p);
      if (p.length === 4) {
        if (p === p1) { dispatch({ t: 'set', p: { pin: p } }); toast('پین تغییر کرد'); setMode(null); }
        else { toast('پین‌ها یکی نیستند'); setMode(1); setP1(''); setP2(''); }
      }
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StackHeader title="قفل و امنیت" onBack={navigation.goBack} />
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Card style={{ padding: 16 }}>
          <Row icon="finger-print" color={C.p} title="ورود با اثر انگشت" sub="با حسگر واقعی دستگاه"
            right={<Sw v={st.bio} set={v => { dispatch({ t: 'set', p: { bio: v } }); toast(v ? 'اثر انگشت فعال شد' : 'اثر انگشت خاموش شد'); }} />} />
        </Card>
        <Btn ghost icon="pencil" title="تغییر پین" onPress={() => { setMode(1); setP1(''); setP2(''); }} style={{ marginTop: 10 }} />
        {!!mode && (
          <Card style={{ padding: 16, marginTop: 14 }}>
            <Text style={sc.t}>{mode === 1 ? 'پین جدید (۴ رقم)' : 'تأیید پین جدید'}</Text>
            <View style={{ marginVertical: 14 }}><Dots n={cur.length} /></View>
            <Keypad onKey={onKey} />
          </Card>)}
      </ScrollView>
    </View>
  );
}
const sc = StyleSheet.create({ t: { fontFamily: F.b, fontSize: 13.5, color: C.tx, textAlign: 'center' } });
