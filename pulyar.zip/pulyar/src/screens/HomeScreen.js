import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { money, fa } from '../utils/format';
import { monthRange, monthLabel, todayLabel } from '../utils/jalali';
import { Card } from '../components/ui';
import { Bars } from '../components/charts';
import TxRow from '../components/TxRow';

export default function HomeScreen({ navigation }) {
  const { st, catById } = useStore();
  const [k, setK] = useState(0), [pick, setPick] = useState(null);
  const range = monthRange(k);
  const sumT = type => st.tx.reduce((s, t) => t.d >= range[0] && t.d <= range[1] && t.type === type ? s + t.amount : s, 0);
  const exp = sumT('expense'), inc = sumT('income');
  const days = range[1] - range[0] + 1;
  const daily = Array.from({ length: days }, (_, i) =>
    st.tx.reduce((s, t) => t.d === range[0] + i && t.type === 'expense' ? s + t.amount : s, 0));

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={h.hdr}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View>
              <Text style={h.h1}>سلام سارا</Text>
              <Text style={h.sub}>خلاصه‌ی {monthLabel(k)} — {todayLabel()}</Text>
            </View>
            <TouchableOpacity style={h.icob} onPress={() => navigation.navigate('reminder')}>
              <Ionicons name="notifications" size={19} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>

        <Card style={h.ov}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View>
              <Text style={h.lbl}>خرج این ماه</Text>
              <Text style={h.big}>{money(exp)} <Text style={h.unit}>تومان</Text></Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.bg, borderRadius: 12, padding: 4 }}>
              <TouchableOpacity disabled={k >= 5} onPress={() => setK(v => v + 1)} style={[h.navB, k >= 5 && { opacity: .3 }]}>
                <Ionicons name="chevron-forward" size={15} color={C.tx} />
              </TouchableOpacity>
              <Text style={h.m}>{monthLabel(k)}</Text>
              <TouchableOpacity disabled={k === 0} onPress={() => setK(v => v - 1)} style={[h.navB, k === 0 && { opacity: .3 }]}>
                <Ionicons name="chevron-back" size={15} color={C.tx} />
              </TouchableOpacity>
            </View>
          </View>
          <View style={{ flexDirection: 'row', gap: 18, marginTop: 12 }}>
            <Text style={h.leg}><Text style={{ color: C.ok }}>● </Text>درآمد: <Text style={{ fontFamily: F.b, color: C.ok }}>{money(inc)}</Text></Text>
            <Text style={h.leg}>میانگین روزانه: <Text style={{ fontFamily: F.b }}>{money(exp / days)}</Text></Text>
          </View>
          <Bars vals={daily} picked={pick} onPick={i => setPick(pick === i ? null : i)} />
          <Text style={h.cap}>
            {pick === null ? 'روند خرج روزانه — روی میله‌ها بزن'
              : fa(range[0] + pick + 1) + ' ' + monthLabel(k) + ' — ' + money(daily[pick]) + ' تومان'}
          </Text>
        </Card>

        <TouchableOpacity activeOpacity={.8} style={h.search} onPress={() => navigation.navigate('search')}>
          <Ionicons name="search" size={18} color={C.tx2} />
          <Text style={h.searchT}>جستجو در تراکنش‌ها…</Text>
        </TouchableOpacity>

        <View style={{ paddingHorizontal: 16 }}>
          <View style={h.sectH}>
            <Text style={h.sectT}>آخرین تراکنش‌ها</Text>
            <Text style={h.more} onPress={() => navigation.navigate('search')}>همه ‹</Text>
          </View>
          <Card>
            {st.tx.slice(0, 6).map(t =>
              <TxRow key={t.id} tx={t} cat={catById(t.cat)} onPress={() => navigation.navigate('search', { open: t.id })} />)}
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}
const h = StyleSheet.create({
  hdr: { backgroundColor: C.pd, paddingTop: 56, paddingHorizontal: 20, paddingBottom: 60 },
  h1: { fontFamily: F.xb, fontSize: 21, color: '#fff' },
  sub: { fontFamily: F.r, fontSize: 12.5, color: '#B8B2D9', marginTop: 4 },
  icob: { width: 38, height: 38, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.12)', alignItems: 'center', justifyContent: 'center' },
  ov: { marginTop: -46, marginHorizontal: 16, padding: 16 },
  lbl: { fontFamily: F.b, fontSize: 11.5, color: C.tx2 },
  big: { fontFamily: F.xb, fontSize: 25, color: C.pd, marginTop: 2 },
  unit: { fontFamily: F.b, fontSize: 12, color: C.tx2 },
  navB: { width: 30, height: 30, borderRadius: 10, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  m: { fontFamily: F.b, fontSize: 12, minWidth: 76, textAlign: 'center' },
  leg: { fontFamily: F.r, fontSize: 11, color: C.tx2 },
  cap: { fontFamily: F.b, fontSize: 11.5, color: pick === null ? C.tx2 : C.acc, textAlign: 'center', marginTop: 4 },
  search: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#fff', borderRadius: 16, paddingHorizontal: 14, paddingVertical: 13, marginHorizontal: 16, marginTop: 18, elevation: 2 },
  searchT: { fontFamily: F.r, fontSize: 13, color: C.tx2, flex: 1 },
  sectH: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10 },
  sectT: { fontFamily: F.xb, fontSize: 15, color: C.tx },
  more: { fontFamily: F.b, fontSize: 12.5, color: C.acc },
});
