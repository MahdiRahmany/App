import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet } from 'react-native';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { money, parseNum } from '../utils/format';
import { uid } from '../utils/format';
import { Card, Seg, Btn, StackHeader, Chip, Inp } from '../components/ui';

export default function NewTxScreen({ navigation }) {
  const { st, dispatch, toast } = useStore();
  const [type, setType] = useState('expense'), [amt, setAmt] = useState('');
  const [cat, setCat] = useState('food'), [note, setNote] = useState('');
  const opts = st.cats.filter(c => (type === 'income' ? c.id === 'income' : c.id !== 'income'));
  const v = parseNum(amt);

  const save = () => {
    if (!v) return toast('مبلغ را وارد کن');
    dispatch({
      t: 'addTx',
      tx: { id: uid(), type, cat: opts.some(c => c.id === cat) ? cat : opts[0].id,
        note: note.trim(), amount: v, d: 0, src: 'manual', intoCash: true },
    });
    toast((type === 'income' ? 'درآمد' : 'خرج') + ' ثبت شد');
    navigation.goBack();
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ paddingBottom: 40 }}>
      <StackHeader title="تراکنش جدید" onBack={navigation.goBack} />
      <View style={{ padding: 16 }}>
        <Seg v={type} set={t => { setType(t); setCat(t === 'income' ? 'income' : 'food'); }}
          opts={[{ v: 'expense', t: 'خرج کردم' }, { v: 'income', t: 'درآمد داشتم' }]} />
      </View>
      <TextInput value={amt} onChangeText={setAmt} keyboardType="number-pad" placeholder="۰"
        placeholderTextColor={C.line} style={[s.amt, { color: type === 'income' ? C.ok : C.tx }]} />
      <Text style={s.sub}>{v ? money(v) + ' تومان' : 'مبلغ به تومان'}</Text>
      <Text style={s.lbl}>دسته‌بندی</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: 16 }}>
        {opts.map(c => <Chip key={c.id} on={cat === c.id} color={c.color} onPress={() => setCat(c.id)}>{c.name}</Chip>)}
      </View>
      <View style={{ padding: 16 }}>
        <Inp label="یادداشت (اختیاری)" value={note} onChangeText={setNote} placeholder="مثلاً: خرید هفتگی هایپراستار" />
        <Text style={s.hint}>محل: حساب {st.cash.bank} — موجودی نقدی به‌صورت خودکار به‌روز می‌شود</Text>
        <Btn icon="checkmark" title={'ثبت ' + (type === 'income' ? 'درآمد' : 'خرج')} onPress={save} style={{ marginTop: 18 }} />
      </View>
    </ScrollView>
  );
}
const s = StyleSheet.create({
  amt: { fontFamily: F.xb, fontSize: 38, textAlign: 'center', paddingVertical: 16 },
  sub: { fontFamily: F.b, fontSize: 13, color: C.tx2, textAlign: 'center' },
  lbl: { fontFamily: F.b, fontSize: 12, color: C.tx2, marginTop: 14, marginBottom: 7, paddingHorizontal: 16 },
  hint: { fontFamily: F.r, fontSize: 11.5, color: C.tx2, marginTop: 14 },
});
