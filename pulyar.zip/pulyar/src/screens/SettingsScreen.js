import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { fa } from '../utils/format';
import { Card, Row } from '../components/ui';

export default function SettingsScreen({ navigation }) {
  const { st, toast } = useStore();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 130 }}>
      <Text style={ss.h1}>تنظیمات</Text>
      <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16, marginTop: 14 }}>
        <View style={ss.avatar}><Text style={ss.avT}>س</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={ss.name}>سارا محمدی</Text>
          <Text style={ss.sub}>{st.pro ? 'اشتراک حرفه‌ای — ۳۱ روز باقیمانده' : 'نسخه رایگان'}</Text>
        </View>
        {!!st.pro && <View style={ss.pro}><Ionicons name="shield-checkmark" size={12} color={C.ok} />
          <Text style={ss.proT}>فعال</Text></View>}
      </Card>
      <Card style={{ marginTop: 14 }}>
        <Row icon="pricetag" color={C.acc} title="مدیریت دسته‌بندی‌ها" sub="دسته و زیرمجموعه دلخواه بساز" onPress={() => navigation.navigate('cats')}
          right={<Ionicons name="chevron-back" size={15} color="#C9C6D8" />} />
        <Row icon="notifications" color="#E8A13D" title="یادآور ثبت خرج"
          sub={st.reminder.on ? (st.reminder.freq === 'day' ? 'روزانه' : 'هفتگی') + ' — ساعت ' + st.reminder.hour + ':۰۰' : 'غیرفعال'}
          onPress={() => navigation.navigate('reminder')} right={<Ionicons name="chevron-back" size={15} color="#C9C6D8" />} />
        <Row icon="lock-closed" color={C.p} title="قفل و امنیت" sub={st.bio ? 'پین + اثر انگشت' : 'فقط پین'}
          onPress={() => navigation.navigate('security')} right={<Ionicons name="chevron-back" size={15} color="#C9C6D8" />} />
        <Row icon="document-text" color="#2E8B8B" title="پشتیبان‌گیری و بازیابی" sub="خروجی و ورودی آفلاین JSON"
          onPress={() => navigation.navigate('backup')} right={<Ionicons name="chevron-back" size={15} color="#C9C6D8" />} />
      </Card>
      <Card style={{ marginTop: 14 }}>
        <Row icon="gift" color={C.acc} title="اشتراک پول‌یار" sub={st.pro ? '۳۱ روز رایگان فعال است' : 'فعال‌سازی دوره آزمایشی'}
          onPress={() => toast(st.pro ? 'اشتراک فعال تو تا ۳۱ روز اعتبار دارد' : 'از آنبوردینگ فعال می‌شود')} />
      </Card>
      <Text style={ss.foot}>پول‌یار نسخه ۱٫۰ — داده‌ها فقط روی همین دستگاه ذخیره می‌شوند</Text>
    </ScrollView>
  );
}
const ss = StyleSheet.create({
  h1: { fontFamily: F.xb, fontSize: 20, color: C.tx },
  avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: C.pd, alignItems: 'center', justifyContent: 'center' },
  avT: { color: '#fff', fontFamily: F.xb, fontSize: 19 },
  name: { fontFamily: F.xb, fontSize: 15, color: C.tx }, sub: { fontFamily: F.r, fontSize: 11.5, color: C.tx2, marginTop: 2 },
  pro: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: C.okSoft, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 8 },
  proT: { fontFamily: F.b, fontSize: 10.5, color: C.ok },
  foot: { fontFamily: F.r, fontSize: 11, color: C.tx2, textAlign: 'center', marginTop: 20 },
});
