import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { fa, uid } from '../utils/format';
import { Card, Sheet, Btn, Inp, Row, StackHeader } from '../components/ui';

const PALETTE = ['#FF6B47', '#2A1F6E', '#E8A13D', '#2E8B8B', '#C94F7C', '#2E7D32', '#5B4BC4'];
const ICONS = ['restaurant', 'car', 'receipt', 'bag-handle', 'film', 'pulse', 'home', 'book', 'gift', 'flash', 'cash', 'pricetag'];

export default function CategoriesScreen({ navigation }) {
  const { st, dispatch, toast } = useStore();
  const [open, setOpen] = useState(false), [nm, setNm] = useState('');
  const [ic, setIc] = useState('pricetag'), [cl, setCl] = useState('#FF6B47'), [par, setPar] = useState('');
  const roots = st.cats.filter(c => !c.parent);
  const subs = c => st.cats.filter(x => x.parent === c.id);
  const count = id => st.tx.filter(t => t.cat === id).length;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StackHeader title="مدیریت دسته‌بندی" onBack={navigation.goBack}
        right={<TouchableOpacity style={cs.add} onPress={() => setOpen(true)}><Ionicons name="add" size={19} color="#fff" /></TouchableOpacity>} />
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Card>
          {roots.map(c => (
            <View key={c.id}>
              <Row icon={c.icon} color={c.color} title={c.name} sub={fa(count(c.id)) + ' تراکنش'}
                right={count(c.id) === 0 &&
                  <TouchableOpacity onPress={() => { dispatch({ t: 'delCat', id: c.id }); toast('دسته حذف شد'); }}>
                    <Ionicons name="trash-outline" size={15} color="#C9C6D8" /></TouchableOpacity>} />
              {subs(c).map(s2 => <Row key={s2.id} icon={s2.icon} color={s2.color}
                title={s2.name} sub={'زیرمجموعه ' + c.name + ' · ' + fa(count(s2.id)) + ' تراکنش'} />)}
            </View>))}
        </Card>
        <Text style={cs.foot}>دسته‌ای که تراکنش دارد قابل حذف نیست تا گزارش‌ها خراب نشوند.</Text>
      </ScrollView>

      <Sheet open={open} onClose={() => setOpen(false)} title="دسته جدید">
        <Inp value={nm} onChangeText={setNm} placeholder="نام دسته" />
        <Text style={cs.lbl}>آیکون</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {ICONS.map(x => (
            <TouchableOpacity key={x} onPress={() => setIc(x)} style={[cs.ic, { borderColor: ic === x ? cl : C.line }]}>
              <Ionicons name={x} size={18} color={ic === x ? cl : C.tx2} />
            </TouchableOpacity>))}
        </View>
        <Text style={cs.lbl}>رنگ</Text>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          {PALETTE.map(x => (
            <TouchableOpacity key={x} onPress={() => setCl(x)}
              style={[cs.cl, { backgroundColor: x }, cl === x && { borderWidth: 2, borderColor: C.tx }]} />))}
        </View>
        <Text style={cs.lbl}>زیرمجموعهٔ (اختیاری)</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          <Text onPress={() => setPar('')} style={[cs.pchip, !par && cs.pchipOn]}>دسته اصلی</Text>
          {roots.map(c => <Text key={c.id} onPress={() => setPar(c.id)} style={[cs.pchip, par === c.id && cs.pchipOn]}>{c.name}</Text>)}
        </View>
        <Btn title="افزودن دسته" style={{ marginTop: 18 }} onPress={() => {
          if (!nm.trim()) return toast('نام دسته را وارد کن');
          dispatch({ t: 'addCat', c: { id: uid(), name: nm.trim(), icon: ic, color: cl, parent: par || undefined } });
          toast('دسته اضافه شد'); setOpen(false); setNm('');
        }} />
      </Sheet>
    </View>
  );
}
const cs = StyleSheet.create({
  add: { width: 36, height: 36, borderRadius: 11, backgroundColor: C.acc, alignItems: 'center', justifyContent: 'center' },
  foot: { fontFamily: F.r, fontSize: 11, color: C.tx2, marginTop: 12, paddingHorizontal: 4 },
  lbl: { fontFamily: F.b, fontSize: 12, color: C.tx2, marginTop: 14, marginBottom: 7 },
  ic: { width: 42, height: 42, borderRadius: 13, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  cl: { width: 34, height: 34, borderRadius: 17 },
  pchip: { fontFamily: F.b, fontSize: 12.5, color: C.tx2, borderWidth: 1.5, borderColor: C.line, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 7, overflow: 'hidden' },
  pchipOn: { color: C.acc, borderColor: C.acc, backgroundColor: C.accSoft },
});
