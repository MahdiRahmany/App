import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { money, parseNum, fa } from '../utils/format';
import { monthRange, monthLabel } from '../utils/jalali';
import { Card, ProgressBar, Sheet, Btn, Inp, Chip, Empty } from '../components/ui';

export default function BudgetScreen() {
  const { st, dispatch, toast, catById } = useStore();
  const range = monthRange(0);
  const spentOf = c => st.tx.reduce((s, t) => t.type === 'expense' && t.cat === c && t.d >= range[0] && t.d <= range[1] ? s + t.amount : s, 0);
  const tot = st.budgets.reduce((s, b) => s + b.limit, 0);
  const used = st.budgets.reduce((s, b) => s + spentOf(b.cat), 0);
  const free = st.cats.filter(c => c.id !== 'income' && !st.budgets.some(b => b.cat === c.id));
  const [open, setOpen] = useState(false), [ncat, setNcat] = useState(free[0]?.id), [nl, setNl] = useState('');

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 130 }}>
        <Text style={bs.h1}>بودجه‌بندی</Text>
        <Card style={{ padding: 16, marginTop: 14 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <Text style={bs.lbl}>مصرف {monthLabel(0)}</Text>
            <Text style={bs.big}>{money(used)} <Text style={bs.unit}>از {money(tot)} تومان</Text></Text>
          </View>
          <View style={{ marginVertical: 10 }}><ProgressBar v={used} max={tot} /></View>
          <Text style={[bs.pct, { color: used > tot ? C.dn : C.tx2 }]}>
            {used > tot ? 'از بودجه کل رد شدی!' : fa(Math.round(used / tot * 100)) + '٪ بودجه مصرف شده'}</Text>
        </Card>

        <Card style={{ marginTop: 14 }}>
          {st.budgets.map(b => {
            const c = catById(b.cat), sp = spentOf(b.cat), pc = b.limit ? sp / b.limit * 100 : 0;
            return (
              <View key={b.cat} style={bs.item}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 11 }}>
                  <View style={[bs.ico, { backgroundColor: c.color + '1a' }]}><Ionicons name={c.icon} size={17} color={c.color} /></View>
                  <Text style={{ flex: 1, fontFamily: F.b, fontSize: 13.5, color: C.tx }}>{c.name}</Text>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text style={{ fontFamily: F.b, fontSize: 11.5, color: pc > 100 ? C.dn : C.pd }}>{money(sp)}</Text>
                    <Text style={{ fontFamily: F.r, fontSize: 10.5, color: C.tx2 }}>از {money(b.limit)}</Text>
                  </View>
                  <TouchableOpacity onPress={() => { dispatch({ t: 'delBudget', id: b.cat }); toast('بودجه حذف شد'); }}>
                    <Ionicons name="trash-outline" size={16} color="#C9C6D8" />
                  </TouchableOpacity>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 9 }}>
                  <View style={{ flex: 1 }}><ProgressBar v={sp} max={b.limit} /></View>
                  <Text style={{ fontFamily: F.b, fontSize: 11, color: pc > 100 ? C.dn : pc > 70 ? C.acc : C.tx2 }}>{fa(Math.round(pc))}٪</Text>
                </View>
              </View>);
          })}
          {!st.budgets.length && <Empty icon="wallet" text="هنوز بودجه‌ای نساختی — دکمه + را بزن" />}
        </Card>
      </ScrollView>

      <TouchableOpacity style={bs.fab} activeOpacity={.85} onPress={() => setOpen(true)}>
        <Ionicons name="add" size={26} color="#fff" />
      </TouchableOpacity>

      <Sheet open={open} onClose={() => setOpen(false)} title="بودجه جدید">
        {free.length ? <View>
          <Text style={bs.lbl}>دسته</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {free.map(c => <Chip key={c.id} on={ncat === c.id} color={c.color} onPress={() => setNcat(c.id)}>{c.name}</Chip>)}
          </View>
          <Inp label="سقف ماهانه (تومان)" keyboardType="number-pad" value={nl} onChangeText={setNl} placeholder="مثلاً ۳۰۰۰۰۰۰" />
          {parseNum(nl) > 0 && <Text style={bs.hint}>= {money(parseNum(nl))} تومان</Text>}
          <Btn title="ثبت بودجه" style={{ marginTop: 18 }} onPress={() => {
            if (!ncat || !parseNum(nl)) return toast('دسته و مبلغ را کامل کن');
            dispatch({ t: 'addBudget', b: { cat: ncat, limit: parseNum(nl) } });
            toast('بودجه ثبت شد'); setOpen(false); setNl('');
          }} />
        </View> : <Empty icon="checkmark-circle" text="همه دسته‌ها بودجه دارند!" />}
      </Sheet>
    </View>
  );
}
const bs = StyleSheet.create({
  h1: { fontFamily: F.xb, fontSize: 20, color: C.tx },
  lbl: { fontFamily: F.b, fontSize: 12, color: C.tx2 },
  big: { fontFamily: F.xb, fontSize: 14, color: C.pd }, unit: { fontFamily: F.b, fontSize: 10.5, color: C.tx2 },
  pct: { fontFamily: F.b, fontSize: 11 },
  item: { padding: 16, borderBottomWidth: 1, borderBottomColor: C.line },
  ico: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  fab: { position: 'absolute', bottom: 110, left: 24, width: 54, height: 54, borderRadius: 18, backgroundColor: C.acc, alignItems: 'center', justifyContent: 'center', elevation: 6 },
  hint: { fontFamily: F.r, fontSize: 11.5, color: C.tx2, marginTop: 6 },
});
