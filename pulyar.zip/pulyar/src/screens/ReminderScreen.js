import React, { useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import * as Notifications from 'expo-notifications';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { Card, Seg, Sw, Chip, StackHeader } from '../components/ui';

export default function ReminderScreen({ navigation }) {
  const { st, dispatch, toast } = useStore();
  const r = st.reminder;

  useEffect(() => {
    (async () => {
      try {
        if (!r.on) { await Notifications.cancelAllScheduledNotificationsAsync(); return; }
        const { status } = await Notifications.requestPermissionsAsync();
        if (status !== 'granted') { toast('اجازه اعلان داده نشد'); return; }
        await Notifications.cancelAllScheduledNotificationsAsync();
        const trigger = r.freq === 'day'
          ? { hour: r.hour, minute: 0, repeats: true }
          : { weekday: 6, hour: r.hour, minute: 0, repeats: true }; // ۶ = جمعه
        await Notifications.scheduleNotificationAsync({
          content: { title: 'یادت نره! 🪙', body: 'خرج‌های امروز را در پول‌یار ثبت کن.' },
          trigger,
        });
        toast('یادآور زمان‌بندی شد');
      } catch (e) { toast('خطا در زمان‌بندی اعلان'); }
    })();
  }, [r.on, r.freq, r.hour]);

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StackHeader title="یادآور ثبت خرج" onBack={navigation.goBack} />
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Card style={{ padding: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <View style={rm.oi}><Ionicons name="notifications" size={17} color={C.acc} /></View>
            <View style={{ flex: 1 }}>
              <Text style={rm.t}>یادآور فعال</Text>
              <Text style={rm.s}>اعلان سر ساعت انتخابی</Text>
            </View>
            <Sw v={r.on} set={v => dispatch({ t: 'set', p: { reminder: { ...r, on: v } } })} />
          </View>
          {!!r.on && <>
            <Text style={rm.lbl}>تناوب</Text>
            <Seg v={r.freq} set={v => dispatch({ t: 'set', p: { reminder: { ...r, freq: v } } })}
              opts={[{ v: 'day', t: 'هر روز' }, { v: 'week', t: 'هفتگی' }]} />
            <Text style={rm.lbl}>ساعت</Text>
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
              {[8, 12, 18, 21, 22].map(h =>
                <Chip key={h} on={r.hour === h} onPress={() => dispatch({ t: 'set', p: { reminder: { ...r, hour: h } } })}>{h}:۰۰</Chip>)}
            </View>
            <Text style={rm.note}>در iOS و اندروید، اگر اعلان اپ را ببندی، یادآور نمایش داده نمی‌شود.</Text>
          </>}
        </Card>
      </ScrollView>
    </View>
  );
}
const rm = StyleSheet.create({
  oi: { width: 38, height: 38, borderRadius: 12, backgroundColor: C.accSoft, alignItems: 'center', justifyContent: 'center' },
  t: { fontFamily: F.b, fontSize: 13.5, color: C.tx }, s: { fontFamily: F.r, fontSize: 11, color: C.tx2 },
  lbl: { fontFamily: F.b, fontSize: 12, color: C.tx2, marginTop: 14, marginBottom: 7 },
  note: { fontFamily: F.r, fontSize: 10.5, color: C.tx2, marginTop: 14, lineHeight: 18 },
});
