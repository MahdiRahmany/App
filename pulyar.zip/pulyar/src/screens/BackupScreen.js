import React from 'react';
import { View, Text, ScrollView, StyleSheet, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { fa } from '../utils/format';
import { Card, Btn, StackHeader } from '../components/ui';

export default function BackupScreen({ navigation }) {
  const { st, dispatch, toast } = useStore();

  const doExport = async () => {
    const path = FileSystem.cacheDirectory + 'pulyar-backup.json';
    await FileSystem.writeAsStringAsync(path, JSON.stringify(st), { encoding: FileSystem.EncodingType.UTF8 });
    if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(path, { mimeType: 'application/json' });
    else toast('فایل ذخیره شد: ' + path);
  };

  const doImport = async () => {
    try {
      const r = await DocumentPicker.getDocumentAsync({ type: 'application/json' });
      if (r.canceled) return;
      const txt = await FileSystem.readAsStringAsync(r.assets[0].uri);
      const d = JSON.parse(txt);
      if (!d.tx || !d.cats) throw 0;
      Alert.alert('بازیابی', fa(d.tx.length) + ' تراکنش جایگزین داده فعلی شود؟', [
        { text: 'انصراف', style: 'cancel' },
        { text: 'بازیابی', style: 'destructive', onPress: () => { dispatch({ t: 'set', p: d }); toast('بازیابی انجام شد'); navigation.goBack(); } }]);
    } catch (e) { toast('فایل نامعتبر است'); }
  };

  const doWipe = () => Alert.alert('پاک‌کردن داده‌ها', 'همه داده‌ها برای همیشه حذف می‌شوند. مطمئنی؟', [
    { text: 'انصراف', style: 'cancel' },
    { text: 'پاک کن', style: 'destructive', onPress: async () => {
      await AsyncStorage.clear();
      toast('پاک شد — اپ را ببند و دوباره باز کن');
    } }]);

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StackHeader title="پشتیبان‌گیری و بازیابی" onBack={navigation.goBack} />
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Card style={{ padding: 16 }}>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            {[['تراکنش', st.tx.length], ['دسته', st.cats.length], ['دارایی', st.assets.length], ['چک', st.checks.length]].map(x => (
              <View key={x[0]} style={bk.stat}>
                <Text style={bk.statV}>{fa(x[1])}</Text><Text style={bk.statT}>{x[0]}</Text>
              </View>))}
          </View>
          <Btn icon="download" title="دریافت فایل پشتیبان (JSON)" onPress={doExport} style={{ marginTop: 16 }} />
          <Btn icon="cloud-upload" title="بازیابی از فایل" dark onPress={doImport} style={{ marginTop: 10 }} />
          <Btn icon="trash" title="پاک‌کردن همه داده‌ها" style={{ marginTop: 10, backgroundColor: C.dnSoft }} txtStyle={{ color: C.dn }} onPress={doWipe} />
          <Text style={bk.note}>همه‌چیز آفلاین و روی همین دستگاه (AsyncStorage) ذخیره می‌شود. فایل پشتیبان را جایی امن نگه دار.</Text>
        </Card>
      </ScrollView>
    </View>
  );
}
const bk = StyleSheet.create({
  stat: { flex: 1, backgroundColor: C.bg, borderRadius: 13, paddingVertical: 12, alignItems: 'center' },
  statV: { fontFamily: F.xb, fontSize: 16, color: C.pd }, statT: { fontFamily: F.r, fontSize: 10.5, color: C.tx2, marginTop: 2 },
  note: { fontFamily: F.r, fontSize: 11, color: C.tx2, textAlign: 'center', lineHeight: 19, marginTop: 14 },
});
