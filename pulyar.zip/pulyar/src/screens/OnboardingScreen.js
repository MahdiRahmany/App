import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform, PermissionsAndroid } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { Card, Btn, Chip, Seg, Sw, Dots, Keypad, Row } from '../components/ui';

export default function OnboardingScreen() {
  const { st, dispatch, toast } = useStore();
  const [i, setI] = useState(0);
  const [pin, setPin] = useState(''), [pin1, setPin1] = useState(''), [pstep, setPstep] = useState(0);
  const next = () => setI(v => v + 1);
  const finish = () => dispatch({ t: 'set', p: { onboarded: true } });

  const askSms = async () => {
    if (Platform.OS !== 'android') { toast('در iOS خواندن پیامک ممکن نیست — با داده نمونه ادامه بده'); return next(); }
    try {
      const g = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.RECEIVE_SMS,
        PermissionsAndroid.PERMISSIONS.READ_SMS,
      ]);
      const ok = g['android.permission.RECEIVE_SMS'] === 'granted';
      toast(ok ? 'دسترسی پیامک داده شد' : 'دسترسی داده نشد — با داده نمونه ادامه می‌دهیم');
    } catch (e) { toast('خطا در دسترسی'); }
    next();
  };

  const key = k => {
    if (k === 'del') return setPin(p => p.slice(0, -1));
    if (pin.length >= 4) return;
    const p = pin + k;
    if (p.length === 4) {
      if (pstep === 0) { setPin1(p); setPstep(1); setPin(''); return; }
      if (p === pin1) { dispatch({ t: 'set', p: { pin: p } }); toast('پین ۴ رقمی ثبت شد'); setTimeout(next, 400); return; }
      toast('پین‌ها یکسان نیستند — دوباره تلاش کن'); setPin(''); setPstep(0); return;
    }
    setPin(p);
  };

  const Hero = ({ icon, title, desc }) => (
    <View style={{ alignItems: 'center', marginBottom: 14 }}>
      <View style={ob.hero}><Ionicons name={icon} size={32} color={C.acc} /></View>
      <Text style={ob.h1}>{title}</Text>
      {!!desc && <Text style={ob.h2}>{desc}</Text>}
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ padding: 20, paddingTop: 40 }}>
      <View style={{ flexDirection: 'row-reverse', justifyContent: 'center', gap: 6, marginBottom: 16 }}>
        {[0, 1, 2, 3].map(j => <View key={j} style={[ob.dot, j === i && ob.dotOn]} />)}
      </View>

      {i === 0 && <>
        <Hero icon="notifications" title="خواندن پیامک‌های بانکی"
          desc="با اجازه‌ی تو، پول‌یار پیامک‌های واریز و برداشت بانک را می‌خواند و تراکنش‌ها را خودکار و دسته‌بندی‌شده ثبت می‌کند." />
        <Card>
          <Row icon="shield-checkmark" color={C.acc} title="داده‌ها فقط روی گوشی تو می‌ماند" sub="هیچ پیامکی به سروری ارسال نمی‌شود" />
          <Row icon="flash" color={C.acc} title="ثبت لحظه‌ای و خودکار" sub="هم‌زمان با رسیدن پیامک بانک" />
        </Card>
        <Btn title="اجازه دسترسی به پیامک" icon="notifications" onPress={askSms} style={{ marginTop: 18 }} />
        <Btn ghost title="فعلاً نه" onPress={next} style={{ marginTop: 8 }} />
      </>}

      {i === 1 && <>
        <Hero icon="lock-closed" title="قفل فقط برای خودت"
          desc={pstep === 0 ? 'یک پین ۴ رقمی انتخاب کن' : 'حالا پین را دوباره وارد کن'} />
        <View style={{ marginVertical: 14 }}><Dots n={pin.length} /></View>
        <Keypad onKey={key} />
        <Card style={{ marginTop: 18 }}>
          <Row icon="finger-print" color={C.p} title="ورود با اثر انگشت" sub="علاوه بر پین، با حسگر دستگاه هم باز می‌شود"
            right={<Sw v={st.bio} set={v => dispatch({ t: 'set', p: { bio: v } })} />} />
        </Card>
      </>}

      {i === 2 && <>
        <Hero icon="alarm" title="یادآور ثبت خرج"
          desc="هر روز یا هفته‌ای یک‌بار، سر ساعت دلخواه یادت می‌اندازیم خرج‌ها را ثبت کنی." />
        <Card style={{ padding: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Ionicons name="notifications" size={19} color={C.acc} />
            <Text style={{ flex: 1, fontFamily: F.b, fontSize: 13.5, color: C.tx }}>یادآور فعال</Text>
            <Sw v={st.reminder.on} set={v => dispatch({ t: 'set', p: { reminder: { ...st.reminder, on: v } } })} />
          </View>
          {!!st.reminder.on && <>
            <Text style={ob.lbl}>تناوب</Text>
            <Seg v={st.reminder.freq} set={v => dispatch({ t: 'set', p: { reminder: { ...st.reminder, freq: v } } })}
              opts={[{ v: 'day', t: 'هر روز' }, { v: 'week', t: 'هفتگی' }]} />
            <Text style={ob.lbl}>ساعت یادآوری</Text>
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
              {[8, 12, 18, 21, 22].map(h =>
                <Chip key={h} on={st.reminder.hour === h}
                  onPress={() => dispatch({ t: 'set', p: { reminder: { ...st.reminder, hour: h } } })}>{h}:۰۰</Chip>)}
            </View>
          </>}
        </Card>
        <Btn title="ادامه" onPress={next} style={{ marginTop: 18 }} />
      </>}

      {i === 3 && <>
        <Hero icon="gift" title="۳۱ روز اشتراک رایگان" desc="همه‌ی امکانات حرفه‌ای، یک ماه مهمان ما باش" />
        <Card>
          {[['flash', 'ثبت خودکار و نامحدود تراکنش از پیامک بانک'],
            ['stats-chart', 'نمودارهای پیشرفته و گزارش‌گیری عمیق'],
            ['document-text', 'پشتیبان‌گیری خودکار و خروجی کامل داده‌ها'],
            ['shield-checkmark', 'پیش‌بینی خرج ماهانه و هشدار بودجه']].map(f =>
            <Row key={f[0]} icon={f[0]} color={C.ok} title={f[1]} />)}
        </Card>
        <Btn title="شروع ۳۱ روز رایگان" icon="gift"
          onPress={() => { dispatch({ t: 'set', p: { pro: true, onboarded: true } }); toast('اشتراک رایگان فعال شد — خوش آمدی!'); }}
          style={{ marginTop: 18 }} />
        <Btn ghost title="رد کردن — بعداً تصمیم می‌گیرم" onPress={finish} style={{ marginTop: 8 }} />
      </>}
    </ScrollView>
  );
}
const ob = StyleSheet.create({
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#D9D7E6' },
  dotOn: { backgroundColor: C.acc, width: 20 },
  hero: { width: 76, height: 76, borderRadius: 26, backgroundColor: C.accSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  h1: { fontFamily: F.xb, fontSize: 20, color: C.tx, textAlign: 'center' },
  h2: { fontFamily: F.r, fontSize: 13, color: C.tx2, textAlign: 'center', lineHeight: 22, marginTop: 8, paddingHorizontal: 10 },
  lbl: { fontFamily: F.b, fontSize: 12, color: C.tx2, marginTop: 14, marginBottom: 7 },
});
