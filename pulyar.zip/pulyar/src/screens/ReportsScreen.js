import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { money, fa } from '../utils/format';
import { monthRange, monthLabel, jAgo, FM } from '../utils/jalali';
import { Card, Seg, ProgressBar } from '../components/ui';
import { Donut } from '../components/charts';

export default function ReportsScreen() {
  const { st } = useStore();
  const [mode, setMode] = useState('month'), [sel, setSel] = useState(null);
  const range = mode === 'day' ? [0, 0] : monthRange(0);
  const exp = st.tx.filter(t => t.type === 'expense' && t.d >= range[0] && t.d <= range[1]);
  const data = st.cats.filter(c => c.id !== 'income')
    .map(c => ({ ...c, v: exp.reduce((s, t) => t.cat === c.id ? s + t.amount : s, 0) }))
    .filter(d => d.v > 0).sort((a, b) => b.v - a.v);
  const total = data.reduce((s, d) => s + d.v, 0);
  const seld = data.find(d => d.id === sel) || data[0];
  const top = [...exp].sort((a, b) => b.amount - a.amount).slice(0, 5);
  const netWorth = st.cash.amount + st.assets.reduce((s, a) => s + a.value, 0);
  const sumR = (r, type) => st.tx.reduce((s, t) => t.d >= r[0] && t.d <= r[1] && t.type === type ? s + t.amount : s, 0);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 130 }}>
      <Text style={rs.h1}>گزارش‌ها</Text>
      <Card style={{ padding: 14, marginTop: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <Text style={rs.h2}>دسته‌بندی هزینه‌ها</Text>
          <View style={{ width: 160 }}>
            <Seg v={mode} set={setMode} opts={[{ v: 'day', t: 'روزانه' }, { v: 'month', t: 'ماهانه' }]} />
          </View>
        </View>
        {total > 0 ? <>
          <View style={{ alignItems: 'center' }}>
            <View>
              <Donut data={data} sel={seld?.id} onSel={setSel} />
              <View style={rs.dCenter} pointerEvents="none">
                <Text style={rs.dCat}>{seld?.name}</Text>
                <Text style={rs.dV}>{money(seld?.v || 0)}</Text>
                <Text style={rs.dP}>{fa(Math.round((seld?.v || 0) / total * 100))}٪ از کل</Text>
              </View>
            </View>
          </View>
          <View style={{ marginTop: 14 }}>
            {data.map(d => (
              <View key={d.id} style={rs.lg} onTouchEnd={() => setSel(d.id)}>
                <View style={{ width: 9, height: 9, borderRadius: 3, backgroundColor: d.color }} />
                <Text style={rs.lgN}>{d.name}</Text>
                <View style={{ flex: 1.3 }}><ProgressBar v={d.v} max={total} /></View>
                <Text style={rs.lgV}>{money(d.v)}</Text>
              </View>))}
          </View>
        </> : <Text style={rs.empty}>در این بازه خرجی ثبت نشده</Text>}
      </Card>

      <Text style={[rs.h2, { marginVertical: 12 }]}>پرهزینه‌ترین‌ها — {mode === 'day' ? 'امروز' : monthLabel(0)}</Text>
      <Card>
        {top.map((t, i) => {
          const [, m, dd] = jAgo(t.d);
          return (
            <View key={t.id} style={rs.trow}>
              <View style={rs.rank}><Text style={rs.rankT}>{fa(i + 1)}</Text></View>
              <View style={{ flex: 1 }}>
                <Text style={rs.tn} numberOfLines={1}>{t.note}</Text>
                <Text style={rs.ts}>{fa(dd) + ' ' + FM[m - 1]}</Text>
              </View>
              <Text style={[rs.tv, { color: C.dn }]}>{money(t.amount)}</Text>
            </View>);
        })}
        {!top.length && <Text style={rs.empty}>موردی نیست</Text>}
      </Card>

      <Text style={[rs.h2, { marginVertical: 12 }]}>ویجت خلاصه سریع</Text>
      <View style={rs.widget}>
        <Text style={rs.wLbl}>ارزش خالص دارایی</Text>
        <Text style={rs.wBig}>{money(netWorth)} <Text style={rs.wU}>تومان</Text></Text>
        <View style={rs.wRow}>
          {[['خرج امروز', money(sumR([0, 0], 'expense'))],
            ['خرج این ماه', money(sumR(monthRange(0), 'expense'))],
            ['تراکنش‌ها', fa(st.tx.filter(t => t.d <= 29).length)]].map(x => (
            <View key={x[0]} style={{ flex: 1, borderLeftWidth: 1, borderLeftColor: 'rgba(255,255,255,0.12)', paddingLeft: 10 }}>
              <Text style={rs.wLbl2}>{x[0]}</Text><Text style={rs.wV}>{x[1]}</Text>
            </View>))}
        </View>
      </View>
    </ScrollView>
  );
}
const rs = StyleSheet.create({
  h1: { fontFamily: F.xb, fontSize: 20, color: C.tx },
  h2: { fontFamily: F.xb, fontSize: 14.5, color: C.tx },
  dCenter: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  dCat: { fontFamily: F.b, fontSize: 11, color: C.tx2 }, dV: { fontFamily: F.xb, fontSize: 16, color: C.pd },
  dP: { fontFamily: F.r, fontSize: 10.5, color: C.tx2 },
  lg: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, paddingHorizontal: 4 },
  lgN: { fontFamily: F.b, fontSize: 12.5, color: C.tx, flex: 1 },
  lgV: { fontFamily: F.b, fontSize: 12, color: C.tx, minWidth: 86, textAlign: 'left' },
  empty: { fontFamily: F.r, fontSize: 13, color: C.tx2, textAlign: 'center', paddingVertical: 26 },
  trow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.line },
  rank: { width: 36, height: 36, borderRadius: 12, backgroundColor: C.dnSoft, alignItems: 'center', justifyContent: 'center' },
  rankT: { fontFamily: F.xb, fontSize: 13, color: C.dn },
  tn: { fontFamily: F.b, fontSize: 13.5, color: C.tx }, ts: { fontFamily: F.r, fontSize: 11, color: C.tx2 },
  tv: { fontFamily: F.xb, fontSize: 13.5 },
  widget: { backgroundColor: C.pd, borderRadius: 16, padding: 18 },
  wLbl: { fontFamily: F.b, fontSize: 11.5, color: '#B8B2D9' },
  wBig: { fontFamily: F.xb, fontSize: 24, color: '#fff', marginVertical: 3 },
  wU: { fontFamily: F.b, fontSize: 11.5, color: '#B8B2D9' },
  wRow: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.12)', paddingTop: 14, marginTop: 12 },
  wLbl2: { fontFamily: F.r, fontSize: 10.5, color: '#B8B2D9' }, wV: { fontFamily: F.xb, fontSize: 13.5, color: '#fff' },
});
