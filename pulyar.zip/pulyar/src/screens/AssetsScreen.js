import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { money, parseNum, fa, uid } from '../utils/format';
import { jIn, FM } from '../utils/jalali';
import { Card, Seg, ProgressBar, Sheet, Btn, Inp, Row, Empty } from '../components/ui';
import { Spark } from '../components/charts';

export default function AssetsScreen() {
  const { st, dispatch, toast } = useStore();
  const [tab, setTab] = useState('port');
  const total = st.assets.reduce((s, a) => s + a.value, 0);
  const chg = (st.hist[st.hist.length - 1] - st.hist[0]) / st.hist[0] * 100;
  const [lt, setLt] = useState('pay');
  const [pOpen, setPOpen] = useState(null), [pAmt, setPAmt] = useState('');
  const [aOpen, setAOpen] = useState(false), [pn, setPn] = useState(''), [pnb, setPnb] = useState('');
  const [cOpen, setCOpen] = useState(false), [cn, setCn] = useState('pay'), [ca, setCa] = useState(''), [cd, setCd] = useState('');

  const personTx = () => {
    const a = parseNum(pAmt);
    if (!a || !pOpen) return toast('مبلغ را وارد کن');
    dispatch({ t: 'personTx', id: pOpen.p.id, dir: pOpen.dir, amount: a });
    dispatch({ t: 'addTx', tx: { id: uid(), type: pOpen.dir === 'recv' ? 'income' : 'expense',
      cat: pOpen.dir === 'recv' ? 'income' : 'other',
      note: (pOpen.dir === 'recv' ? 'دریافت از ' : 'پرداخت به ') + pOpen.p.name,
      amount: a, d: 0, src: 'manual', intoCash: true } });
    toast('ثبت شد'); setPOpen(null); setPAmt('');
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 130 }}>
        <Text style={as.h1}>دارایی‌ها</Text>
        <View style={{ marginTop: 14 }}>
          <Seg v={tab} set={setTab} opts={[{ v: 'port', t: 'پورتفوی' }, { v: 'loan', t: 'قسط و وام' },
            { v: 'people', t: 'طلب و بدهی' }, { v: 'check', t: 'چک‌ها' }]} />
        </View>

        {tab === 'port' && <>
          <Card style={{ padding: 16, marginTop: 14 }}>
            <Text style={as.lbl}>ارزش کل پورتفوی غیرنقدی</Text>
            <Text style={as.big}>{money(total)} <Text style={as.unit}>تومان</Text></Text>
            <Text style={{ fontFamily: F.xb, fontSize: 12.5, color: chg >= 0 ? C.ok : C.dn }}>
              {chg >= 0 ? '▲' : '▼'} {money(Math.abs(chg))}٪ در ۳۰ روز گذشته</Text>
            <View style={{ marginTop: 10 }}><Spark pts={st.hist} color={chg >= 0 ? C.ok : C.dn} /></View>
          </Card>
          <Card style={{ marginTop: 14 }}>
            {st.assets.map(a => <Row key={a.id} icon={a.icon} color={a.color} title={a.name} sub={a.unit}
              right={<Text style={as.val}>{money(a.value)}</Text>} />)}
            <Row icon="business" color={C.p} title={'موجودی نقدی — ' + st.cash.bank} sub="قابل برداشت"
              right={<Text style={as.val}>{money(st.cash.amount)}</Text>} />
          </Card>
        </>}

        {tab === 'loan' && <>
          <View style={{ marginTop: 14 }}>
            <Seg v={lt} set={setLt} opts={[{ v: 'pay', t: 'قسط‌های پرداختی' }, { v: 'recv', t: 'دریافتی' }]} />
          </View>
          <Card style={{ marginTop: 12 }}>
            {st.loans.filter(l => l.dir === lt).map(l => (
              <View key={l.id} style={as.item}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={as.name}>{l.name}</Text>
                  <Text style={[as.badge, { color: l.due <= 7 ? C.acc : C.tx2, backgroundColor: l.due <= 7 ? C.accSoft : C.bg }]}>
                    {fa(l.due)} روز تا سررسید</Text>
                </View>
                <Text style={as.sub}>قسط ماهانه {money(l.monthly)} تومان · {l.remain ? fa(l.remain) + ' قسط باقی‌مانده' : 'تسویه‌شده'}</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 9 }}>
                  <View style={{ flex: 1 }}><ProgressBar v={l.paid} max={l.total} /></View>
                  <Text style={as.sub2}>{money(l.paid)} / {money(l.total)}</Text>
                </View>
                {l.remain > 0 && <Btn icon="checkmark" title="ثبت پرداخت قسط این ماه" style={{ marginTop: 12, paddingVertical: 10 }}
                  onPress={() => {
                    dispatch({ t: 'payLoan', id: l.id });
                    dispatch({ t: 'addTx', tx: { id: uid(), type: 'expense', cat: 'bills', note: 'قسط ' + l.name, amount: l.monthly, d: 0, src: 'manual', intoCash: true } });
                    toast('قسط پرداخت شد');
                  }} />}
              </View>))}
            {!st.loans.filter(l => l.dir === lt).length && <Empty icon="repeat" text="موردی ثبت نشده" />}
          </Card>
        </>}

        {tab === 'people' && <>
          <View style={[as.sectH, { marginTop: 16 }]}>
            <Text style={as.h2}>حساب با اشخاص</Text>
            <Text style={as.link} onPress={() => setAOpen(true)}>+ شخص جدید</Text>
          </View>
          <Card>
            {st.people.map(p => {
              const pos = p.balance > 0;
              return (
                <View key={p.id} style={as.item}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                    <View style={[as.avatar, { backgroundColor: pos ? C.ok : C.dn }]}>
                      <Text style={as.avT}>{p.name.trim()[0]}</Text></View>
                    <View style={{ flex: 1 }}>
                      <Text style={as.name}>{p.name}</Text>
                      <Text style={as.sub}>{p.note}</Text>
                      <Text style={{ fontFamily: F.xb, fontSize: 12, color: pos ? C.ok : C.dn, marginTop: 2 }}>
                        {money(p.balance)} تومان {pos ? 'طلب داری' : 'بدهکاری'}</Text>
                    </View>
                    <TouchableOpacity onPress={() => { setPOpen({ p, dir: pos ? 'recv' : 'pay' }); setPAmt(''); }}
                      style={[as.pbtn, { borderColor: pos ? C.ok : C.dn }]}>
                      <Text style={{ fontFamily: F.b, fontSize: 11.5, color: pos ? C.ok : C.dn }}>{pos ? 'دریافت کردم' : 'پرداخت کردم'}</Text>
                    </TouchableOpacity>
                  </View>
                </View>);
            })}
          </Card>
        </>}

        {tab === 'check' && <>
          <View style={[as.sectH, { marginTop: 16 }]}>
            <Text style={as.h2}>سررسید و چک</Text>
            <Text style={as.link} onPress={() => setCOpen(true)}>+ چک جدید</Text>
          </View>
          <Card>
            {[...st.checks].sort((a, b) => a.due - b.due).map(c => {
              const near = c.due <= 7;
              const [, m, dd] = jIn(c.due);
              return <Row key={c.id} icon="business" color={c.dir === 'pay' ? C.dn : C.ok}
                title={c.bank + ' — ' + c.no}
                sub={(c.dir === 'pay' ? 'چک پرداختی ' : 'چک دریافتی ') + money(c.amount) + ' تومان · سررسید ' + fa(dd) + ' ' + FM[m - 1]}
                right={<Text style={[as.badge, { color: near ? C.acc : C.tx2, backgroundColor: near ? C.accSoft : C.bg }]}>{fa(c.due)} روز مانده</Text>} />;
            })}
            {!st.checks.length && <Empty icon="business" text="چکی ثبت نشده" />}
          </Card>
        </>}
      </ScrollView>

      <Sheet open={!!pOpen} onClose={() => setPOpen(null)} title={pOpen ? (pOpen.dir === 'recv' ? 'دریافت از ' : 'پرداخت به ') + pOpen.p.name : ''}>
        <Inp keyboardType="number-pad" value={pAmt} onChangeText={setPAmt} placeholder="مبلغ (تومان)" />
        {parseNum(pAmt) > 0 && <Text style={as.hint}>= {money(parseNum(pAmt))} تومان</Text>}
        <Btn title="ثبت و تسویه" style={{ marginTop: 16 }} onPress={personTx} />
      </Sheet>
      <Sheet open={aOpen} onClose={() => setAOpen(false)} title="افزودن شخص">
        <Inp value={pn} onChangeText={setPn} placeholder="نام شخص" />
        <Inp label="توضیح (اختیاری)" value={pnb} onChangeText={setPnb} placeholder="مثلاً: سهم سفر" />
        <Btn title="افزودن" style={{ marginTop: 16 }} onPress={() => {
          if (!pn.trim()) return toast('نام را وارد کن');
          dispatch({ t: 'addPerson', p: { id: uid(), name: pn.trim(), balance: 0, note: pnb.trim() || '—' } });
          toast('شخص اضافه شد'); setAOpen(false); setPn(''); setPnb('');
        }} />
      </Sheet>
      <Sheet open={cOpen} onClose={() => setCOpen(false)} title="ثبت چک جدید">
        <Seg v={cn} set={setCn} opts={[{ v: 'pay', t: 'پرداختی' }, { v: 'recv', t: 'دریافتی' }]} />
        <Inp label="مبلغ (تومان)" keyboardType="number-pad" value={ca} onChangeText={setCa} />
        <Inp label="سررسید تا چند روز دیگر؟" keyboardType="number-pad" value={cd} onChangeText={setCd} />
        <Btn title="ثبت چک" style={{ marginTop: 16 }} onPress={() => {
          if (!parseNum(ca) || !parseNum(cd)) return toast('مبلغ و سررسید را وارد کن');
          dispatch({ t: 'addCheck', c: { id: uid(), dir: cn, amount: parseNum(ca), due: parseNum(cd), bank: 'بانک ملت', no: 'جدید**' + fa(Math.floor(Math.random() * 900 + 100)) } });
          toast('چک ثبت شد'); setCOpen(false); setCa(''); setCd('');
        }} />
      </Sheet>
    </View>
  );
}
const as = StyleSheet.create({
  h1: { fontFamily: F.xb, fontSize: 20, color: C.tx }, h2: { fontFamily: F.xb, fontSize: 14.5, color: C.tx },
  lbl: { fontFamily: F.b, fontSize: 11.5, color: C.tx2 },
  big: { fontFamily: F.xb, fontSize: 23, color: C.pd, marginVertical: 2 }, unit: { fontFamily: F.b, fontSize: 11.5, color: C.tx2 },
  val: { fontFamily: F.xb, fontSize: 13, color: C.pd },
  item: { padding: 16, borderBottomWidth: 1, borderBottomColor: C.line },
  name: { fontFamily: F.b, fontSize: 13.5, color: C.tx },
  sub: { fontFamily: F.r, fontSize: 11, color: C.tx2, marginTop: 2 },
  sub2: { fontFamily: F.r, fontSize: 10.5, color: C.tx2 },
  badge: { fontFamily: F.b, fontSize: 10.5, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 8, overflow: 'hidden' },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  avT: { color: '#fff', fontFamily: F.xb, fontSize: 16 },
  pbtn: { borderWidth: 1.5, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7 },
  sectH: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  link: { fontFamily: F.b, fontSize: 12.5, color: C.acc },
  hint: { fontFamily: F.r, fontSize: 11.5, color: C.tx2, marginTop: 6 },
});
