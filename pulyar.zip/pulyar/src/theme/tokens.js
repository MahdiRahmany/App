export const C = {
  pd: '#1B1447', p: '#2A1F6E', acc: '#FF6B47', bg: '#F5F5F8', card: '#FFFFFF',
  dn: '#E53935', ok: '#2E7D32', tx: '#221A3F', tx2: '#8B87A0', line: '#ECEBF2',
  accSoft: 'rgba(255,107,71,0.10)', okSoft: 'rgba(46,125,50,0.10)', dnSoft: 'rgba(229,57,53,0.08)',
};
export const F = { r: 'Vazirmatn_400Regular', b: 'Vazirmatn_700Bold', xb: 'Vazirmatn_800ExtraBold' };
export const SH = { shadowColor: '#1B1447', shadowOpacity: 0.07, shadowRadius: 16, shadowOffset: { width: 0, height: 4 }, elevation: 2 };
