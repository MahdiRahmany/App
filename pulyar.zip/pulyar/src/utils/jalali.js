import { fa } from './format';

export const FM = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

export function toJalali(gy, gm, gd) {
  const G = [0,31,59,90,120,151,181,212,243,273,304,334];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100)
    + Math.floor((gy2 + 399) / 400) - 80 + gd + G[gm - 1];
  jy += 33 * Math.floor(days / 12053); days %= 12053;
  jy += 4 * Math.floor(days / 1461); days %= 1461;
  if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}
const jOf = d => toJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
export const jNow = () => jOf(new Date());
export const jAgo = n => { const x = new Date(); x.setDate(x.getDate() - n); return jOf(x); };
export const jIn = n => jAgo(-n); // n روز در آینده
export const jDate = d => { const [, m, dd] = jAgo(d); return fa(dd) + ' ' + FM[m - 1]; };
export const jFull = d => { const [y, m, dd] = jAgo(d); return fa(dd) + ' ' + FM[m - 1] + ' ' + fa(y); };
export const todayLabel = () => { const [y, m, d] = jNow(); return fa(d) + ' ' + FM[m - 1] + ' ' + fa(y); };
export const mLen = m => (m <= 6 ? 31 : m <= 11 ? 30 : 29);
const mOf = i => { const [, jm] = jNow(); return (((jm - 1 - i) % 12) + 12) % 12 + 1; };
const startBack = k => { let s = 0; for (let i = 0; i < k; i++) s += mLen(mOf(i)); return s; };
export function monthRange(k) {
  const [, jm, jd] = jNow();
  if (k === 0) return [0, jd - 1];
  const st = jd - 1 + startBack(k);
  return [st, st + startBack(k + 1) - startBack(k) - 1];
}
export function monthLabel(k) {
  const [jy, jm] = jNow();
  const t = (jm - 1) - k;
  return FM[((t % 12) + 12) % 12] + ' ' + fa(jy + Math.floor(t / 12));
}
