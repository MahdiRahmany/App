const FA = '۰۱۲۳۴۵۶۷۸۹';
export const fa = s => String(s).replace(/\d/g, d => FA[+d]);
export const grp = n => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
export const money = n => fa(grp(Math.abs(n)));
export const moneySign = (n, inc) => (inc ? '+' : '−') + money(n);
export const parseNum = s => {
  const d = String(s).replace(/[۰-۹]/g, c => String(FA.indexOf(c))).replace(/[^\d]/g, '');
  return Number(d) || 0;
};
export const uid = () => 'x' + Math.random().toString(36).slice(2, 9);
