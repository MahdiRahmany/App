const BANK_WORDS = ['بانک','ملت','ملی','صادرات','پاسارگاد','سامان','سپه','تجارت','رسالت','کشاورزی','مسکن','آینده','سینا','iran','bpi'];
const fa2en = s => String(s).replace(/[۰-۹]/g, c => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c));

/** پیامک بانکی را به تراکنش تبدیل می‌کند — قواعد ساده و قابل توسعه */
export function parseBankSms(body) {
  const t = fa2en(body || '');
  if (!BANK_WORDS.some(b => t.includes(b))) return null;
  const dep = /واریز[^\d]*([\d,]{3,})/.exec(t);
  const wit = /(?:برداشت|خرید|پرداخت|خرج)[^\d]*([\d,]{3,})/.exec(t);
  const num = m => Number((m ? m[1] : '').replace(/,/g, '')) || 0;
  const bank = (BANK_WORDS.find(b => t.includes(b)) || 'بانک');
  if (dep && dep[1].length >= 3)
    return { type: 'income', amount: num(dep), note: 'واریز — ' + bank };
  if (wit && wit[1].length >= 3)
    return { type: 'expense', amount: num(wit), note: 'برداشت/خرید — ' + bank };
  return null;
}
