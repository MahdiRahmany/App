import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, F } from '../theme/tokens';
import { moneySign } from '../utils/format';
import { jDate } from '../utils/jalali';

export default function TxRow({ tx, cat, onPress }) {
  const inc = tx.type === 'income';
  return (
    <TouchableOpacity activeOpacity={.7} onPress={onPress} style={tr.row}>
      <View style={[tr.ico, { backgroundColor: cat.color + '1a' }]}>
        <Ionicons name={cat.icon} size={18} color={cat.color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={tr.t} numberOfLines={1}>{tx.note || cat.name}</Text>
        <Text style={tr.s}>{jDate(tx.d)} · {tx.src === 'sms' ? 'پیامک بانک' : 'ثبت دستی'}</Text>
      </View>
      <Text style={[tr.a, { color: inc ? C.ok : C.dn }]}>{moneySign(tx.amount, inc)}</Text>
    </TouchableOpacity>
  );
}
const tr = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.line },
  ico: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  t: { fontFamily: F.b, fontSize: 13.5, color: C.tx },
  s: { fontFamily: F.r, fontSize: 11, color: C.tx2 },
  a: { fontFamily: F.xb, fontSize: 13.5 },
});
