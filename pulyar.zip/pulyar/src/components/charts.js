import React from 'react';
import Svg, { Rect, Circle, Path } from 'react-native-svg';
import { C } from '../theme/tokens';

export function Bars({ vals, picked, onPick, W = 330, H = 96 }) {
  const max = Math.max(...vals, 1);
  const step = W / vals.length;
  return (
    <Svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`}>
      {vals.map((v, i) => {
        const h = (v / max) * (H - 16);
        const bw = Math.max(step - 3, 2.5);
        return <Rect key={i} x={W - (i + 1) * step + 1.5} y={H - 6 - h} width={bw}
          height={Math.max(h, v > 0 ? 4 : 2)} rx={Math.min(4, bw / 2)}
          fill={picked === i ? C.acc : (v > 0 ? '#D9D7E6' : '#ECEBF2')}
          onPress={() => onPick && onPick(i)} />;
      })}
    </Svg>
  );
}

export function Donut({ data, sel, onSel, size = 190 }) {
  const total = data.reduce((s, d) => s + d.v, 0) || 1;
  const R = 62, CIRC = 2 * Math.PI * R;
  let acc = 0;
  return (
    <Svg width={size} height={size} viewBox="0 0 160 160">
      {data.map(d => {
        const f = d.v / total;
        const el = <Circle key={d.id} cx={80} cy={80} r={R} fill="none" stroke={d.color}
          strokeWidth={sel === d.id ? 26 : 16}
          strokeDasharray={`${Math.max(f * CIRC - 2.5, 0.5)} ${CIRC}`}
          strokeDashoffset={-acc * CIRC - 1.2}
          transform="rotate(-90 80 80)" opacity={sel && sel !== d.id ? 0.35 : 1}
          onPressIn={() => onSel(d.id)} />;
        acc += f;
        return el;
      })}
    </Svg>
  );
}

export function Spark({ pts, W = 330, H = 88, color = C.ok }) {
  const max = Math.max(...pts), min = Math.min(...pts);
  const X = i => W - (i / (pts.length - 1)) * W;
  const Y = v => H - 10 - ((v - min) / ((max - min) || 1)) * (H - 24);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(p).toFixed(1)}`).join(' ');
  return (
    <Svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`}>
      <Path d={`${d} L${W} ${H} L0 ${H} Z`} fill={color} opacity={0.07} />
      <Path d={d} stroke={color} strokeWidth={2.5} fill="none" strokeLinecap="round" />
      <Circle cx={X(pts.length - 1)} cy={Y(pts[pts.length - 1])} r={4} fill={color} />
    </Svg>
  );
}
