import React from 'react';
import { View, Text, TextInput, TouchableOpacity, Modal, Switch, StyleSheet, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, F, SH } from '../theme/tokens';
import { fa } from '../utils/format';

export const Card = ({ children, style }) => <View style={[st.card, SH, style]}>{children}</View>;

export const Btn = ({ title, onPress, icon, ghost, dark, style, txtStyle }) => (
  <TouchableOpacity onPress={onPress} activeOpacity={.85} style={[st.btn, ghost && st.btnG, dark && { backgroundColor: C.pd }, style]}>
    {!!icon && <Ionicons name={icon} size={17} color={ghost ? C.tx2 : '#fff'} />}
    <Text style={[st.btnT, ghost && { color: C.tx2 }, txtStyle]}>{title}</Text>
  </TouchableOpacity>
);

export const Chip = ({ on, onPress, children, color }) => (
  <TouchableOpacity onPress={onPress} style={[st.chip, on && { borderColor: color || C.acc, backgroundColor: (color || C.acc) + '14' }]}>
    <Text style={[st.chipT, on && { color: color || C.acc }]}>{children}</Text>
  </TouchableOpacity>
);

export const Seg = ({ v, set, opts }) => (
  <View style={st.seg}>
    {opts.map(o => (
      <TouchableOpacity key={o.v} onPress={() => set(o.v)} style={[st.segB, v === o.v && st.segOn]}>
        <Text style={[st.segT, v === o.v && { color: C.tx }]}>{o.t}</Text>
      </TouchableOpacity>))}
  </View>
);

export const Inp = ({ label, ...p }) => (
  <View>{!!label && <Text style={st.lbl}>{label}</Text>}
    <TextInput style={st.inp} placeholderTextColor={C.tx2} {...p} /></View>
);

export const Sw = ({ v, set }) => (
  <Switch value={v} onValueChange={set} trackColor={{ true: C.acc, false: '#D8D6E4' }} thumbColor="#fff" />
);

export const ProgressBar = ({ v, max }) => {
  const pc = Math.min(100, max > 0 ? (v / max) * 100 : 0);
  return <View style={st.pbar}><View style={[st.pfill, { width: pc + '%' }]} /></View>;
};

export const Sheet = ({ open, onClose, title, children }) => (
  <Modal visible={open} transparent animationType="slide" onRequestClose={onClose}>
    <Pressable style={st.ovl} onPress={onClose}>
      <Pressable style={st.sheet} onPress={() => {}}>
        <View style={st.shH}>
          <Text style={st.shT}>{title}</Text>
          <TouchableOpacity onPress={onClose} style={st.shX}><Ionicons name="close" size={17} color={C.tx2} /></TouchableOpacity>
        </View>
        {children}
      </Pressable>
    </Pressable>
  </Modal>
);

export const Row = ({ icon, color, title, sub, right, onPress }) => {
  const B = <View style={st.rowli}>
    <View style={[st.tico, { backgroundColor: color + '1a' }]}><Ionicons name={icon} size={18} color={color} /></View>
    <View style={{ flex: 1 }}>
      <Text style={st.rowT}>{title}</Text>
      {!!sub && <Text style={st.rowS}>{sub}</Text>}
    </View>
    {right}
  </View>;
  return onPress ? <TouchableOpacity activeOpacity={.7} onPress={onPress}>{B}</TouchableOpacity> : B;
};

export const StackHeader = ({ title, onBack, right }) => (
  <View style={st.stk}>
    <TouchableOpacity onPress={onBack} style={st.bk}><Ionicons name="arrow-forward" size={17} color={C.tx} /></TouchableOpacity>
    <Text style={st.stkT}>{title}</Text>
    {right || <View style={{ width: 36 }} />}
  </View>
);

export const Empty = ({ icon, text }) => (
  <View style={st.empty}>
    <View style={st.emptyIc}><Ionicons name={icon} size={26} color={C.tx2} /></View>
    <Text style={st.emptyT}>{text}</Text>
  </View>
);

export const Dots = ({ n }) => (
  <View style={st.dots}>{[0, 1, 2, 3].map(i => <View key={i} style={[st.dot, n > i && st.dotOn]} />)}</View>
);

export const Keypad = ({ onKey }) => (
  <View style={st.keypad}>
    {['1','2','3','4','5','6','7','8','9','','0','del'].map((k, i) =>
      k === '' ? <View key={i} /> :
      <TouchableOpacity key={i} style={st.key} onPress={() => onKey(k)} activeOpacity={.7}>
        {k === 'del'
          ? <Ionicons name="chevron-back" size={22} color={C.tx} />
          : <Text style={st.keyT}>{fa(k)}</Text>}
      </TouchableOpacity>)}
  </View>
);

export const Toast = ({ msg }) => !msg ? null : (
  <View style={st.toast} pointerEvents="none"><Text style={st.toastT}>{msg}</Text></View>
);

const st = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 16 },
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: C.acc, borderRadius: 14, paddingVertical: 14 },
  btnG: { backgroundColor: 'transparent' },
  btnT: { color: '#fff', fontFamily: F.xb, fontSize: 15 },
  chip: { borderWidth: 1.5, borderColor: C.line, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 7 },
  chipT: { fontFamily: F.b, fontSize: 12.5, color: C.tx2 },
  seg: { flexDirection: 'row', backgroundColor: '#ECEBF3', borderRadius: 12, padding: 4 },
  segB: { flex: 1, paddingVertical: 8, borderRadius: 9, alignItems: 'center' },
  segOn: { backgroundColor: '#fff', borderRadius: 9 },
  segT: { fontFamily: F.b, fontSize: 12.5, color: C.tx2 },
  lbl: { fontFamily: F.b, fontSize: 12, color: C.tx2, marginTop: 14, marginBottom: 7 },
  inp: { backgroundColor: C.bg, borderWidth: 1.5, borderColor: C.line, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, color: C.tx, fontFamily: F.r, textAlign: 'right' },
  pbar: { height: 8, borderRadius: 6, backgroundColor: '#EDECF3', overflow: 'hidden' },
  pfill: { height: '100%', borderRadius: 6, backgroundColor: C.acc },
  ovl: { flex: 1, backgroundColor: 'rgba(27,20,71,0.45)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#fff', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 18, paddingBottom: 40 },
  shH: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  shT: { fontFamily: F.xb, fontSize: 15.5, color: C.tx },
  shX: { width: 32, height: 32, borderRadius: 10, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' },
  rowli: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 13, borderBottomWidth: 1, borderBottomColor: C.line },
  tico: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  rowT: { fontFamily: F.b, fontSize: 13.5, color: C.tx },
  rowS: { fontFamily: F.r, fontSize: 11, color: C.tx2, marginTop: 1 },
  stk: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingVertical: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: C.line },
  bk: { width: 36, height: 36, borderRadius: 11, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' },
  stkT: { flex: 1, fontFamily: F.xb, fontSize: 16, color: C.tx },
  empty: { alignItems: 'center', paddingVertical: 34 },
  emptyIc: { width: 64, height: 64, borderRadius: 20, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  emptyT: { fontFamily: F.r, fontSize: 13, color: C.tx2, textAlign: 'center', paddingHorizontal: 20 },
  dots: { flexDirection: 'row', gap: 14, justifyContent: 'center' },
  dot: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#E3E1EE' },
  dotOn: { backgroundColor: C.acc },
  keypad: { flexDirection: 'row', flexWrap: 'wrap', alignSelf: 'center', maxWidth: 290, gap: 12, marginTop: 16 },
  key: { width: 88, height: 58, borderRadius: 18, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...SH },
  keyT: { fontFamily: F.xb, fontSize: 21, color: C.tx },
  toast: { position: 'absolute', bottom: 110, alignSelf: 'center', backgroundColor: C.pd, borderRadius: 14, paddingHorizontal: 20, paddingVertical: 11, zIndex: 99, maxWidth: '90%' },
  toastT: { color: '#fff', fontFamily: F.b, fontSize: 13, textAlign: 'center' },
});
