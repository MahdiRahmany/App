import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../store/Store';
import { C, F } from '../theme/tokens';
import { Keypad, Dots } from './ui';

export default function LockScreen({ onUnlock }) {
  const { st, toast } = useStore();
  const [pin, setPin] = useState('');

  const onKey = k => {
    if (k === 'del') return setPin(p => p.slice(0, -1));
    const p = pin + k;
    if (p.length > 4) return;
    if (p.length === 4) {
      if (p === st.pin) return onUnlock();
      toast('پین اشتباه است'); setPin('');
    } else setPin(p);
  };

  const bio = async () => {
    try {
      const ok = await LocalAuthentication.hasHardwareAsync() && await LocalAuthentication.isEnrolledAsync();
      if (!ok) return toast('اثر انگشت روی دستگاه ثبت نشده');
      const r = await LocalAuthentication.authenticateAsync({ promptMessage: 'باز کردن پول‌یار' });
      if (r.success) onUnlock(); else toast('تأیید ناموفق بود');
    } catch (e) { toast('خطا در بایومتریک'); }
  };

  return (
    <View style={ls.wrap}>
      <View style={ls.logo}><Ionicons name="wallet" size={30} color="#fff" /></View>
      <Text style={ls.h}>پول‌یار قفله</Text>
      <Text style={ls.p}>پین ۴ رقمی‌ات را وارد کن</Text>
      <View style={{ marginTop: 26 }}><Dots n={pin.length} /></View>
      <Keypad onKey={onKey} />
      {!!st.bio && (
        <TouchableOpacity onPress={bio} style={ls.bio}>
          <Ionicons name="finger-print" size={22} color={C.acc} />
          <Text style={ls.bioT}> ورود با اثر انگشت</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}
const ls = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: C.bg, justifyContent: 'center', padding: 24 },
  logo: { width: 70, height: 70, borderRadius: 24, backgroundColor: C.pd, alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: 16 },
  h: { fontFamily: F.xb, fontSize: 18, color: C.tx, textAlign: 'center' },
  p: { fontFamily: F.r, fontSize: 12.5, color: C.tx2, textAlign: 'center', marginTop: 6 },
  bio: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 24 },
  bioT: { fontFamily: F.b, fontSize: 14, color: C.acc },
});
