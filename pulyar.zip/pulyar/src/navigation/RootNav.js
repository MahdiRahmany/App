import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { C, F } from '../theme/tokens';
import HomeScreen from '../screens/HomeScreen';
import ReportsScreen from '../screens/ReportsScreen';
import BudgetScreen from '../screens/BudgetScreen';
import AssetsScreen from '../screens/AssetsScreen';
import SettingsScreen from '../screens/SettingsScreen';
import SearchScreen from '../screens/SearchScreen';
import NewTxScreen from '../screens/NewTxScreen';
import CategoriesScreen from '../screens/CategoriesScreen';
import ReminderScreen from '../screens/ReminderScreen';
import SecurityScreen from '../screens/SecurityScreen';
import BackupScreen from '../screens/BackupScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const TABS = [
  ['home', 'خانه', 'home'], ['reports', 'گزارش‌ها', 'stats-chart'],
  ['budget', 'بودجه', 'wallet'], ['assets', 'دارایی‌ها', 'cash'], ['settings', 'تنظیمات', 'settings'],
];

function TabBar({ state, navigation }) {
  const inset = useSafeAreaInsets();
  const item = ([n, l, ic]) => {
    const on = state.routes[state.index]?.name === n;
    return (
      <TouchableOpacity key={n} style={{ flex: 1, alignItems: 'center', gap: 3 }} onPress={() => navigation.navigate(n)}>
        <Ionicons name={ic} size={21} color={on ? C.acc : '#A5A1B8'} />
        <Text style={[tb.t, on && { color: C.acc }]}>{l}</Text>
      </TouchableOpacity>
    );
  };
  return (
    <View style={[tb.bar, { paddingBottom: inset.bottom + 6 }]}>
      {TABS.slice(0, 2).map(item)}
      <TouchableOpacity style={tb.fab} activeOpacity={.85} onPress={() => navigation.navigate('newtx')}>
        <Ionicons name="add" size={26} color="#fff" />
      </TouchableOpacity>
      {TABS.slice(2).map(item)}
    </View>
  );
}

function Tabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }} tabBar={p => <TabBar {...p} />}>
      <Tab.Screen name="home" component={HomeScreen} />
      <Tab.Screen name="reports" component={ReportsScreen} />
      <Tab.Screen name="budget" component={BudgetScreen} />
      <Tab.Screen name="assets" component={AssetsScreen} />
      <Tab.Screen name="settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function RootNav() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="tabs" component={Tabs} />
        <Stack.Screen name="search" component={SearchScreen} />
        <Stack.Screen name="newtx" component={NewTxScreen} />
        <Stack.Screen name="cats" component={CategoriesScreen} />
        <Stack.Screen name="reminder" component={ReminderScreen} />
        <Stack.Screen name="security" component={SecurityScreen} />
        <Stack.Screen name="backup" component={BackupScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const tb = StyleSheet.create({
  bar: { flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: C.line, paddingTop: 8, alignItems: 'flex-start' },
  t: { fontFamily: F.b, fontSize: 10, color: '#A5A1B8' },
  fab: { width: 52, height: 52, borderRadius: 18, backgroundColor: C.acc, alignItems: 'center', justifyContent: 'center', marginTop: -26, elevation: 6 },
});
