# پول‌یار — مدیریت مالی شخصی (React Native / Expo)

اپلیکیشن فارسی مدیریت مالی شخصی با پشتیبانی RTL، تقویم جلالی، خواندن پیامک بانکی (فقط اندروید با development build)، بودجه، دارایی، وام و چک.

## پیش‌نیازها روی ویندوز

1. **Node.js** نسخه ۱۸ یا ۲۰ (LTS)  
   از https://nodejs.org نصب کنید.

2. **npm** (همراه Node می‌آید)

3. برای تست روی گوشی اندروید:
   - اپ **Expo Go** را از Google Play نصب کنید  
   - یا برای قابلیت SMS: development build بسازید (نیاز به Android Studio)

4. (اختیاری) **Android Studio** اگر می‌خواهید `expo run:android` بزنید.

## اجرا روی ویندوز (با داده نمونه — بدون نیاز به SMS)

در **PowerShell** یا **Command Prompt**:

```powershell
cd مسیر\به\پوشه\pulyar

npm install

npx expo start -c
```

بعد از بالا آمدن سرور:

- با گوشی اندروید: اپ **Expo Go** را باز کنید و QR کد را اسکن کنید.
- یا در ترمینال `a` بزنید (اگر emulator اندروید آماده باشد).
- یا `w` برای وب (محدود — بعضی قابلیت‌های native کار نمی‌کند).

### نکته مهم درباره SMS

ماژول خواندن پیامک (`expo-pulyar-sms`) فقط روی **Android development build** کار می‌کند و در **Expo Go** موجود نیست.  
برای تست کامل SMS باید:

```powershell
npx expo prebuild
npx expo run:android
```

(نیاز به Android Studio و SDK دارد.)

در حالت عادی با دادهٔ نمونه (seed) اپ کامل کار می‌کند.

## ساختار پروژه

- `src/screens/` — صفحات اصلی
- `src/store/Store.js` — state و داده نمونه
- `src/utils/smsParser.js` — پارس پیامک بانکی
- `modules/expo-pulyar-sms/` — ماژول native اندروید
- `plugins/withSmsPermissions.js` — افزودن permissionهای SMS

## دستورات مفید

```powershell
npm start          # همان expo start -c
npx expo start -c  # پاک کردن کش و شروع
npx expo doctor    # بررسی سلامت پروژه
```

داده‌ها فقط روی دستگاه (AsyncStorage) ذخیره می‌شوند و به سرور ارسال نمی‌شوند.
