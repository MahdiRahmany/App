export const colors = {
  primaryDark: '#1B1447',
  primary: '#2A1F6E',
  accent: '#FF6B47',
  background: '#F5F5F8',
  cardWhite: '#FFFFFF',
  danger: '#E53935',
  success: '#2E7D32',
  warning: '#F59E0B',
  text: '#1B1B24',
  muted: '#75758A',
  border: '#E7E7EF',
  white: '#FFFFFF',
  black: '#000000',
  lilac: '#EDEBFF',
  softOrange: '#FFF0EC',
  softGreen: '#EAF6EC',
  softRed: '#FDECEC',
  softBlue: '#EEF3FF',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const radius = {
  card: 16,
  button: 14,
  pill: 999,
};

export const typography = {
  regular: 'Vazirmatn_400Regular',
  bold: 'Vazirmatn_700Bold',
};

export const shadow = {
  card: {
    shadowColor: '#111122',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.07,
    shadowRadius: 12,
    elevation: 3,
  },
};
