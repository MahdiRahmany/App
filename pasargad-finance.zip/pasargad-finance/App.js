import React, { useEffect } from 'react';
import { I18nManager, StyleSheet, Text } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useFonts, Vazirmatn_400Regular, Vazirmatn_700Bold } from '@expo-google-fonts/vazirmatn';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import RootNavigator from './navigation/RootNavigator';
import { colors, typography } from './theme';

I18nManager.allowRTL(true);
I18nManager.forceRTL(true);

function Boot() {
  const [loaded] = useFonts({
    Vazirmatn_400Regular,
    Vazirmatn_700Bold,
  });
  const { nightMode } = useFinance();

  useEffect(() => {
    // Font loading is handled before the navigator renders.
  }, [loaded]);

  if (!loaded) return <Text style={styles.loading}>در حال آماده‌سازی پول‌یار…</Text>;

  return (
    <>
      <StatusBar style={nightMode ? 'light' : 'dark'} />
      <RootNavigator />
    </>
  );
}

export default function App() {
  return (
    <FinanceProvider>
      <Boot />
    </FinanceProvider>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    backgroundColor: colors.background,
    color: colors.primaryDark,
    fontFamily: typography.bold,
    fontSize: 18,
    textAlign: 'center',
    textAlignVertical: 'center',
    paddingHorizontal: 24,
  },
});
