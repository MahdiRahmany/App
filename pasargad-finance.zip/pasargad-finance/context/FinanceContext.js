import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { initialState } from '../data/mock';
import { loadState, saveState } from '../services/storage';
import { scheduleFinanceReminder } from '../services/notifications';

const FinanceContext = createContext(null);

export function FinanceProvider({ children }) {
  const [data, setData] = useState(initialState);
  const [hydrated, setHydrated] = useState(false);
  const [sessionUnlocked, setSessionUnlocked] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const saved = await loadState();
        if (saved) setData({ ...initialState, ...saved });
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveState(data).catch(() => {});
  }, [data, hydrated]);

  const patch = useCallback((partial) => {
    setData((current) => ({ ...current, ...partial }));
  }, []);

  const addTransaction = useCallback((transaction) => {
    setData((current) => ({
      ...current,
      transactions: [transaction, ...current.transactions],
    }));
  }, []);

  const addBudget = useCallback((budget) => {
    setData((current) => ({
      ...current,
      budgets: [budget, ...current.budgets],
    }));
  }, []);

  const resetDemo = useCallback(() => {
    setData({ ...initialState, onboardingDone: true, pin: data.pin, biometricEnabled: data.biometricEnabled });
  }, [data.pin, data.biometricEnabled]);

  const scheduleReminder = useCallback(async (nextData = data) => {
    await scheduleFinanceReminder({
      enabled: nextData.reminderEnabled,
      period: nextData.reminderPeriod,
      time: nextData.reminderTime,
    });
  }, [data]);

  const value = useMemo(() => ({
    ...data,
    hydrated,
    sessionUnlocked,
    setSessionUnlocked,
    patch,
    addTransaction,
    addBudget,
    resetDemo,
    scheduleReminder,
  }), [data, hydrated, sessionUnlocked, patch, addTransaction, addBudget, resetDemo, scheduleReminder]);

  return <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>;
}

export function useFinance() {
  const context = useContext(FinanceContext);
  if (!context) throw new Error('useFinance must be used inside FinanceProvider');
  return context;
}
