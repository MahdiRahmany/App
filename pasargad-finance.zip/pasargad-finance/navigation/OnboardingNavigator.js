import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { colors } from '../theme';
import { OnboardingWelcome, OnboardingPin, OnboardingReminder, OnboardingTrial } from '../screens/OnboardingScreen';

const Stack = createNativeStackNavigator();

export default function OnboardingNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}>
      <Stack.Screen name="Welcome" component={OnboardingWelcome} />
      <Stack.Screen name="Pin" component={OnboardingPin} />
      <Stack.Screen name="Reminder" component={OnboardingReminder} />
      <Stack.Screen name="Trial" component={OnboardingTrial} />
    </Stack.Navigator>
  );
}
