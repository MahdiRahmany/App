import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography } from '../theme';
import HomeScreen from '../screens/HomeScreen';
import ReportsScreen from '../screens/ReportsScreen';
import BudgetScreen from '../screens/BudgetScreen';
import AssetsScreen from '../screens/AssetsScreen';
import SettingsScreen from '../screens/SettingsScreen';
import AddTransactionScreen from '../screens/AddTransactionScreen';
import AddBudgetScreen from '../screens/AddBudgetScreen';
import PersonDetailScreen from '../screens/PersonDetailScreen';
import CategoriesScreen from '../screens/CategoriesScreen';
import BackupScreen from '../screens/BackupScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function AppTabs() {
  const tabs = [
    { name: 'Home', title: 'خانه', icon: 'home-outline', active: 'home' },
    { name: 'Reports', title: 'گزارش‌ها', icon: 'pie-chart-outline', active: 'pie-chart' },
    { name: 'Budget', title: 'بودجه', icon: 'speedometer-outline', active: 'speedometer' },
    { name: 'Assets', title: 'دارایی‌ها', icon: 'trending-up-outline', active: 'trending-up' },
    { name: 'Settings', title: 'تنظیمات', icon: 'settings-outline', active: 'settings' },
  ];
  return (
    <Tab.Navigator
      screenOptions={({ route }) => {
        const item = tabs.find((tab) => tab.name === route.name);
        return {
          headerShown: false,
          tabBarActiveTintColor: colors.accent,
          tabBarInactiveTintColor: '#9696A8',
          tabBarStyle: { height: 68, paddingBottom: 8, paddingTop: 6, backgroundColor: colors.white, borderTopColor: colors.border },
          tabBarLabelStyle: { fontFamily: typography.regular, fontSize: 10 },
          tabBarIcon: ({ color, focused }) => <Ionicons name={focused ? item.active : item.icon} color={color} size={22} />,
        };
      }}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarLabel: 'خانه' }} />
      <Tab.Screen name="Reports" component={ReportsScreen} options={{ tabBarLabel: 'گزارش‌ها' }} />
      <Tab.Screen name="Budget" component={BudgetScreen} options={{ tabBarLabel: 'بودجه' }} />
      <Tab.Screen name="Assets" component={AssetsScreen} options={{ tabBarLabel: 'دارایی‌ها' }} />
      <Tab.Screen name="Settings" component={SettingsScreen} options={{ tabBarLabel: 'تنظیمات' }} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}>
      <Stack.Screen name="Tabs" component={AppTabs} />
      <Stack.Screen name="AddTransaction" component={AddTransactionScreen} />
      <Stack.Screen name="AddBudget" component={AddBudgetScreen} />
      <Stack.Screen name="PersonDetail" component={PersonDetailScreen} />
      <Stack.Screen name="Categories" component={CategoriesScreen} />
      <Stack.Screen name="Backup" component={BackupScreen} />
    </Stack.Navigator>
  );
}
