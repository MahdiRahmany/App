import React from 'react';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import AppNavigator from './AppNavigator';
import OnboardingNavigator from './OnboardingNavigator';
import LockScreen from '../screens/LockScreen';
import { colors } from '../theme';
import { useFinance } from '../context/FinanceContext';

const lightTheme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: colors.background, card: colors.white, primary: colors.accent, text: colors.text, border: colors.border },
};

const darkTheme = {
  ...DarkTheme,
  colors: { ...DarkTheme.colors, background: '#13121B', card: '#1B1A25', primary: colors.accent, text: '#F6F5FB', border: '#2D2B38' },
};

export default function RootNavigator() {
  const { onboardingDone, hydrated, pin, sessionUnlocked, nightMode } = useFinance();

  if (!hydrated) return null;

  const root = !onboardingDone ? <OnboardingNavigator /> : (pin && !sessionUnlocked ? <LockScreen /> : <AppNavigator />);

  return <NavigationContainer theme={nightMode ? darkTheme : lightTheme}>{root}</NavigationContainer>;
}
