# پول‌یار — اپلیکیشن مدیریت مالی شخصی فارسی (RTL)

یک نمونه‌ی اجرایی React Native + Expo با معماری کامپوننت‌محور، RTL کامل، داده‌ی Mock فارسی و ذخیره‌سازی آفلاین.

## اجرا

```bash
npm install
npx expo start
```

برای اندروید:

```bash
npx expo run:android
```

برای iOS:

```bash
npx expo run:ios
```

برای وب:

```bash
npx expo start --web
```

## نکات مهم

- پروژه بر پایه‌ی Expo SDK 57 و React Native 0.86.3 تنظیم شده است.
- فونت Vazirmatn از پکیج `@expo-google-fonts/vazirmatn` استفاده می‌شود و در build از طریق `expo-font` قابل embed شدن است.
- داده‌ها با AsyncStorage ذخیره می‌شوند و اپ بدون backend نیز قابل استفاده است.
- مسیر پشتیبان‌گیری JSON از فایل محلی + DocumentPicker + Share استفاده می‌کند.
- قفل PIN و بیومتریک با `expo-local-authentication` پیاده‌سازی شده است. در این نمونه، PIN در AsyncStorage ذخیره می‌شود؛ برای محصول بانکی واقعی باید Secret/Key یا SecureStore و سخت‌سازی بیشتری اضافه شود.
- «خواندن پیامک بانکی» فقط UI و flow درخواست را دارد. Expo API رسمی `expo-sms` برای خواندن SMS طراحی نشده و صرفاً برای ارسال SMS است؛ بنابراین این پروژه تراکنش‌های Mock و ثبت دستی را جایگزین می‌کند. برای خواندن واقعی SMS در Android باید native module اختصاصی، مجوزهای حساس Android و الزامات انتشار فروشگاه را جداگانه پیاده‌سازی کنید.
- یادآور روزانه/هفتگی با local notification قابل زمان‌بندی است.

## ساختار

```text
components/
data/
navigation/
screens/
services/
theme/
utils/
App.js
```

## ریست داده‌ی Demo

در تنظیمات اپ، گزینه‌ی «بازنشانی داده‌های نمونه» قرار دارد تا وضعیت اولیه‌ی داده‌ها برگردد.
