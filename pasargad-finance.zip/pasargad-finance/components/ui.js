import React from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import Svg, { Circle, Line, Polyline, Rect } from 'react-native-svg';
import { colors, radius, shadow, spacing, typography } from '../theme';
import { formatToman } from '../utils/format';

export function Screen({ children, style, scroll = true }) {
  const body = <View style={[styles.screen, style]}>{children}</View>;
  return scroll ? (
    <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>{body}</ScrollView>
  ) : body;
}

export function PageHeader({ title, subtitle, onBack, right }) {
  return (
    <View style={styles.header}>
      <View style={styles.headerMain}>
        {onBack ? (
          <Pressable onPress={onBack} style={styles.iconButton}>
            <Ionicons name="chevron-forward" size={24} color={colors.text} />
          </Pressable>
        ) : null}
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{title}</Text>
          {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        </View>
        {right || <View style={{ width: 42 }} />}
      </View>
    </View>
  );
}

export function Card({ children, style, padding = spacing.lg }) {
  return <View style={[styles.card, { padding }, style]}>{children}</View>;
}

export function Button({ children, onPress, variant = 'primary', icon, disabled = false, style }) {
  const isOutline = variant === 'outline';
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.button,
        isOutline ? styles.buttonOutline : styles.buttonPrimary,
        pressed && { opacity: 0.85 },
        disabled && { opacity: 0.45 },
        style
      ]}
    >
      {icon ? <Ionicons name={icon} size={18} color={isOutline ? colors.accent : colors.white} /> : null}
      <Text style={[styles.buttonText, isOutline && { color: colors.accent }]}>{children}</Text>
    </Pressable>
  );
}

export function ProgressBar({ value, max, height = 8 }) {
  const ratio = Math.max(0, Math.min(1, (Number(value) || 0) / (Number(max) || 1)));
  return (
    <View style={[styles.progressTrack, { height }]}>
      <View style={[styles.progressFill, { width: `${ratio * 100}%`, height }]} />
    </View>
  );
}

export function Pill({ label, active, onPress, icon }) {
  return (
    <Pressable onPress={onPress} style={[styles.pill, active && styles.pillActive]}>
      {icon ? <Ionicons name={icon} size={14} color={active ? colors.white : colors.muted} /> : null}
      <Text style={[styles.pillText, active && { color: colors.white }]}>{label}</Text>
    </Pressable>
  );
}

export function Toggle({ value, onValueChange }) {
  return (
    <Pressable onPress={() => onValueChange(!value)} style={[styles.toggle, value && styles.toggleActive]}>
      <View style={[styles.toggleKnob, value && styles.toggleKnobActive]} />
    </Pressable>
  );
}

export function SectionTitle({ title, action, onPress }) {
  return (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {action ? <Pressable onPress={onPress}><Text style={styles.action}>{action}</Text></Pressable> : null}
    </View>
  );
}

export function StatCard({ label, value, tone = 'default', icon }) {
  const toneColor = tone === 'danger' ? colors.danger : tone === 'success' ? colors.success : colors.primary;
  return (
    <Card style={styles.statCard}>
      <View style={[styles.statIcon, { backgroundColor: `${toneColor}15` }]}>
        <Ionicons name={icon} size={20} color={toneColor} />
      </View>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={[styles.statValue, { color: toneColor }]}>{value}</Text>
    </Card>
  );
}

export function TransactionRow({ item, category }) {
  const income = item.type === 'income';
  return (
    <View style={styles.row}>
      <View style={[styles.rowIcon, { backgroundColor: `${category?.color || colors.primary}15` }]}>
        <Ionicons name={category?.icon || 'swap-horizontal'} size={21} color={category?.color || colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle}>{item.title}</Text>
        <Text style={styles.rowMeta}>{category?.name || 'دسته دیگر'} • {item.source === 'sms' ? 'پیامک' : 'دستی'}</Text>
      </View>
      <View style={{ alignItems: 'flex-start' }}>
        <Text style={[styles.rowAmount, { color: income ? colors.success : colors.danger }]}>
          {income ? '+' : '−'} {formatToman(item.amount)}
        </Text>
        <Text style={styles.rowMeta}>{new Date(item.date).toLocaleDateString('fa-IR', { month: 'short', day: 'numeric' })}</Text>
      </View>
    </View>
  );
}

export function SearchBar({ value, onChangeText, placeholder = 'جستجوی تراکنش...' }) {
  return (
    <View style={styles.search}>
      <Ionicons name="search-outline" size={20} color={colors.muted} />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        style={styles.searchInput}
        textAlign="right"
      />
      {value ? (
        <Pressable onPress={() => onChangeText('')}><Ionicons name="close-circle" size={20} color={colors.muted} /></Pressable>
      ) : null}
    </View>
  );
}

export function MiniBarChart({ data, height = 130 }) {
  const max = Math.max(...data, 1);
  const barW = 250 / data.length;
  return (
    <Svg width="100%" height={height} viewBox="0 0 250 130">
      <Line x1="0" y1="124" x2="250" y2="124" stroke="#E6E6EE" strokeWidth="1" />
      {data.map((value, index) => {
        const h = (value / max) * 100;
        const x = index * barW + 2;
        const y = 122 - h;
        return <Rect key={index} x={x} y={y} width={Math.max(barW - 3, 2)} height={h} rx="2" fill={colors.accent} opacity={0.35 + (value / max) * 0.65} />;
      })}
    </Svg>
  );
}

export function DonutChart({ segments, size = 180 }) {
  const total = segments.reduce((sum, item) => sum + item.value, 0) || 1;
  const stroke = 24;
  const radiusValue = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radiusValue;
  let offset = 0;
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <Circle cx={size / 2} cy={size / 2} r={radiusValue} fill="none" stroke="#F0EFF5" strokeWidth={stroke} />
        {segments.map((segment, index) => {
          const dash = circumference * (segment.value / total);
          const current = (
            <Circle
              key={index}
              cx={size / 2}
              cy={size / 2}
              r={radiusValue}
              fill="none"
              stroke={segment.color}
              strokeWidth={stroke}
              strokeDasharray={`${dash} ${circumference - dash}`}
              strokeDashoffset={-offset}
              strokeLinecap="round"
              rotation="-90"
              origin={`${size / 2}, ${size / 2}`}
            />
          );
          offset += dash;
          return current;
        })}
      </Svg>
      <View style={styles.donutCenter}>
        <Text style={styles.donutCenterSmall}>هزینه</Text>
        <Text style={styles.donutCenterValue}>{formatToman(total, true)}</Text>
      </View>
    </View>
  );
}

export function LineChart({ data, height = 150 }) {
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const points = data.map((value, index) => {
    const x = 8 + (index / Math.max(data.length - 1, 1)) * 234;
    const y = 124 - ((value - min) / range) * 100;
    return `${x},${y}`;
  }).join(' ');
  return (
    <Svg width="100%" height={height} viewBox="0 0 250 130">
      <Line x1="8" y1="124" x2="242" y2="124" stroke="#E6E6EE" />
      <Polyline points={points} fill="none" stroke={colors.accent} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      {data.map((value, index) => {
        const x = 8 + (index / Math.max(data.length - 1, 1)) * 234;
        const y = 124 - ((value - min) / range) * 100;
        return <Circle key={index} cx={x} cy={y} r="3.2" fill={colors.accent} />;
      })}
    </Svg>
  );
}

export function SelectModal({ visible, title, options, value, onSelect, onClose }) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.modalBackdrop} onPress={onClose}>
        <Pressable style={styles.modalCard} onPress={(event) => event.stopPropagation()}>
          <Text style={styles.modalTitle}>{title}</Text>
          {options.map((option) => (
            <Pressable key={option.value} onPress={() => { onSelect(option.value); onClose(); }} style={styles.modalOption}>
              <Text style={[styles.modalOptionText, option.value === value && { color: colors.accent, fontFamily: typography.bold }]}>{option.label}</Text>
              {option.value === value ? <Ionicons name="checkmark" color={colors.accent} size={20} /> : null}
            </Pressable>
          ))}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

export const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: 32 },
  scroll: { flexGrow: 1, backgroundColor: colors.background },
  header: { paddingBottom: spacing.sm },
  headerMain: { flexDirection: 'row-reverse', alignItems: 'center', gap: spacing.sm },
  title: { fontFamily: typography.bold, color: colors.text, fontSize: 23, textAlign: 'right' },
  subtitle: { fontFamily: typography.regular, color: colors.muted, fontSize: 13, textAlign: 'right', marginTop: 2 },
  iconButton: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center', ...shadow.card },
  card: { backgroundColor: colors.cardWhite, borderRadius: radius.card, ...shadow.card },
  button: { minHeight: 50, borderRadius: radius.button, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 20 },
  buttonPrimary: { backgroundColor: colors.accent },
  buttonOutline: { backgroundColor: 'transparent', borderWidth: 1, borderColor: colors.accent },
  buttonText: { fontFamily: typography.bold, fontSize: 15, color: colors.white },
  progressTrack: { backgroundColor: '#ECEBF2', borderRadius: radius.pill, overflow: 'hidden' },
  progressFill: { backgroundColor: colors.accent, borderRadius: radius.pill },
  pill: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, paddingVertical: 9, paddingHorizontal: 13, borderRadius: radius.pill, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border },
  pillActive: { backgroundColor: colors.accent, borderColor: colors.accent },
  pillText: { fontFamily: typography.regular, color: colors.muted, fontSize: 12 },
  toggle: { width: 52, height: 30, borderRadius: 15, backgroundColor: '#D8D8E3', padding: 3, justifyContent: 'center' },
  toggleActive: { backgroundColor: colors.accent },
  toggleKnob: { width: 24, height: 24, borderRadius: 12, backgroundColor: colors.white, alignSelf: 'flex-end' },
  toggleKnobActive: { alignSelf: 'flex-start' },
  sectionHeader: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginTop: 20, marginBottom: 10 },
  sectionTitle: { fontFamily: typography.bold, color: colors.text, fontSize: 16 },
  action: { fontFamily: typography.bold, color: colors.accent, fontSize: 13 },
  statCard: { flex: 1, minWidth: 110 },
  statIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 10, alignSelf: 'flex-end' },
  statLabel: { color: colors.muted, fontFamily: typography.regular, fontSize: 12, textAlign: 'right' },
  statValue: { fontFamily: typography.bold, fontSize: 15, marginTop: 3, textAlign: 'right' },
  row: { flexDirection: 'row-reverse', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F0EFF4', gap: 10 },
  rowIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  rowTitle: { fontFamily: typography.bold, color: colors.text, fontSize: 14, textAlign: 'right' },
  rowMeta: { fontFamily: typography.regular, color: colors.muted, fontSize: 11, marginTop: 2, textAlign: 'right' },
  rowAmount: { fontFamily: typography.bold, fontSize: 13, textAlign: 'left' },
  search: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, backgroundColor: colors.white, borderRadius: 14, paddingHorizontal: 14, height: 48, ...shadow.card },
  searchInput: { flex: 1, fontFamily: typography.regular, color: colors.text, fontSize: 13 },
  donutCenter: { position: 'absolute', alignItems: 'center' },
  donutCenterSmall: { fontFamily: typography.regular, color: colors.muted, fontSize: 11 },
  donutCenterValue: { fontFamily: typography.bold, color: colors.primary, fontSize: 16, marginTop: 3 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: colors.white, padding: spacing.xl, borderTopLeftRadius: 24, borderTopRightRadius: 24 },
  modalTitle: { fontFamily: typography.bold, color: colors.text, textAlign: 'right', fontSize: 17, marginBottom: 8 },
  modalOption: { minHeight: 48, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#F0EFF4' },
  modalOptionText: { fontFamily: typography.regular, color: colors.text, fontSize: 14, textAlign: 'right' },
});
