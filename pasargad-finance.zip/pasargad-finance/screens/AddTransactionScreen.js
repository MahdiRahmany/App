import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, typography } from '../theme';
import { Button, Card, PageHeader, Screen, SelectModal } from '../components/ui';
import { useFinance } from '../context/FinanceContext';

export default function AddTransactionScreen({ navigation }) {
  const { categories, addTransaction } = useFinance();
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '');
  const [type, setType] = useState('expense');
  const [modal, setModal] = useState(false);

  const save = () => {
    const numeric = Number(amount.replace(/,/g, ''));
    if (!title.trim() || !numeric) return Alert.alert('اطلاعات ناقص', 'عنوان و مبلغ را وارد کن.');
    addTransaction({
      id: `t-${Date.now()}`,
      title: title.trim(),
      categoryId,
      amount: numeric,
      type,
      date: new Date('2026-09-25T12:00:00').toISOString(),
      source: 'manual'
    });
    navigation.goBack();
  };

  return (
    <Screen>
      <PageHeader title="تراکنش جدید" onBack={() => navigation.goBack()} />
      <Card>
        <Text style={styles.label}>عنوان</Text>
        <TextInput value={title} onChangeText={setTitle} placeholder="مثلاً نان سنگک" style={styles.input} textAlign="right" />
        <Text style={styles.label}>مبلغ</Text>
        <TextInput value={amount} onChangeText={(t) => setAmount(t.replace(/[^0-9]/g, ''))} placeholder="مثلاً ۱۸۰۰۰۰" keyboardType="number-pad" style={styles.input} textAlign="right" />
        <Text style={styles.label}>نوع تراکنش</Text>
        <View style={styles.row}>
          <Button variant={type === 'expense' ? 'primary' : 'outline'} onPress={() => setType('expense')} style={styles.half}>خرج</Button>
          <Button variant={type === 'income' ? 'primary' : 'outline'} onPress={() => setType('income')} style={styles.half}>درآمد</Button>
        </View>
        <Text style={styles.label}>دسته‌بندی</Text>
        <Text style={styles.select} onPress={() => setModal(true)}>{categories.find((c) => c.id === categoryId)?.name}</Text>
        <Button onPress={save}>ثبت تراکنش</Button>
      </Card>
      <SelectModal visible={modal} title="انتخاب دسته" options={categories.map((c) => ({ label: c.name, value: c.id }))} value={categoryId} onSelect={setCategoryId} onClose={() => setModal(false)} />
    </Screen>
  );
}
const styles = StyleSheet.create({
  label: { fontFamily: typography.bold, color: colors.text, fontSize: 12, marginTop: 4, marginBottom: 7, textAlign: 'right' },
  input: { height: 50, borderWidth: 1, borderColor: colors.border, borderRadius: 13, backgroundColor: '#FAFAFC', paddingHorizontal: 14, fontFamily: typography.regular, color: colors.text, marginBottom: 10 },
  select: { height: 50, borderWidth: 1, borderColor: colors.border, borderRadius: 13, backgroundColor: '#FAFAFC', paddingHorizontal: 14, paddingVertical: 15, fontFamily: typography.regular, color: colors.text, textAlign: 'right', marginBottom: 14 },
  row: { flexDirection: 'row-reverse', gap: 8, marginBottom: 8 },
  half: { flex: 1 },
});
