import React, { useState } from 'react';
import { Alert, StyleSheet, Text } from 'react-native';
import { colors, typography } from '../theme';
import { Button, Card, PageHeader, Screen } from '../components/ui';
import { exportBackup, importBackup } from '../services/backup';
import { useFinance } from '../context/FinanceContext';

export default function BackupScreen({ navigation }) {
  const { transactions, budgets, assets, loans, people, dues, categories, patch } = useFinance();
  const [busy, setBusy] = useState(false);

  const snapshot = { version: 1, exportedAt: new Date('2026-09-25T12:00:00').toISOString(), transactions, budgets, assets, loans, people, dues, categories };

  const doExport = async () => {
    setBusy(true);
    try {
      await exportBackup(snapshot);
      Alert.alert('پشتیبان آماده شد', 'فایل JSON ساخته و برای اشتراک‌گذاری باز شد.');
    } catch {
      Alert.alert('خطا', 'ساخت فایل پشتیبان انجام نشد.');
    } finally {
      setBusy(false);
    }
  };

  const doImport = async () => {
    setBusy(true);
    try {
      const imported = await importBackup();
      if (!imported) return;
      patch({
        transactions: imported.transactions || transactions,
        budgets: imported.budgets || budgets,
        assets: imported.assets || assets,
        loans: imported.loans || loans,
        people: imported.people || people,
        dues: imported.dues || dues,
        categories: imported.categories || categories,
      });
      Alert.alert('بازیابی شد', 'اطلاعات پشتیبان روی داده‌های محلی اعمال شد.');
    } catch {
      Alert.alert('خطا', 'فایل انتخاب‌شده JSON معتبر پول‌یار نبود.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <PageHeader title="پشتیبان‌گیری و بازیابی" onBack={() => navigation.goBack()} />
      <Card>
        <Text style={styles.title}>پشتیبان آفلاین JSON</Text>
        <Text style={styles.text}>یک snapshot از تراکنش‌ها، بودجه‌ها، دارایی‌ها، اشخاص، سررسیدها و دسته‌بندی‌ها روی فایل محلی بساز.</Text>
        <Button onPress={doExport} icon="share-social-outline" disabled={busy}>خروجی JSON</Button>
        <Button onPress={doImport} variant="outline" icon="cloud-download-outline" disabled={busy} style={{ marginTop: 10 }}>بازیابی از فایل</Button>
      </Card>
      <Card style={{ marginTop: 12, backgroundColor: colors.softOrange }}>
        <Text style={styles.noteTitle}>نکته</Text>
        <Text style={styles.text}>این نسخه بدون سرور کار می‌کند. قبل از انتشار محصول نهایی، رمزنگاری backup و کنترل دسترسی فایل را هم اضافه کن.</Text>
      </Card>
    </Screen>
  );
}
const styles = StyleSheet.create({
  title: { fontFamily: typography.bold, color: colors.text, fontSize: 16, textAlign: 'right' },
  text: { fontFamily: typography.regular, color: colors.muted, fontSize: 12, lineHeight: 23, textAlign: 'right', marginTop: 7, marginBottom: 14 },
  noteTitle: { fontFamily: typography.bold, color: colors.accent, fontSize: 13, textAlign: 'right' },
});
