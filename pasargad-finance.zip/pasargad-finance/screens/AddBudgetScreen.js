import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TextInput } from 'react-native';
import { colors, typography } from '../theme';
import { Button, Card, PageHeader, Screen, SelectModal, SectionTitle } from '../components/ui';
import { useFinance } from '../context/FinanceContext';

export default function AddBudgetScreen({ navigation }) {
  const { categories, addBudget } = useFinance();
  const [categoryId, setCategoryId] = useState(categories[0]?.id || '');
  const [limit, setLimit] = useState('');
  const [modal, setModal] = useState(false);

  const save = () => {
    const value = Number(limit.replace(/,/g, ''));
    if (!value || !categoryId) return Alert.alert('اطلاعات ناقص', 'دسته و سقف بودجه را وارد کن.');
    addBudget({ id: `b-${Date.now()}`, categoryId, limit: value, spent: 0 });
    navigation.goBack();
  };

  return (
    <Screen>
      <PageHeader title="بودجه جدید" onBack={() => navigation.goBack()} />
      <SectionTitle title="جزئیات بودجه" />
      <Card>
        <Text style={styles.label}>دسته‌بندی</Text>
        <Text style={styles.select} onPress={() => setModal(true)}>{categories.find((c) => c.id === categoryId)?.name || 'انتخاب دسته'}</Text>
        <Text style={styles.label}>سقف ماهانه (تومان)</Text>
        <TextInput value={limit} onChangeText={setLimit} keyboardType="number-pad" placeholder="مثلاً ۵۰۰۰۰۰۰" style={styles.input} textAlign="right" />
        <Button onPress={save}>ذخیره بودجه</Button>
      </Card>
      <SelectModal
        visible={modal}
        title="انتخاب دسته"
        options={categories.map((c) => ({ label: c.name, value: c.id }))}
        value={categoryId}
        onSelect={setCategoryId}
        onClose={() => setModal(false)}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  label: { fontFamily: typography.bold, color: colors.text, fontSize: 12, marginBottom: 7, marginTop: 4, textAlign: 'right' },
  select: { height: 50, borderWidth: 1, borderColor: colors.border, borderRadius: 13, backgroundColor: '#FAFAFC', paddingHorizontal: 14, paddingVertical: 15, fontFamily: typography.regular, color: colors.text, textAlign: 'right', marginBottom: 12 },
  input: { height: 50, borderWidth: 1, borderColor: colors.border, borderRadius: 13, backgroundColor: '#FAFAFC', paddingHorizontal: 14, fontFamily: typography.regular, color: colors.text, marginBottom: 16 },
});
