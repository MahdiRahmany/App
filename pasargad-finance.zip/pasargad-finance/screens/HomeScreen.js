import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, radius, spacing, typography } from '../theme';
import { Card, Pill, Screen, SearchBar, SectionTitle, SelectModal, StatCard, TransactionRow } from '../components/ui';
import { useFinance } from '../context/FinanceContext';
import { formatToman } from '../utils/format';
import { months, inMonth } from '../utils/date';

export default function HomeScreen({ navigation }) {
  const { transactions, categories, dailySpend } = useFinance();
  const [monthIndex, setMonthIndex] = useState(0);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [amountFilter, setAmountFilter] = useState('all');
  const [modal, setModal] = useState(null);

  const monthKey = months[monthIndex].key;
  const currentMonthTransactions = transactions.filter((t) => inMonth(t.date, monthKey));

  const totals = useMemo(() => {
    const income = currentMonthTransactions.filter((t) => t.type === 'income').reduce((a, b) => a + b.amount, 0);
    const expense = currentMonthTransactions.filter((t) => t.type === 'expense').reduce((a, b) => a + b.amount, 0);
    return { income, expense, balance: income - expense };
  }, [currentMonthTransactions]);

  const filtered = useMemo(() => {
    const now = new Date('2026-09-25T12:00:00');
    return currentMonthTransactions.filter((item) => {
      const catName = categories.find((c) => c.id === item.categoryId)?.name || '';
      const matchQuery = !query || `${item.title} ${catName}`.toLowerCase().includes(query.toLowerCase());
      const matchCategory = category === 'all' || item.categoryId === category;
      const ageDays = Math.floor((now - new Date(item.date)) / (1000 * 60 * 60 * 24));
      const matchDate = dateFilter === 'all' || (dateFilter === 'week' ? ageDays <= 7 : ageDays <= 30);
      const matchAmount = amountFilter === 'all' || (amountFilter === 'large' ? item.amount >= 1000000 : item.amount < 1000000);
      return matchQuery && matchCategory && matchDate && matchAmount;
    });
  }, [amountFilter, category, categories, currentMonthTransactions, dateFilter, query]);

  const categoryOptions = [{ label: 'همه دسته‌ها', value: 'all' }, ...categories.map((item) => ({ label: item.name, value: item.id }))];
  const monthOptions = months.map((m, index) => ({ label: m.title, value: String(index) }));

  return (
    <View style={styles.root}>
      <Screen style={{ paddingBottom: 90 }}>
        <View style={styles.topLine}>
          <View>
            <Text style={styles.greeting}>سلام 👋</Text>
            <Text style={styles.sub}>این ماه چطور گذشت؟</Text>
          </View>
          <Pressable onPress={() => navigation.navigate('AddTransaction')} style={styles.addTop}>
            <Ionicons name="add" color={colors.white} size={24} />
          </Pressable>
        </View>

        <Card style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>مانده خالص ماه</Text>
          <Text style={styles.balance}>{formatToman(totals.balance)}</Text>
          <View style={styles.statRow}>
            <StatCard label="درآمد" value={formatToman(totals.income, true)} tone="success" icon="arrow-down-outline" />
            <View style={{ width: 10 }} />
            <StatCard label="خرج" value={formatToman(totals.expense, true)} tone="danger" icon="arrow-up-outline" />
          </View>
        </Card>

        <View style={styles.monthSwitcher}>
          <Pressable onPress={() => setMonthIndex((i) => Math.max(0, i - 1))}><Ionicons name="chevron-forward" size={22} color={colors.primary} /></Pressable>
          <Pressable onPress={() => setModal('month')}><Text style={styles.monthTitle}>{months[monthIndex].title}</Text></Pressable>
          <Pressable onPress={() => setMonthIndex((i) => Math.min(months.length - 1, i + 1))}><Ionicons name="chevron-back" size={22} color={colors.primary} /></Pressable>
        </View>

        <Card>
          <SectionTitle title="روند روزانه خرج" />
          <Text style={styles.chartHint}>هر ستون یک روز از ماه را نشان می‌دهد</Text>
          <View style={styles.chartGrid}>
            <View style={styles.yLabel}><Text>۲م</Text><Text>۱م</Text><Text>۰</Text></View>
            <View style={{ flex: 1 }}>
              <View style={styles.bars}>
                {dailySpend.map((value, index) => {
                  const max = Math.max(...dailySpend, 1);
                  return <View key={index} style={[styles.bar, { height: Math.max(4, (value / max) * 112), opacity: 0.35 + (value / max) * 0.65 }]} />;
                })}
              </View>
            </View>
          </View>
        </Card>

        <SectionTitle title="آخرین تراکنش‌ها" action="افزودن دستی" onPress={() => navigation.navigate('AddTransaction')} />
        <SearchBar value={query} onChangeText={setQuery} />
        <View style={styles.filterWrap}>
          <Pill label={categories.find((c) => c.id === category)?.name || 'همه دسته‌ها'} onPress={() => setModal('category')} active />
          <Pill label={dateFilter === 'week' ? '۷ روز اخیر' : '۳۰ روز اخیر'} onPress={() => setModal('date')} />
          <Pill label={amountFilter === 'large' ? 'بالای ۱م' : 'مبلغ'} onPress={() => setModal('amount')} />
        </View>

        <Card style={{ marginTop: 10 }}>
          {filtered.slice(0, 8).map((item) => (
            <TransactionRow key={item.id} item={item} category={categories.find((c) => c.id === item.categoryId)} />
          ))}
          {!filtered.length ? <Text style={styles.empty}>تراکنشی مطابق فیلتر پیدا نشد.</Text> : null}
        </Card>
      </Screen>

      <Pressable style={styles.fab} onPress={() => navigation.navigate('AddTransaction')}>
        <Ionicons name="add" color={colors.white} size={30} />
      </Pressable>

      <SelectModal visible={modal === 'category'} title="فیلتر دسته" options={categoryOptions} value={category} onSelect={setCategory} onClose={() => setModal(null)} />
      <SelectModal visible={modal === 'month'} title="انتخاب ماه" options={monthOptions} value={String(monthIndex)} onSelect={(v) => setMonthIndex(Number(v))} onClose={() => setModal(null)} />
      <SelectModal visible={modal === 'date'} title="فیلتر تاریخ" options={[{ label: 'همه تاریخ‌ها', value: 'all' }, { label: '۷ روز اخیر', value: 'week' }, { label: '۳۰ روز اخیر', value: 'month' }]} value={dateFilter} onSelect={setDateFilter} onClose={() => setModal(null)} />
      <SelectModal visible={modal === 'amount'} title="فیلتر مبلغ" options={[{ label: 'همه مبالغ', value: 'all' }, { label: 'کمتر از ۱ میلیون', value: 'small' }, { label: '۱ میلیون و بیشتر', value: 'large' }]} value={amountFilter} onSelect={setAmountFilter} onClose={() => setModal(null)} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  topLine: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  greeting: { fontFamily: typography.bold, color: colors.primaryDark, fontSize: 21, textAlign: 'right' },
  sub: { fontFamily: typography.regular, color: colors.muted, fontSize: 12, textAlign: 'right', marginTop: 2 },
  addTop: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  balanceCard: { backgroundColor: colors.primaryDark, marginBottom: 12 },
  balanceLabel: { fontFamily: typography.regular, color: '#D8D2FF', textAlign: 'right', fontSize: 12 },
  balance: { fontFamily: typography.bold, color: colors.white, fontSize: 27, textAlign: 'right', marginTop: 4, marginBottom: 16 },
  statRow: { flexDirection: 'row-reverse' },
  monthSwitcher: { height: 46, flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 2 },
  monthTitle: { fontFamily: typography.bold, color: colors.primary, fontSize: 15 },
  chartHint: { fontFamily: typography.regular, color: colors.muted, fontSize: 11, textAlign: 'right', marginBottom: 10 },
  chartGrid: { flexDirection: 'row-reverse', alignItems: 'flex-end' },
  yLabel: { height: 124, justifyContent: 'space-between', paddingBottom: 8, paddingTop: 4 },
  yLabelText: { color: colors.muted },
  bars: { height: 124, flexDirection: 'row', alignItems: 'flex-end', gap: 3, overflow: 'hidden' },
  bar: { flex: 1, minWidth: 2, maxWidth: 8, backgroundColor: colors.accent, borderRadius: 4 },
  filterWrap: { flexDirection: 'row-reverse', gap: 8, marginVertical: 10, flexWrap: 'wrap' },
  empty: { textAlign: 'center', color: colors.muted, fontFamily: typography.regular, paddingVertical: 24 },
  fab: { position: 'absolute', left: 22, bottom: 20, width: 58, height: 58, borderRadius: 29, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center', elevation: 6, shadowColor: '#222', shadowOpacity: 0.2, shadowRadius: 8 },
});
