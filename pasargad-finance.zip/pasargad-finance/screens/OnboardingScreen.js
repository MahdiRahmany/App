import React, { useState } from 'react';
import { Alert, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, spacing, typography } from '../theme';
import { Button, Card, Screen, Toggle } from '../components/ui';
import { useFinance } from '../context/FinanceContext';
import { requestNotificationPermission, scheduleFinanceReminder } from '../services/notifications';

export function OnboardingWelcome({ navigation }) {
  const [simulated, setSimulated] = useState(false);
  const handlePermission = () => {
    setSimulated(true);
    Alert.alert('دسترسی پیامک', Platform.OS === 'android'
      ? 'این نسخه UI و جریان مجوز را نمایش می‌دهد؛ خواندن محتوای SMS بانکی عمداً به native module اختصاصی موکول شده است.'
      : 'در iOS دسترسی عمومی برای خواندن SMS توسط اپ‌های شخص ثالث وجود ندارد. این نسخه از Mock و ثبت دستی استفاده می‌کند.');
  };
  return (
    <Screen style={styles.onboard} scroll={false}>
      <View style={styles.brandMark}><Ionicons name="wallet-outline" size={34} color={colors.white} /></View>
      <Text style={styles.kicker}>پول‌یار</Text>
      <Text style={styles.hero}>خرج‌هات رو{'\n'}خودکار مرتب کن</Text>
      <Text style={styles.desc}>پیامک‌های بانکی، ثبت دستی و گزارش‌های ساده در یک داشبورد فارسی و آفلاین.</Text>
      <Card style={styles.permissionCard}>
        <View style={styles.featureIcon}><Ionicons name="chatbox-ellipses-outline" size={28} color={colors.accent} /></View>
        <Text style={styles.cardTitle}>خواندن پیامک‌های بانکی</Text>
        <Text style={styles.cardText}>برای ساخت تراکنش خودکار، اپ می‌تواند در Android با پیاده‌سازی native مجزا از SMS استفاده کند.</Text>
        <Button onPress={handlePermission} icon={simulated ? 'checkmark-circle' : 'shield-checkmark'}>
          {simulated ? 'دسترسی نمونه فعال شد' : 'اجازه دسترسی'}
        </Button>
      </Card>
      <View style={styles.bottom}>
        <Text style={styles.page}>۱ / ۴</Text>
        <Button onPress={() => navigation.navigate('Pin')} style={{ minWidth: 155 }}>ادامه</Button>
      </View>
    </Screen>
  );
}

export function OnboardingPin({ navigation }) {
  const { patch } = useFinance();
  const [pin, setPin] = useState('');
  const [confirm, setConfirm] = useState('');
  const [biometric, setBiometric] = useState(true);

  const next = () => {
    if (pin.length !== 4 || confirm.length !== 4) return Alert.alert('PIN ناقص است', 'هر دو فیلد را با ۴ رقم پر کن.');
    if (pin !== confirm) return Alert.alert('PIN یکسان نیست', 'PIN و تکرار آن را یکسان وارد کن.');
    patch({ pin, biometricEnabled: biometric });
    navigation.navigate('Reminder');
  };

  return (
    <Screen style={styles.onboard} scroll={false}>
      <View style={styles.onboardTop}><Text style={styles.page}>۲ / ۴</Text></View>
      <View style={styles.illustration}><Ionicons name="finger-print-outline" size={64} color={colors.accent} /></View>
      <Text style={styles.heroSmall}>قفل فقط برای خودت</Text>
      <Text style={styles.desc}>یک PIN چهاررقمی بساز و برای ورود سریع‌تر بیومتریک را فعال کن.</Text>
      <View style={styles.inputWrap}>
        <Text style={styles.inputLabel}>PIN چهار رقمی</Text>
        <TextInput
          value={pin}
          onChangeText={(t) => setPin(t.replace(/[^0-9]/g, '').slice(0, 4))}
          keyboardType="number-pad"
          secureTextEntry
          maxLength={4}
          style={styles.pinInput}
          textAlign="center"
        />
        <Text style={styles.inputLabel}>تکرار PIN</Text>
        <TextInput
          value={confirm}
          onChangeText={(t) => setConfirm(t.replace(/[^0-9]/g, '').slice(0, 4))}
          keyboardType="number-pad"
          secureTextEntry
          maxLength={4}
          style={styles.pinInput}
          textAlign="center"
        />
      </View>
      <View style={styles.settingLine}>
        <Text style={styles.settingText}>فعال‌سازی اثر انگشت / Face ID</Text>
        <Toggle value={biometric} onValueChange={setBiometric} />
      </View>
      <Button onPress={next}>ذخیره و ادامه</Button>
    </Screen>
  );
}

export function OnboardingReminder({ navigation }) {
  const { patch } = useFinance();
  const [enabled, setEnabled] = useState(true);
  const [period, setPeriod] = useState('daily');
  const [time, setTime] = useState('21:00');

  const next = async () => {
    patch({ reminderEnabled: enabled, reminderPeriod: period, reminderTime: time });
    if (enabled) {
      await requestNotificationPermission();
      await scheduleFinanceReminder({ enabled, period, time });
    }
    navigation.navigate('Trial');
  };

  return (
    <Screen style={styles.onboard} scroll={false}>
      <Text style={styles.page}>۳ / ۴</Text>
      <View style={styles.illustration}><Ionicons name="notifications-outline" size={60} color={colors.accent} /></View>
      <Text style={styles.heroSmall}>یادآور مالی</Text>
      <Text style={styles.desc}>یک یادآوری کوتاه برای ثبت تراکنش‌ها و مرور دخل‌وخرج دریافت کن.</Text>
      <Card>
        <View style={styles.settingLine}><Text style={styles.settingText}>یادآور فعال باشد</Text><Toggle value={enabled} onValueChange={setEnabled} /></View>
        <View style={styles.choiceRow}>
          <Pressable onPress={() => setPeriod('daily')} style={[styles.choice, period === 'daily' && styles.choiceActive]}><Text style={styles.choiceText}>روزانه</Text></Pressable>
          <Pressable onPress={() => setPeriod('weekly')} style={[styles.choice, period === 'weekly' && styles.choiceActive]}><Text style={styles.choiceText}>هفتگی</Text></Pressable>
        </View>
        <Text style={styles.inputLabel}>ساعت یادآوری</Text>
        <TextInput value={time} onChangeText={setTime} style={styles.timeInput} keyboardType="numbers-and-punctuation" textAlign="center" />
      </Card>
      <Button onPress={next}>ادامه</Button>
    </Screen>
  );
}

export function OnboardingTrial({ navigation }) {
  const { patch, setSessionUnlocked } = useFinance();
  const start = () => {
    patch({ onboardingDone: true, subscriptionStarted: true });
    setSessionUnlocked(true);
  };
  return (
    <Screen style={styles.onboard} scroll={false}>
      <Text style={styles.page}>۴ / ۴</Text>
      <View style={[styles.illustration, { backgroundColor: colors.softOrange }]}><Text style={styles.trialDays}>۳۱</Text><Text style={styles.trialLabel}>روز</Text></View>
      <Text style={styles.heroSmall}>۳۱ روز اشتراک رایگان</Text>
      <Text style={styles.desc}>همه قابلیت‌های مدیریت مالی را برای شروع و تست اپ در اختیار داشته باش.</Text>
      <Card>
        {['داشبورد دخل‌وخرج و جستجوی تراکنش', 'بودجه‌بندی دسته‌ای و گزارش دونات', 'دارایی، وام، طلب و بدهی', 'پشتیبان‌گیری آفلاین JSON'].map((item) => (
          <View key={item} style={styles.benefit}><Ionicons name="checkmark-circle" size={20} color={colors.success} /><Text style={styles.benefitText}>{item}</Text></View>
        ))}
      </Card>
      <Button onPress={start}>شروع دوره آزمایشی</Button>
    </Screen>
  );
}

const styles = StyleSheet.create({
  onboard: { paddingTop: 28, justifyContent: 'space-between' },
  brandMark: { width: 68, height: 68, borderRadius: 22, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginTop: 20 },
  kicker: { fontFamily: typography.bold, color: colors.accent, textAlign: 'center', fontSize: 16, marginTop: 10 },
  hero: { fontFamily: typography.bold, fontSize: 34, lineHeight: 46, color: colors.primaryDark, textAlign: 'center', marginTop: 18 },
  heroSmall: { fontFamily: typography.bold, fontSize: 27, color: colors.primaryDark, textAlign: 'center', marginTop: 16 },
  desc: { fontFamily: typography.regular, color: colors.muted, fontSize: 14, lineHeight: 25, textAlign: 'center', marginTop: 12, marginBottom: 20 },
  permissionCard: { marginTop: 10 },
  featureIcon: { width: 54, height: 54, borderRadius: 18, backgroundColor: colors.softOrange, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-end', marginBottom: 12 },
  cardTitle: { fontFamily: typography.bold, color: colors.text, fontSize: 16, textAlign: 'right' },
  cardText: { fontFamily: typography.regular, color: colors.muted, fontSize: 12, lineHeight: 22, textAlign: 'right', marginVertical: 8 },
  bottom: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', paddingTop: 18 },
  page: { fontFamily: typography.bold, color: colors.muted, fontSize: 12, textAlign: 'right' },
  illustration: { width: 110, height: 110, borderRadius: 40, backgroundColor: colors.softOrange, alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginTop: 20 },
  inputWrap: { marginBottom: 18 },
  inputLabel: { fontFamily: typography.bold, color: colors.text, fontSize: 12, textAlign: 'right', marginBottom: 6, marginTop: 10 },
  pinInput: { height: 54, borderWidth: 1, borderColor: colors.border, borderRadius: 14, backgroundColor: colors.white, fontFamily: typography.bold, fontSize: 24, letterSpacing: 9, color: colors.primary },
  settingLine: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 },
  settingText: { fontFamily: typography.bold, fontSize: 13, color: colors.text, textAlign: 'right', flex: 1, marginLeft: 10 },
  choiceRow: { flexDirection: 'row-reverse', gap: 8, marginBottom: 8 },
  choice: { flex: 1, height: 46, alignItems: 'center', justifyContent: 'center', borderRadius: 13, backgroundColor: '#F2F1F6' },
  choiceActive: { backgroundColor: colors.softOrange, borderWidth: 1, borderColor: colors.accent },
  choiceText: { fontFamily: typography.bold, color: colors.text, fontSize: 13 },
  timeInput: { height: 48, borderWidth: 1, borderColor: colors.border, borderRadius: 12, backgroundColor: colors.white, fontFamily: typography.bold, color: colors.primary, fontSize: 17 },
  trialDays: { fontFamily: typography.bold, color: colors.accent, fontSize: 38, lineHeight: 40 },
  trialLabel: { fontFamily: typography.bold, color: colors.text, fontSize: 13 },
  benefit: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9, paddingVertical: 7 },
  benefitText: { flex: 1, fontFamily: typography.regular, color: colors.text, fontSize: 13, textAlign: 'right' },
  onboardTop: { alignItems: 'flex-end' },
});
