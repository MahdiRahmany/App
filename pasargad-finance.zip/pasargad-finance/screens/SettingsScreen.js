import React from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, typography } from '../theme';
import { Card, Screen, SectionTitle, Toggle } from '../components/ui';
import { useFinance } from '../context/FinanceContext';
import { requestNotificationPermission, scheduleFinanceReminder } from '../services/notifications';

export default function SettingsScreen({ navigation }) {
  const { reminderEnabled, reminderPeriod, reminderTime, patch, nightMode, resetDemo } = useFinance();

  const toggleReminder = async (value) => {
    const next = { enabled: value, period: reminderPeriod, time: reminderTime };
    patch({ reminderEnabled: value });
    if (value) await requestNotificationPermission();
    await scheduleFinanceReminder(next);
  };

  return (
    <Screen>
      <SectionTitle title="تنظیمات" />
      <Card>
        <SettingRow icon="notifications-outline" title="یادآور مالی" subtitle={`${reminderPeriod === 'daily' ? 'روزانه' : 'هفتگی'} • ساعت ${reminderTime}`} right={<Toggle value={reminderEnabled} onValueChange={toggleReminder} />} />
        <SettingRow icon="moon-outline" title="حالت شب" subtitle="حالت نمایش خلاصه مالی" right={<Toggle value={nightMode} onValueChange={(v) => patch({ nightMode: v })} />} />
        <SettingRow icon="lock-closed-outline" title="قفل برنامه" subtitle="PIN و بیومتریک در آنبوردینگ تنظیم شده‌اند" onPress={() => Alert.alert('قفل برنامه', 'برای تغییر PIN، داده‌ی onboarding را دوباره تکمیل کنید.')} />
      </Card>

      <SectionTitle title="مدیریت داده" />
      <Card>
        <SettingRow icon="pricetags-outline" title="دسته‌بندی‌ها" subtitle="افزودن، ویرایش و زیرمجموعه‌ها" onPress={() => navigation.navigate('Categories')} />
        <SettingRow icon="cloud-upload-outline" title="پشتیبان‌گیری و بازیابی" subtitle="JSON آفلاین" onPress={() => navigation.navigate('Backup')} />
        <SettingRow icon="refresh-outline" title="بازنشانی داده‌های نمونه" subtitle="برگرداندن اطلاعات Demo" onPress={() => { resetDemo(); Alert.alert('انجام شد', 'داده‌های نمونه بازگردانی شدند.'); }} />
      </Card>

      <Card style={styles.about}>
        <View style={styles.logo}><Ionicons name="wallet-outline" size={22} color={colors.white} /></View>
        <Text style={styles.aboutTitle}>پول‌یار</Text>
        <Text style={styles.aboutText}>مدیریت مالی شخصی فارسی • نسخه Demo ۱.۰</Text>
      </Card>
    </Screen>
  );
}

function SettingRow({ icon, title, subtitle, right, onPress }) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={styles.row}>
      <View style={styles.icon}><Ionicons name={icon} size={20} color={colors.accent} /></View>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.sub}>{subtitle}</Text>
      </View>
      {right || (onPress ? <Ionicons name="chevron-back" size={19} color={colors.muted} /> : null)}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { minHeight: 66, flexDirection: 'row-reverse', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: '#F0EFF4' },
  icon: { width: 40, height: 40, borderRadius: 13, backgroundColor: colors.softOrange, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: typography.bold, color: colors.text, fontSize: 13, textAlign: 'right' },
  sub: { fontFamily: typography.regular, color: colors.muted, fontSize: 10, marginTop: 2, textAlign: 'right' },
  about: { marginTop: 20, alignItems: 'center' },
  logo: { width: 48, height: 48, borderRadius: 16, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  aboutTitle: { fontFamily: typography.bold, color: colors.primaryDark, fontSize: 17, marginTop: 8 },
  aboutText: { fontFamily: typography.regular, color: colors.muted, fontSize: 11, marginTop: 2 },
});
