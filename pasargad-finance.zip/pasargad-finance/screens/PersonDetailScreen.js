import React from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, typography } from '../theme';
import { Button, Card, PageHeader, Screen } from '../components/ui';
import { useFinance } from '../context/FinanceContext';
import { formatToman } from '../utils/format';

export default function PersonDetailScreen({ navigation, route }) {
  const { people, patch } = useFinance();
  const person = people.find((p) => p.id === route.params?.personId) || people[0];
  const isReceivable = person.balance > 0;

  const updateBalance = (delta) => {
    patch({ people: people.map((p) => p.id === person.id ? { ...p, balance: p.balance + delta } : p) });
    Alert.alert('ثبت شد', 'مانده حساب این شخص به‌روزرسانی شد.');
  };

  return (
    <Screen>
      <PageHeader title="پروفایل شخص" onBack={() => navigation.goBack()} />
      <Card style={styles.profile}>
        <View style={styles.avatar}><Text style={styles.avatarText}>{person.avatar}</Text></View>
        <Text style={styles.name}>{person.name}</Text>
        <Text style={styles.relation}>{person.relation}</Text>
        <Text style={[styles.balance, { color: isReceivable ? colors.success : colors.danger }]}>
          {isReceivable ? 'طلب شما' : 'بدهی شما'} {formatToman(Math.abs(person.balance))}
        </Text>
      </Card>
      <Text style={styles.section}>عملیات سریع</Text>
      <View style={styles.actionRow}>
        <Button onPress={() => updateBalance(500000)} icon="arrow-down-outline" style={styles.action}>دریافت ۵۰۰ هزار</Button>
        <Button onPress={() => updateBalance(-500000)} variant="outline" icon="arrow-up-outline" style={styles.action}>پرداخت ۵۰۰ هزار</Button>
      </View>
      <Card style={{ marginTop: 12 }}>
        <View style={styles.historyHead}><Text style={styles.historyTitle}>آخرین وضعیت</Text><Ionicons name="time-outline" size={18} color={colors.accent} /></View>
        <Text style={styles.muted}>مانده فعلی با هر ثبت دریافت یا پرداخت، آفلاین در دستگاه ذخیره می‌شود.</Text>
      </Card>
    </Screen>
  );
}
const styles = StyleSheet.create({
  profile: { alignItems: 'center', marginTop: 8 },
  avatar: { width: 74, height: 74, borderRadius: 26, backgroundColor: colors.lilac, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontFamily: typography.bold, color: colors.primary, fontSize: 28 },
  name: { fontFamily: typography.bold, color: colors.text, fontSize: 21, marginTop: 10 },
  relation: { fontFamily: typography.regular, color: colors.muted, fontSize: 12, marginTop: 2 },
  balance: { fontFamily: typography.bold, fontSize: 18, marginTop: 13 },
  section: { fontFamily: typography.bold, color: colors.text, fontSize: 15, textAlign: 'right', marginTop: 20, marginBottom: 10 },
  actionRow: { flexDirection: 'row-reverse', gap: 8 },
  action: { flex: 1 },
  historyHead: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  historyTitle: { fontFamily: typography.bold, color: colors.text, fontSize: 14 },
  muted: { fontFamily: typography.regular, color: colors.muted, fontSize: 12, lineHeight: 22, textAlign: 'right' },
});
