import React, { useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, typography } from '../theme';
import { Card, DonutChart, LineChart, Pill, Screen, SectionTitle, Toggle } from '../components/ui';
import { useFinance } from '../context/FinanceContext';
import { formatToman } from '../utils/format';

export default function ReportsScreen() {
  const { transactions, categories, nightMode, patch } = useFinance();
  const reportTransactions = transactions.filter((t) => t.date.startsWith('2026-09'));
  const [range, setRange] = useState('month');

  const segments = useMemo(() => {
    return categories
      .map((cat) => ({
        ...cat,
        value: reportTransactions.filter((t) => t.type === 'expense' && t.categoryId === cat.id).reduce((sum, t) => sum + t.amount, 0),
      }))
      .filter((x) => x.value > 0);
  }, [categories, reportTransactions]);

  const expensive = [...segments].sort((a, b) => b.value - a.value);

  return (
    <Screen>
      <SectionTitle title="گزارش‌ها" action="خروجی تصویری" />
      <View style={styles.segment}>
        <Pill label="ماهانه" active={range === 'month'} onPress={() => setRange('month')} />
        <Pill label="روزانه" active={range === 'day'} onPress={() => setRange('day')} />
      </View>

      <Card>
        <Text style={styles.cardTitle}>توزیع هزینه‌ها</Text>
        <DonutChart segments={segments.map((s) => ({ value: range === 'day' ? s.value * 0.1 : s.value, color: s.color }))} />
        <View style={styles.legend}>
          {segments.slice(0, 5).map((item) => (
            <View key={item.id} style={styles.legendRow}>
              <View style={[styles.dot, { backgroundColor: item.color }]} />
              <Text style={styles.legendName}>{item.name}</Text>
              <Text style={styles.legendValue}>{formatToman(item.value, true)}</Text>
            </View>
          ))}
        </View>
      </Card>

      <SectionTitle title="پرهزینه‌ترین‌ها" />
      <Card>
        {expensive.slice(0, 4).map((item, index) => (
          <View key={item.id} style={styles.rankRow}>
            <Text style={styles.rank}>{index + 1}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.rankName}>{item.name}</Text>
              <View style={styles.rankBar}><View style={[styles.rankFill, { width: `${Math.min(100, (item.value / (expensive[0]?.value || 1)) * 100)}%` }]} /></View>
            </View>
            <Text style={styles.rankValue}>{formatToman(item.value, true)}</Text>
          </View>
        ))}
      </Card>

      <SectionTitle title="ویجت خلاصه سریع مالی" />
      <Card style={nightMode ? styles.nightCard : undefined}>
        <View style={styles.nightToggle}>
          <Text style={[styles.nightLabel, nightMode && { color: colors.white }]}>حالت شب</Text>
          <Toggle value={nightMode} onValueChange={(value) => patch({ nightMode: value })} />
        </View>
        <Text style={[styles.quickTitle, nightMode && { color: colors.white }]}>امروز</Text>
        <View style={styles.quickRow}>
          <QuickItem label="خرج امروز" value={formatToman(1240000, true)} icon="↑" />
          <QuickItem label="درآمد" value={formatToman(48500000, true)} icon="↓" success />
          <QuickItem label="سقف باقی‌مانده" value={formatToman(2160000, true)} icon="◔" />
        </View>
      </Card>
    </Screen>
  );
}

function QuickItem({ label, value, icon, success }) {
  return (
    <View style={styles.quickItem}>
      <Text style={[styles.quickIcon, { color: success ? colors.success : colors.accent }]}>{icon}</Text>
      <Text style={styles.quickLabel}>{label}</Text>
      <Text style={styles.quickValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  segment: { flexDirection: 'row-reverse', gap: 8, marginBottom: 10 },
  cardTitle: { fontFamily: typography.bold, color: colors.text, fontSize: 15, textAlign: 'right', marginBottom: 2 },
  legend: { marginTop: 8 },
  legendRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, paddingVertical: 6 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  legendName: { fontFamily: typography.regular, color: colors.text, flex: 1, textAlign: 'right', fontSize: 12 },
  legendValue: { fontFamily: typography.bold, color: colors.primary, fontSize: 12 },
  rankRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, paddingVertical: 9 },
  rank: { width: 28, height: 28, borderRadius: 10, backgroundColor: colors.lilac, textAlign: 'center', textAlignVertical: 'center', fontFamily: typography.bold, color: colors.primary },
  rankName: { fontFamily: typography.bold, color: colors.text, textAlign: 'right', fontSize: 13 },
  rankValue: { fontFamily: typography.bold, color: colors.danger, fontSize: 12 },
  rankBar: { marginTop: 6, height: 6, backgroundColor: '#EEE', borderRadius: 5, overflow: 'hidden' },
  rankFill: { height: 6, backgroundColor: colors.accent, borderRadius: 5 },
  nightCard: { backgroundColor: '#1B1A25', borderWidth: 1, borderColor: '#343140' },
  nightToggle: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  nightLabel: { fontFamily: typography.bold, color: colors.text, fontSize: 13 },
  quickTitle: { fontFamily: typography.bold, color: colors.primaryDark, fontSize: 18, textAlign: 'right', marginBottom: 8 },
  quickRow: { flexDirection: 'row-reverse', gap: 8 },
  quickItem: { flex: 1, backgroundColor: '#F8F7FB', borderRadius: 14, padding: 10 },
  quickIcon: { fontFamily: typography.bold, fontSize: 17, textAlign: 'right' },
  quickLabel: { fontFamily: typography.regular, color: colors.muted, fontSize: 10, textAlign: 'right', marginTop: 8 },
  quickValue: { fontFamily: typography.bold, color: colors.primary, fontSize: 12, textAlign: 'right', marginTop: 2 },
});
