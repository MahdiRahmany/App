import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, typography } from '../theme';
import { Card, ProgressBar, Screen, SectionTitle } from '../components/ui';
import { useFinance } from '../context/FinanceContext';
import { formatToman, formatNumber } from '../utils/format';

export default function BudgetScreen({ navigation }) {
  const { budgets, categories } = useFinance();
  const totalLimit = budgets.reduce((a, b) => a + b.limit, 0);
  const totalSpent = budgets.reduce((a, b) => a + b.spent, 0);
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Screen style={{ paddingBottom: 90 }}>
        <SectionTitle title="بودجه‌بندی" action="این ماه" />
        <Card style={styles.summary}>
          <Text style={styles.summaryLabel}>مصرف کل</Text>
          <Text style={styles.summaryValue}>{formatToman(totalSpent)}</Text>
          <ProgressBar value={totalSpent} max={totalLimit} height={10} />
          <Text style={styles.summaryMeta}>{formatNumber(Math.max(0, totalLimit - totalSpent))} تومان تا سقف بودجه باقی مانده</Text>
        </Card>

        {budgets.map((budget) => {
          const category = categories.find((c) => c.id === budget.categoryId);
          const ratio = Math.round((budget.spent / Math.max(budget.limit, 1)) * 100);
          return (
            <Card key={budget.id} style={styles.budgetCard}>
              <View style={styles.cardTop}>
                <View style={[styles.icon, { backgroundColor: `${category?.color || colors.primary}15` }]}>
                  <Ionicons name={category?.icon || 'pricetag-outline'} size={21} color={category?.color || colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{category?.name}</Text>
                  <Text style={styles.meta}>{formatToman(budget.spent, true)} از {formatToman(budget.limit, true)}</Text>
                </View>
                <Text style={[styles.percent, ratio >= 90 && { color: colors.danger }]}>{formatNumber(ratio)}٪</Text>
              </View>
              <ProgressBar value={budget.spent} max={budget.limit} height={9} />
            </Card>
          );
        })}
      </Screen>
      <Pressable style={styles.fab} onPress={() => navigation.navigate('AddBudget')}>
        <Ionicons name="add" size={30} color={colors.white} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  summary: { backgroundColor: colors.primaryDark, marginBottom: 12 },
  summaryLabel: { fontFamily: typography.regular, color: '#D8D2FF', fontSize: 12, textAlign: 'right' },
  summaryValue: { fontFamily: typography.bold, color: colors.white, fontSize: 22, textAlign: 'right', marginVertical: 5 },
  summaryMeta: { fontFamily: typography.regular, color: '#D8D2FF', fontSize: 11, textAlign: 'right', marginTop: 8 },
  budgetCard: { marginBottom: 10 },
  cardTop: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, marginBottom: 11 },
  icon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  name: { fontFamily: typography.bold, color: colors.text, textAlign: 'right', fontSize: 14 },
  meta: { fontFamily: typography.regular, color: colors.muted, textAlign: 'right', fontSize: 11, marginTop: 2 },
  percent: { fontFamily: typography.bold, color: colors.primary, fontSize: 14 },
  fab: { position: 'absolute', left: 22, bottom: 20, width: 58, height: 58, borderRadius: 29, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center', elevation: 6, shadowColor: '#222', shadowOpacity: 0.2, shadowRadius: 8 },
});
