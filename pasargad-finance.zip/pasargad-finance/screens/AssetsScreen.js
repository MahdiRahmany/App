import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, typography } from '../theme';
import { Card, LineChart, PageHeader, Pill, ProgressBar, Screen } from '../components/ui';
import { useFinance } from '../context/FinanceContext';
import { daysUntil, formatNumber, formatToman } from '../utils/format';

const tabs = [
  { key: 'portfolio', label: 'پورتفوی' },
  { key: 'loans', label: 'قسط و وام' },
  { key: 'people', label: 'اشخاص' },
  { key: 'dues', label: 'سررسید و چک' }
];

export default function AssetsScreen({ navigation }) {
  const [tab, setTab] = useState('portfolio');
  const { assets, portfolioTrend, loans, people, dues, categories } = useFinance();
  const total = useMemo(() => assets.reduce((a, b) => a + b.value, 0), [assets]);

  return (
    <Screen>
      <PageHeader title="دارایی‌ها" subtitle="غیرنقدی، بدهی و سررسیدها" />
      <View style={styles.tabs}>{tabs.map((item) => <Pill key={item.key} label={item.label} active={tab === item.key} onPress={() => setTab(item.key)} />)}</View>

      {tab === 'portfolio' ? (
        <>
          <Card style={styles.totalCard}>
            <Text style={styles.muted}>ارزش کل دارایی‌های غیرنقدی</Text>
            <Text style={styles.total}>{formatToman(total)}</Text>
            <View style={styles.trend}><Ionicons name="trending-up" size={17} color={colors.success} /><Text style={styles.trendText}>+۳.۷٪ در ۳۰ روز اخیر</Text></View>
            <LineChart data={portfolioTrend} />
          </Card>
          {assets.map((item) => (
            <Card key={item.id} style={styles.itemCard}>
              <View style={styles.assetRow}>
                <View style={styles.assetIcon}><Ionicons name={item.type === 'gold' ? 'sparkles-outline' : 'logo-bitcoin'} size={21} color={colors.accent} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.assetTitle}>{item.title}</Text>
                  <Text style={styles.muted}>{item.quantity}</Text>
                </View>
                <View>
                  <Text style={styles.assetValue}>{formatToman(item.value)}</Text>
                  <Text style={[styles.change, { color: item.change >= 0 ? colors.success : colors.danger }]}>{item.change >= 0 ? '+' : ''}{formatNumber(item.change)}٪</Text>
                </View>
              </View>
            </Card>
          ))}
        </>
      ) : null}

      {tab === 'loans' ? (
        loans.map((loan) => {
          const remaining = Math.max(0, loan.amount - loan.paid);
          const ratio = loan.paid / Math.max(loan.amount, 1);
          const payable = loan.role === 'payable';
          return (
            <Card key={loan.id} style={styles.itemCard}>
              <View style={styles.assetRow}>
                <View style={[styles.badgeIcon, { backgroundColor: payable ? colors.softRed : colors.softGreen }]}>
                  <Ionicons name={payable ? 'arrow-up-outline' : 'arrow-down-outline'} size={20} color={payable ? colors.danger : colors.success} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.assetTitle}>{loan.title}</Text>
                  <Text style={styles.muted}>{loan.bank} • سررسید {loan.dueDate}</Text>
                </View>
                <Text style={[styles.status, { color: payable ? colors.danger : colors.success }]}>{payable ? 'پرداختی' : 'دریافتی'}</Text>
              </View>
              <ProgressBar value={loan.paid} max={loan.amount} height={8} />
              <View style={styles.loanMeta}><Text style={styles.muted}>باقی‌مانده {formatToman(remaining, true)}</Text><Text style={styles.muted}>قسط {formatToman(loan.installment, true)}</Text></View>
            </Card>
          );
        })
      ) : null}

      {tab === 'people' ? (
        people.map((person) => (
          <Pressable key={person.id} onPress={() => navigation.navigate('PersonDetail', { personId: person.id })}>
            <Card style={styles.itemCard}>
              <View style={styles.assetRow}>
                <View style={styles.avatar}><Text style={styles.avatarText}>{person.avatar}</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.assetTitle}>{person.name}</Text>
                  <Text style={styles.muted}>{person.relation}</Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={[styles.assetValue, { color: person.balance >= 0 ? colors.success : colors.danger }]}>{person.balance >= 0 ? 'طلب ' : 'بدهی '} {formatToman(Math.abs(person.balance), true)}</Text>
                  <Text style={styles.actionHint}>مشاهده پروفایل</Text>
                </View>
              </View>
            </Card>
          </Pressable>
        ))
      ) : null}

      {tab === 'dues' ? (
        dues.map((due) => {
          const left = daysUntil(due.date);
          return (
            <Card key={due.id} style={styles.itemCard}>
              <View style={styles.assetRow}>
                <View style={styles.dueIcon}><Ionicons name={due.kind === 'چک' ? 'document-text-outline' : 'calendar-outline'} size={21} color={colors.accent} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.assetTitle}>{due.title}</Text>
                  <Text style={styles.muted}>{due.kind} • {due.date}</Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={styles.assetValue}>{formatToman(due.amount, true)}</Text>
                  <Text style={[styles.countdown, { color: left <= 3 ? colors.danger : colors.primary }]}>{formatNumber(left)} روز مانده</Text>
                </View>
              </View>
            </Card>
          );
        })
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  tabs: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 7, marginBottom: 10 },
  totalCard: { backgroundColor: colors.primaryDark, marginBottom: 10 },
  muted: { fontFamily: typography.regular, color: colors.muted, textAlign: 'right', fontSize: 11 },
  total: { fontFamily: typography.bold, color: colors.white, fontSize: 24, textAlign: 'right', marginTop: 4 },
  trend: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'flex-start', gap: 5, marginTop: 4 },
  trendText: { fontFamily: typography.bold, color: '#AFE2B7', fontSize: 11 },
  itemCard: { marginBottom: 9 },
  assetRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10 },
  assetIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.softOrange, alignItems: 'center', justifyContent: 'center' },
  badgeIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  dueIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: colors.softOrange, alignItems: 'center', justifyContent: 'center' },
  assetTitle: { fontFamily: typography.bold, color: colors.text, textAlign: 'right', fontSize: 14 },
  assetValue: { fontFamily: typography.bold, color: colors.primary, fontSize: 12, textAlign: 'left' },
  change: { fontFamily: typography.bold, fontSize: 11, marginTop: 3, textAlign: 'left' },
  status: { fontFamily: typography.bold, fontSize: 11 },
  loanMeta: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginTop: 8 },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.lilac, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontFamily: typography.bold, color: colors.primary, fontSize: 17 },
  actionHint: { fontFamily: typography.regular, color: colors.accent, fontSize: 10, marginTop: 3, textAlign: 'left' },
  countdown: { fontFamily: typography.bold, fontSize: 11, marginTop: 3 },
});
