import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, typography } from '../theme';
import { Button, Card, PageHeader, Screen } from '../components/ui';
import { useFinance } from '../context/FinanceContext';

export default function CategoriesScreen({ navigation }) {
  const { categories, patch } = useFinance();
  const [name, setName] = useState('');
  const [subName, setSubName] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [parentId, setParentId] = useState(categories[0]?.id || '');

  const saveCategory = () => {
    if (!name.trim()) return Alert.alert('نام دسته', 'نام دسته‌بندی را وارد کن.');
    if (editingId) {
      patch({ categories: categories.map((c) => c.id === editingId ? { ...c, name: name.trim() } : c) });
    } else {
      patch({ categories: [{ id: `cat-${Date.now()}`, name: name.trim(), icon: 'pricetag-outline', color: colors.accent, subcategories: [] }, ...categories] });
    }
    setName('');
    setEditingId(null);
  };

  const addSubcategory = () => {
    if (!subName.trim() || !parentId) return Alert.alert('زیرمجموعه', 'نام زیرمجموعه را وارد کن.');
    patch({
      categories: categories.map((c) =>
        c.id === parentId ? { ...c, subcategories: [...(c.subcategories || []), subName.trim()] } : c
      )
    });
    setSubName('');
  };

  return (
    <Screen>
      <PageHeader title="مدیریت دسته‌بندی" onBack={() => navigation.goBack()} />
      <Card>
        <Text style={styles.label}>{editingId ? 'ویرایش دسته' : 'دسته جدید'}</Text>
        <TextInput value={name} onChangeText={setName} style={styles.input} placeholder="مثلاً آموزش" textAlign="right" />
        <Button onPress={saveCategory}>{editingId ? 'ذخیره تغییرات' : 'افزودن دسته'}</Button>
      </Card>

      <Card style={{ marginTop: 12 }}>
        <Text style={styles.label}>افزودن زیرمجموعه به یک دسته</Text>
        <View style={styles.parentRow}>
          {categories.slice(0, 4).map((cat) => (
            <Pressable key={cat.id} onPress={() => setParentId(cat.id)} style={[styles.parentPill, parentId === cat.id && styles.parentActive]}>
              <Text style={[styles.parentText, parentId === cat.id && { color: colors.white }]}>{cat.name}</Text>
            </Pressable>
          ))}
        </View>
        <TextInput value={subName} onChangeText={setSubName} style={styles.input} placeholder="مثلاً صبحانه" textAlign="right" />
        <Button variant="outline" onPress={addSubcategory} icon="add-circle-outline">افزودن زیرمجموعه</Button>
      </Card>

      <View style={styles.heading}><Text style={styles.headingText}>دسته‌های فعلی</Text><Text style={styles.muted}>{categories.length} دسته</Text></View>
      <Card>
        {categories.map((item) => (
          <View key={item.id} style={styles.categoryRow}>
            <View style={styles.icon}><Ionicons name={item.icon} size={20} color={item.color} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.muted}>{(item.subcategories || []).length ? item.subcategories.join(' • ') : 'بدون زیرمجموعه'}</Text>
            </View>
            <Pressable onPress={() => { setEditingId(item.id); setName(item.name); }}><Ionicons name="create-outline" size={20} color={colors.accent} /></Pressable>
          </View>
        ))}
      </Card>
    </Screen>
  );
}
const styles = StyleSheet.create({
  label: { fontFamily: typography.bold, color: colors.text, fontSize: 12, textAlign: 'right', marginBottom: 7 },
  input: { height: 50, borderWidth: 1, borderColor: colors.border, borderRadius: 13, backgroundColor: '#FAFAFC', paddingHorizontal: 14, fontFamily: typography.regular, color: colors.text, marginBottom: 12 },
  parentRow: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 7, marginBottom: 10 },
  parentPill: { paddingVertical: 8, paddingHorizontal: 11, borderRadius: 999, backgroundColor: '#F2F1F6' },
  parentActive: { backgroundColor: colors.accent },
  parentText: { fontFamily: typography.regular, color: colors.text, fontSize: 11 },
  heading: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginTop: 20, marginBottom: 10 },
  headingText: { fontFamily: typography.bold, color: colors.text, fontSize: 15 },
  muted: { fontFamily: typography.regular, color: colors.muted, fontSize: 10, textAlign: 'right' },
  categoryRow: { minHeight: 58, flexDirection: 'row-reverse', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: '#F0EFF4' },
  icon: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#F8F7FB', alignItems: 'center', justifyContent: 'center' },
  name: { fontFamily: typography.bold, color: colors.text, fontSize: 13, textAlign: 'right' },
});
