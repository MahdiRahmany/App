import React, { useEffect, useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import * as LocalAuthentication from 'expo-local-authentication';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, typography } from '../theme';
import { Button, Screen } from '../components/ui';
import { useFinance } from '../context/FinanceContext';

export default function LockScreen() {
  const { pin, biometricEnabled, setSessionUnlocked } = useFinance();
  const [value, setValue] = useState('');

  useEffect(() => {
    tryBiometric();
  }, []);

  const tryBiometric = async () => {
    if (!biometricEnabled) return;
    try {
      const hasHardware = await LocalAuthentication.hasHardwareAsync();
      const enrolled = hasHardware && await LocalAuthentication.isEnrolledAsync();
      if (!enrolled) return;
      const result = await LocalAuthentication.authenticateAsync({ promptMessage: 'ورود به پول‌یار' });
      if (result.success) setSessionUnlocked(true);
    } catch {}
  };

  const unlock = () => {
    if (value === pin) setSessionUnlocked(true);
    else {
      setValue('');
      Alert.alert('PIN اشتباه است', 'دوباره امتحان کن.');
    }
  };

  return (
    <Screen scroll={false} style={styles.wrap}>
      <View style={styles.icon}><Ionicons name="lock-closed" size={34} color={colors.white} /></View>
      <Text style={styles.title}>قفل پول‌یار</Text>
      <Text style={styles.subtitle}>برای دیدن اطلاعات مالی PIN را وارد کن.</Text>
      <TextInput
        value={value}
        onChangeText={(t) => setValue(t.replace(/[^0-9]/g, '').slice(0, 4))}
        keyboardType="number-pad"
        secureTextEntry
        maxLength={4}
        autoFocus
        style={styles.pin}
        textAlign="center"
      />
      <Button onPress={unlock}>باز کردن قفل</Button>
      {biometricEnabled ? <Button onPress={tryBiometric} variant="outline" icon="finger-print-outline">ورود با بیومتریک</Button> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  wrap: { justifyContent: 'center', paddingTop: 80 },
  icon: { width: 76, height: 76, borderRadius: 26, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: 18 },
  title: { fontFamily: typography.bold, color: colors.primaryDark, fontSize: 27, textAlign: 'center' },
  subtitle: { fontFamily: typography.regular, color: colors.muted, fontSize: 13, textAlign: 'center', marginTop: 6, marginBottom: 22 },
  pin: { height: 58, borderRadius: 16, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white, fontFamily: typography.bold, fontSize: 26, letterSpacing: 10, color: colors.primary, marginBottom: 14 },
});
