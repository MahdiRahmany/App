import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = '@pasargad-finance/state';

export async function loadState() {
  const raw = await AsyncStorage.getItem(KEY);
  return raw ? JSON.parse(raw) : null;
}

export async function saveState(state) {
  await AsyncStorage.setItem(KEY, JSON.stringify(state));
}

export async function clearState() {
  await AsyncStorage.removeItem(KEY);
}

export async function writeRawState(snapshot) {
  await AsyncStorage.setItem(KEY, JSON.stringify(snapshot));
}
