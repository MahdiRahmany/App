import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system/legacy';

export async function exportBackup(snapshot) {
  const fileUri = `${FileSystem.documentDirectory}pulyar-backup-${Date.now()}.json`;
  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(snapshot, null, 2));
  const canShare = await Sharing.isAvailableAsync();
  if (canShare) await Sharing.shareAsync(fileUri, { mimeType: 'application/json', dialogTitle: 'پشتیبان پول‌یار' });
  return fileUri;
}

export async function importBackup() {
  const picked = await DocumentPicker.getDocumentAsync({
    type: 'application/json',
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (picked.canceled) return null;

  const fileUri = picked.assets?.[0]?.uri;
  if (!fileUri) return null;
  const raw = await FileSystem.readAsStringAsync(fileUri);
  return JSON.parse(raw);
}
