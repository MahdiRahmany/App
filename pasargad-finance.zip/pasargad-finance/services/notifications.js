import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

export async function scheduleFinanceReminder({ enabled, period, time }) {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    if (!enabled) return null;

    const [hour, minute] = time.split(':').map(Number);

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('finance-reminder', {
        name: 'یادآور مالی',
        importance: Notifications.AndroidImportance.DEFAULT,
      });
    }

    const trigger =
      period === 'weekly'
        ? { weekday: 2, hour, minute, repeats: true, channelId: 'finance-reminder' }
        : { hour, minute, repeats: true, channelId: 'finance-reminder' };

    return await Notifications.scheduleNotificationAsync({
      content: {
        title: 'یادآور پول‌یار',
        body: 'یک نگاه کوتاه به دخل‌وخرج امروزت بینداز.',
      },
      trigger,
    });
  } catch (error) {
    return null;
  }
}

export async function requestNotificationPermission() {
  try {
    const { status } = await Notifications.requestPermissionsAsync();
    return status === 'granted';
  } catch {
    return false;
  }
}
