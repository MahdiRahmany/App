export const categories = [
  { id: 'cat_food', name: 'خوراک', icon: 'restaurant-outline', color: '#FF6B47', subcategories: ['رستوران', 'سوپرمارکت', 'نانوایی'] },
  { id: 'cat_transport', name: 'حمل‌ونقل', icon: 'car-outline', color: '#2A1F6E', subcategories: ['مترو', 'تاکسی', 'سوخت'] },
  { id: 'cat_bills', name: 'قبض و خدمات', icon: 'flash-outline', color: '#F59E0B', subcategories: ['برق', 'آب', 'اینترنت'] },
  { id: 'cat_fun', name: 'تفریح', icon: 'game-controller-outline', color: '#7C4DFF', subcategories: ['کافه', 'سینما'] },
  { id: 'cat_shopping', name: 'خرید', icon: 'bag-handle-outline', color: '#0F766E', subcategories: ['پوشاک', 'دیجیتال'] },
  { id: 'cat_health', name: 'سلامت', icon: 'medkit-outline', color: '#2E7D32', subcategories: ['دارو', 'ورزش'] },
  { id: 'cat_salary', name: 'حقوق', icon: 'wallet-outline', color: '#2E7D32', subcategories: ['حقوق ثابت', 'پاداش'] },
];

export const transactions = [
  { id: 't1', title: 'فروشگاه افق کوروش', categoryId: 'cat_food', amount: 485000, type: 'expense', date: '2026-09-24T18:30:00', source: 'sms' },
  { id: 't2', title: 'مترو تهران', categoryId: 'cat_transport', amount: 74000, type: 'expense', date: '2026-09-24T08:20:00', source: 'sms' },
  { id: 't3', title: 'حقوق شهریور', categoryId: 'cat_salary', amount: 48500000, type: 'income', date: '2026-09-23T09:10:00', source: 'manual' },
  { id: 't4', title: 'همراه اول', categoryId: 'cat_bills', amount: 245000, type: 'expense', date: '2026-09-22T14:05:00', source: 'sms' },
  { id: 't5', title: 'اسنپ‌فود', categoryId: 'cat_food', amount: 780000, type: 'expense', date: '2026-09-21T21:18:00', source: 'sms' },
  { id: 't6', title: 'دیجی‌کالا', categoryId: 'cat_shopping', amount: 2190000, type: 'expense', date: '2026-09-20T16:45:00', source: 'manual' },
  { id: 't7', title: 'باشگاه انقلاب', categoryId: 'cat_health', amount: 650000, type: 'expense', date: '2026-09-19T19:30:00', source: 'manual' },
  { id: 't8', title: 'کافه ویونا', categoryId: 'cat_fun', amount: 390000, type: 'expense', date: '2026-09-18T17:50:00', source: 'sms' },
  { id: 't9', title: 'تاکسی اینترنتی', categoryId: 'cat_transport', amount: 182000, type: 'expense', date: '2026-09-17T13:25:00', source: 'sms' },
  { id: 't10', title: 'قبض برق', categoryId: 'cat_bills', amount: 370000, type: 'expense', date: '2026-09-16T10:05:00', source: 'sms' },
  { id: 't11', title: 'رستوران نون‌خور', categoryId: 'cat_food', amount: 1240000, type: 'expense', date: '2026-09-15T20:00:00', source: 'manual' },
  { id: 't12', title: 'پرداخت قسط لپ‌تاپ', categoryId: 'cat_shopping', amount: 2300000, type: 'expense', date: '2026-09-14T11:30:00', source: 'manual' },
  { id: 't13', title: 'سوپرمارکت شهروند', categoryId: 'cat_food', amount: 910000, type: 'expense', date: '2026-08-28T18:30:00', source: 'sms' },
  { id: 't14', title: 'حقوق مرداد', categoryId: 'cat_salary', amount: 47000000, type: 'income', date: '2026-08-25T09:10:00', source: 'manual' },
  { id: 't15', title: 'شارژ ساختمان', categoryId: 'cat_bills', amount: 1200000, type: 'expense', date: '2026-08-12T12:30:00', source: 'manual' },
  { id: 't16', title: 'کافه نزدیک محل کار', categoryId: 'cat_fun', amount: 320000, type: 'expense', date: '2026-07-23T17:20:00', source: 'sms' },
  { id: 't17', title: 'حقوق تیر', categoryId: 'cat_salary', amount: 46000000, type: 'income', date: '2026-07-25T09:10:00', source: 'manual' }
];

export const budgets = [
  { id: 'b1', categoryId: 'cat_food', limit: 9000000, spent: 6840000 },
  { id: 'b2', categoryId: 'cat_transport', limit: 3500000, spent: 1820000 },
  { id: 'b3', categoryId: 'cat_fun', limit: 2800000, spent: 2110000 },
  { id: 'b4', categoryId: 'cat_bills', limit: 4200000, spent: 2890000 },
  { id: 'b5', categoryId: 'cat_shopping', limit: 7000000, spent: 5120000 }
];

export const assets = [
  { id: 'a1', title: 'طلای آب‌شده', type: 'gold', quantity: '۸.۳ گرم', value: 16900000, change: 6.4 },
  { id: 'a2', title: 'بیت‌کوین', type: 'crypto', quantity: '۰.۰۴ BTC', value: 12800000, change: -2.1 },
  { id: 'a3', title: 'تتر', type: 'crypto', quantity: '۱۲۰۰ USDT', value: 12800000, change: 1.8 }
];

export const loans = [
  { id: 'l1', title: 'وام خرید خودرو', bank: 'بانک سامان', role: 'payable', amount: 64000000, paid: 32000000, dueDate: '2026-10-05', installment: 3200000 },
  { id: 'l2', title: 'قسط لپ‌تاپ', bank: 'دیجی‌پی', role: 'payable', amount: 4600000, paid: 2300000, dueDate: '2026-09-28', installment: 2300000 },
  { id: 'l3', title: 'وام خانوادگی', bank: 'دریافتی', role: 'receivable', amount: 12000000, paid: 4000000, dueDate: '2026-11-01', installment: 2000000 }
];

export const people = [
  { id: 'p1', name: 'سارا', relation: 'دوست', balance: 1850000, avatar: 'س' },
  { id: 'p2', name: 'امیر', relation: 'همکار', balance: -920000, avatar: 'ا' },
  { id: 'p3', name: 'مریم', relation: 'خواهر', balance: 450000, avatar: 'م' }
];

export const dues = [
  { id: 'd1', title: 'چک رهن خانه', kind: 'چک', amount: 18000000, date: '2026-09-29' },
  { id: 'd2', title: 'سررسید بیمه خودرو', kind: 'بیمه', amount: 7800000, date: '2026-10-03' },
  { id: 'd3', title: 'قسط وام خودرو', kind: 'قسط', amount: 3200000, date: '2026-10-05' },
  { id: 'd4', title: 'اجاره خانه', kind: 'اجاره', amount: 15500000, date: '2026-10-10' }
];

export const dailySpend = [
  220000, 390000, 120000, 650000, 340000, 920000, 560000, 430000, 780000, 610000,
  990000, 450000, 520000, 700000, 1240000, 390000, 182000, 370000, 650000, 2190000,
  245000, 780000, 485000, 74000, 0, 0, 0, 0, 0, 0
];

export const portfolioTrend = [
  25800000, 26400000, 27200000, 26800000, 28100000, 28900000,
  30100000, 29800000, 31200000, 31500000, 32300000, 32500000
];

export const initialState = {
  onboardingDone: false,
  pin: '',
  biometricEnabled: false,
  reminderEnabled: true,
  reminderPeriod: 'daily',
  reminderTime: '21:00',
  nightMode: false,
  subscriptionStarted: false,
  transactions,
  budgets,
  assets,
  loans,
  people,
  dues,
  categories,
  dailySpend,
  portfolioTrend,
};
