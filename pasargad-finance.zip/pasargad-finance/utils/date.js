export const months = [
  { key: '2026-09', title: 'مهر ۱۴۰۵' },
  { key: '2026-08', title: 'شهریور ۱۴۰۵' },
  { key: '2026-07', title: 'مرداد ۱۴۰۵' },
];

export const faWeekdays = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

export function inMonth(iso, key) {
  return iso.startsWith(key);
}
