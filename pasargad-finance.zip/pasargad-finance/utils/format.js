export function toFa(value) {
  return String(value)
    .replace(/0/g, '۰')
    .replace(/1/g, '۱')
    .replace(/2/g, '۲')
    .replace(/3/g, '۳')
    .replace(/4/g, '۴')
    .replace(/5/g, '۵')
    .replace(/6/g, '۶')
    .replace(/7/g, '۷')
    .replace(/8/g, '۸')
    .replace(/9/g, '۹');
}

export function toEn(value) {
  return String(value)
    .replace(/۰/g, '0')
    .replace(/۱/g, '1')
    .replace(/۲/g, '2')
    .replace(/۳/g, '3')
    .replace(/۴/g, '4')
    .replace(/۵/g, '5')
    .replace(/۶/g, '6')
    .replace(/۷/g, '7')
    .replace(/۸/g, '8')
    .replace(/۹/g, '9');
}

export function formatNumber(value) {
  const number = Number(value || 0);
  return toFa(number.toLocaleString('en-US', { maximumFractionDigits: 0 }));
}

export function formatToman(value, compact = false) {
  const number = Number(value || 0);
  if (compact) return `${formatNumber(number)} ت`;
  return `${formatNumber(number)} تومان`;
}

export function formatDate(iso) {
  const date = new Date(iso);
  return toFa(date.toLocaleDateString('fa-IR', { month: 'short', day: 'numeric' }));
}

export function formatTime(time) {
  return toFa(time);
}

export function daysUntil(iso) {
  const target = new Date(iso);
  const now = new Date('2026-09-25T12:00:00');
  const diff = Math.ceil((target - now) / (1000 * 60 * 60 * 24));
  return diff;
}
