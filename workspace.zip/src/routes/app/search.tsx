import { createFileRoute } from "@tanstack/react-router";
import { SearchScreen } from "@/screens/home/SearchScreen";

export const Route = createFileRoute("/app/search")({ component: SearchScreen });
