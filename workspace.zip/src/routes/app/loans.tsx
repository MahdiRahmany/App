import { createFileRoute } from "@tanstack/react-router";
import { LoansScreen } from "@/screens/assets/LoansScreen";

export const Route = createFileRoute("/app/loans")({ component: LoansScreen });
