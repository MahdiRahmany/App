import { createFileRoute } from "@tanstack/react-router";
import { PeopleScreen } from "@/screens/assets/PeopleScreen";

export const Route = createFileRoute("/app/people/")({ component: PeopleScreen });
