import { createFileRoute } from "@tanstack/react-router";
import { PersonScreen } from "@/screens/assets/PersonScreen";

export const Route = createFileRoute("/app/people/$personId")({ component: PersonScreen });
