import { createFileRoute } from "@tanstack/react-router";
import { ReportsScreen } from "@/screens/reports/ReportsScreen";

export const Route = createFileRoute("/app/reports")({ component: ReportsScreen });
