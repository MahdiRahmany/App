import { createFileRoute } from "@tanstack/react-router";
import { ChecksScreen } from "@/screens/assets/ChecksScreen";

export const Route = createFileRoute("/app/checks")({ component: ChecksScreen });
