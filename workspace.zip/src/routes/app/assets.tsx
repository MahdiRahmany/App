import { createFileRoute } from "@tanstack/react-router";
import { AssetsScreen } from "@/screens/assets/AssetsScreen";

export const Route = createFileRoute("/app/assets")({ component: AssetsScreen });
