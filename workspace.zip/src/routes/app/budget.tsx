import { createFileRoute } from "@tanstack/react-router";
import { BudgetScreen } from "@/screens/budget/BudgetScreen";

export const Route = createFileRoute("/app/budget")({ component: BudgetScreen });
