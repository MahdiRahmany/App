import { createFileRoute } from "@tanstack/react-router";
import { BackupScreen } from "@/screens/settings/BackupScreen";

export const Route = createFileRoute("/app/settings/backup")({ component: BackupScreen });
