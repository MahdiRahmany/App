import { createFileRoute } from "@tanstack/react-router";
import { CategoriesScreen } from "@/screens/settings/CategoriesScreen";

export const Route = createFileRoute("/app/settings/categories")({
  component: CategoriesScreen,
});
