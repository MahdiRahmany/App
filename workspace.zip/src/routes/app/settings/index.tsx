import { createFileRoute } from "@tanstack/react-router";
import { SettingsScreen } from "@/screens/settings/SettingsScreen";

export const Route = createFileRoute("/app/settings/")({ component: SettingsScreen });
