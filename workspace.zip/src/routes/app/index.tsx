import { createFileRoute } from "@tanstack/react-router";
import { HomeScreen } from "@/screens/home/HomeScreen";

export const Route = createFileRoute("/app/")({ component: HomeScreen });
