import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Logo } from "@/components/Logo";
import { PhoneFrame } from "@/navigation/PhoneFrame";
import { useFinanceStore } from "@/store/finance-store";

export const Route = createFileRoute("/")({ component: Gate });

function Gate() {
  const navigate = useNavigate();
  const hydrated = useFinanceStore((s) => s.hydrated);
  const onboarded = useFinanceStore((s) => s.onboarded);
  const pin = useFinanceStore((s) => s.pin);
  const unlocked = useFinanceStore((s) => s.unlocked);

  useEffect(() => {
    if (!hydrated) return;
    if (!onboarded) navigate({ to: "/onboarding" });
    else if (pin && !unlocked) navigate({ to: "/lock" });
    else navigate({ to: "/app" });
  }, [hydrated, onboarded, pin, unlocked, navigate]);

  return (
    <PhoneFrame>
      <div className="flex min-h-svh flex-col items-center justify-center gap-4 px-6">
        <Logo markClass="size-16 rounded-3xl" />
        <p className="text-sm text-muted">دخل‌وخرجت، همیشه دمِ دست</p>
      </div>
    </PhoneFrame>
  );
}
