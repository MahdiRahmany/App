import { createFileRoute } from "@tanstack/react-router";
import { LockScreen } from "@/screens/lock/LockScreen";

export const Route = createFileRoute("/lock")({ component: LockScreen });
