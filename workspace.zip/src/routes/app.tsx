import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/navigation/AppShell";

export const Route = createFileRoute("/app")({ component: AppShell });
