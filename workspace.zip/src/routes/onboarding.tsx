import { createFileRoute } from "@tanstack/react-router";
import { OnboardingFlow } from "@/screens/onboarding/OnboardingFlow";

export const Route = createFileRoute("/onboarding")({ component: OnboardingFlow });
