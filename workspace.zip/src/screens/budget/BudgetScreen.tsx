import { useMemo, useState } from "react";
import { Card } from "@/components/Card";
import { FAB } from "@/components/FAB";
import { MonthSwitcher } from "@/components/MonthSwitcher";
import { ProgressBar } from "@/components/ProgressBar";
import { Sheet } from "@/components/Sheet";
import { AmountField } from "@/components/AmountField";
import { Button } from "@/components/ui/Button";
import { spentInMonth, useFinanceStore } from "@/store/finance-store";
import { formatToman, toFaDigits } from "@/utils/format";
import { jalaliMonthKey } from "@/utils/jalali";
import { CategoryGlyph } from "@/utils/icons";
import { cn } from "@/lib/utils";

export function BudgetScreen() {
  const budgets = useFinanceStore((s) => s.budgets);
  const categories = useFinanceStore((s) => s.categories);
  const transactions = useFinanceStore((s) => s.transactions);
  const addBudget = useFinanceStore((s) => s.addBudget);
  const updateBudget = useFinanceStore((s) => s.updateBudget);
  const removeBudget = useFinanceStore((s) => s.removeBudget);
  const [monthKey, setMonthKey] = useState(() => jalaliMonthKey(new Date()));
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [catId, setCatId] = useState("food");
  const [amount, setAmount] = useState("");

  const rows = useMemo(() => {
    return budgets
      .map((b) => {
        const cat = categories.find((c) => c.id === b.categoryId);
        const spent = spentInMonth(transactions, categories, monthKey, b.categoryId);
        const pct = b.amount ? (spent / b.amount) * 100 : 0;
        return { b, cat, spent, pct };
      })
      .sort((a, b) => b.pct - a.pct);
  }, [budgets, categories, transactions, monthKey]);

  const expenseCats = categories.filter((c) => c.type === "expense" && !c.parentId);

  function openNew() {
    setEditId(null);
    setCatId(expenseCats[0]?.id ?? "food");
    setAmount("");
    setOpen(true);
  }

  function openEdit(id: string, categoryId: string, value: number) {
    setEditId(id);
    setCatId(categoryId);
    setAmount(String(value));
    setOpen(true);
  }

  function save() {
    const n = Number(amount);
    if (!n) return;
    if (editId) updateBudget(editId, n);
    else addBudget(catId, n);
    setOpen(false);
  }

  return (
    <div className="fade-in relative px-4 pb-6 pt-5">
      <h1 className="text-xl font-bold">بودجه</h1>
      <p className="mt-1 text-sm text-muted">سقف هزینه هر دسته در ماه انتخابی</p>
      <div className="mt-4">
        <MonthSwitcher monthKey={monthKey} onChange={setMonthKey} />
      </div>

      <div className="mt-4 space-y-3">
        {rows.map(({ b, cat, spent, pct }) => {
          const over = pct >= 100;
          const warn = pct >= 80;
          return (
            <button
              key={b.id}
              type="button"
              onClick={() => openEdit(b.id, b.categoryId, b.amount)}
              className="w-full text-right"
            >
              <Card>
                <div className="flex items-center gap-3">
                  <span
                    className="flex size-11 items-center justify-center rounded-2xl text-white"
                    style={{ background: cat?.color ?? "var(--color-primary)" }}
                  >
                    <CategoryGlyph icon={cat?.icon ?? "dots"} className="size-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline justify-between gap-2">
                      <p className="font-bold">{cat?.name}</p>
                      <p className={cn("text-xs font-semibold tabular", over ? "text-danger" : "text-muted")}>
                        {toFaDigits(Math.round(pct))}٪
                      </p>
                    </div>
                    <p className="mt-0.5 text-xs text-muted">
                      {formatToman(spent, false)} از {formatToman(b.amount, false)}
                    </p>
                    <ProgressBar
                      className="mt-2"
                      value={pct}
                      tone={over ? "danger" : warn ? "accent" : "success"}
                    />
                  </div>
                </div>
              </Card>
            </button>
          );
        })}
      </div>

      <FAB onClick={openNew} label="بودجه جدید" />

      <Sheet open={open} onClose={() => setOpen(false)} title={editId ? "ویرایش بودجه" : "بودجه جدید"}>
        <div className="space-y-4">
          {!editId ? (
            <div>
              <p className="mb-2 text-sm text-muted">دسته</p>
              <div className="flex flex-wrap gap-2">
                {expenseCats.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setCatId(c.id)}
                    className={cn(
                      "rounded-full px-3 py-2 text-xs font-semibold",
                      catId === c.id ? "bg-accent text-white" : "bg-background",
                    )}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            </div>
          ) : null}
          <AmountField value={amount} onChange={setAmount} label="سقف ماهانه" />
          <Button className="w-full" onClick={save} disabled={!amount}>
            ذخیره
          </Button>
          {editId ? (
            <Button
              variant="ghost"
              className="w-full text-danger"
              onClick={() => {
                removeBudget(editId);
                setOpen(false);
              }}
            >
              حذف بودجه
            </Button>
          ) : null}
        </div>
      </Sheet>
    </div>
  );
}
