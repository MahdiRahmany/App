import { useRef, useState } from "react";
import { Download, Upload } from "lucide-react";
import { ScreenHeader } from "@/components/ScreenHeader";
import { Card } from "@/components/Card";
import { Button } from "@/components/ui/Button";
import { useFinanceStore } from "@/store/finance-store";
import type { FinanceSnapshot } from "@/data/types";

function isSnapshot(v: unknown): v is FinanceSnapshot {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return Array.isArray(o.transactions) && Array.isArray(o.categories);
}

export function BackupScreen() {
  const exportSnapshot = useFinanceStore((s) => s.exportSnapshot);
  const importSnapshot = useFinanceStore((s) => s.importSnapshot);
  const inputRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  function download() {
    const data = exportSnapshot();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "hesabino-backup.json";
    a.click();
    URL.revokeObjectURL(url);
    setMessage("فایل پشتیبان دانلود شد.");
    setError("");
  }

  async function onFile(file: File) {
    try {
      const text = await file.text();
      const parsed: unknown = JSON.parse(text);
      if (!isSnapshot(parsed)) throw new Error("invalid");
      importSnapshot(parsed);
      setMessage("بازیابی با موفقیت انجام شد.");
      setError("");
    } catch {
      setError("فایل نامعتبر است. یک خروجی JSON حسابینو انتخاب کن.");
      setMessage("");
    }
  }

  return (
    <div className="fade-in pb-6">
      <ScreenHeader title="پشتیبان‌گیری و بازیابی" backTo="/app/settings" />
      <div className="space-y-3 px-4">
        <p className="text-sm leading-7 text-muted">
          همه داده‌ها فقط روی همین مرورگر ذخیره می‌شود. می‌توانی یک فایل JSON بگیری و بعداً همان را برگردانی — بدون سرور.
        </p>
        <Card>
          <div className="flex items-start gap-3">
            <span className="flex size-11 items-center justify-center rounded-2xl bg-accent-soft text-accent">
              <Download className="size-5" />
            </span>
            <div className="flex-1">
              <p className="font-bold">خروجی گرفتن</p>
              <p className="mt-1 text-xs leading-6 text-muted">تراکنش، بودجه، دارایی و تنظیمات در یک فایل.</p>
              <Button className="mt-3 h-10 text-xs" onClick={download}>
                دانلود JSON
              </Button>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-start gap-3">
            <span className="flex size-11 items-center justify-center rounded-2xl bg-primary-soft text-primary">
              <Upload className="size-5" />
            </span>
            <div className="flex-1">
              <p className="font-bold">بازیابی</p>
              <p className="mt-1 text-xs leading-6 text-muted">فایل قبلی جایگزین داده فعلی می‌شود.</p>
              <Button variant="secondary" className="mt-3 h-10 text-xs" onClick={() => inputRef.current?.click()}>
                انتخاب فایل
              </Button>
              <input
                ref={inputRef}
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void onFile(f);
                  e.target.value = "";
                }}
              />
            </div>
          </div>
        </Card>
        {message ? <p className="text-sm font-medium text-success">{message}</p> : null}
        {error ? <p className="text-sm font-medium text-danger">{error}</p> : null}
      </div>
    </div>
  );
}
