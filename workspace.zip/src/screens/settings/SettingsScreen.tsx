import { Link } from "@tanstack/react-router";
import {
  ChevronLeft,
  DatabaseBackup,
  Fingerprint,
  FolderTree,
  Moon,
  RotateCcw,
  Shield,
} from "lucide-react";
import { Card } from "@/components/Card";
import { Switch } from "@/components/ui/Switch";
import { Button } from "@/components/ui/Button";
import { useFinanceStore } from "@/store/finance-store";
import { toFaDigits } from "@/utils/format";

function trialLeft(iso: string | null): number {
  if (!iso) return 31;
  const start = new Date(iso).getTime();
  const end = start + 31 * 86400000;
  return Math.max(0, Math.ceil((end - Date.now()) / 86400000));
}

export function SettingsScreen() {
  const darkMode = useFinanceStore((s) => s.darkMode);
  const setDarkMode = useFinanceStore((s) => s.setDarkMode);
  const biometric = useFinanceStore((s) => s.biometric);
  const pin = useFinanceStore((s) => s.pin);
  const smsGranted = useFinanceStore((s) => s.smsGranted);
  const trialStartedAt = useFinanceStore((s) => s.trialStartedAt);
  const userName = useFinanceStore((s) => s.userName);
  const resetDemo = useFinanceStore((s) => s.resetDemo);
  const days = trialLeft(trialStartedAt);

  return (
    <div className="fade-in px-4 pb-6 pt-5">
      <h1 className="text-xl font-bold">تنظیمات</h1>
      <Card className="mt-4 flex items-center gap-3">
        <span className="flex size-12 items-center justify-center rounded-2xl bg-primary text-white font-bold">
          {userName.split(" ").map((p) => p[0]).join("").slice(0, 2)}
        </span>
        <div>
          <p className="font-bold">{userName}</p>
          <p className="text-xs text-muted">
            {days > 0 ? `${toFaDigits(days)} روز از دوره آزمایشی باقی است` : "دوره آزمایشی تمام شده"}
          </p>
        </div>
      </Card>

      <div className="mt-4 space-y-2">
        <Row to="/app/settings/categories" icon={FolderTree} title="دسته‌بندی‌ها" desc="افزودن و ویرایش دسته و زیرمجموعه" />
        <Row to="/app/settings/backup" icon={DatabaseBackup} title="پشتیبان‌گیری" desc="خروجی و بازیابی فایل JSON محلی" />
      </div>

      <Card className="mt-4 space-y-4">
        <Switch label="حالت شب" checked={darkMode} onCheckedChange={setDarkMode} />
        <div className="flex items-center gap-3 text-sm">
          <Fingerprint className="size-4 text-accent" />
          <span>اثر انگشت: {biometric ? "فعال" : "خاموش"}</span>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <Shield className="size-4 text-accent" />
          <span>قفل PIN: {pin ? "تنظیم شده" : "ندارد"}</span>
        </div>
        <p className="text-xs leading-6 text-muted">
          {smsGranted
            ? "دسترسی پیامک در همین دستگاه شبیه‌سازی شده. مرورگر وب نمی‌تواند پیامک واقعی بانک را بخواند."
            : "خواندن پیامک بانکی روی وب امکان‌پذیر نیست؛ تراکنش‌ها را دستی ثبت کن یا از داده نمونه استفاده کن."}
        </p>
      </Card>

      <Card className="mt-4">
        <div className="flex items-start gap-3">
          <RotateCcw className="mt-0.5 size-4 text-muted" />
          <div className="flex-1">
            <p className="font-semibold">بازگشت به داده نمونه</p>
            <p className="mt-1 text-xs leading-6 text-muted">تراکنش‌ها و بودجه‌ها به حالت اولیه دمو برمی‌گردند.</p>
            <Button variant="soft" className="mt-3 h-10 text-xs" onClick={resetDemo}>
              بازنشانی داده
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

function Row({
  to,
  icon: Icon,
  title,
  desc,
}: {
  to: "/app/settings/categories" | "/app/settings/backup";
  icon: typeof FolderTree;
  title: string;
  desc: string;
}) {
  return (
    <Link to={to} className="block">
      <Card className="flex items-center gap-3">
        <span className="flex size-11 items-center justify-center rounded-2xl bg-primary-soft text-primary">
          <Icon className="size-5" />
        </span>
        <span className="flex-1">
          <span className="block font-bold">{title}</span>
          <span className="block text-xs text-muted">{desc}</span>
        </span>
        <ChevronLeft className="size-5 text-muted" />
      </Card>
    </Link>
  );
}
