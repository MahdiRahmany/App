import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { ScreenHeader } from "@/components/ScreenHeader";
import { Card } from "@/components/Card";
import { Sheet } from "@/components/Sheet";
import { TextField } from "@/components/AmountField";
import { Button } from "@/components/ui/Button";
import { Segmented } from "@/components/Segmented";
import { useFinanceStore } from "@/store/finance-store";
import { CategoryGlyph } from "@/utils/icons";
import type { TxType } from "@/data/types";
import { cn } from "@/lib/utils";

const ICONS = ["utensils", "car", "zap", "clapper", "heart", "bag", "home", "edu", "dots", "banknote"] as const;
const COLORS = [
  "var(--color-cat-food)",
  "var(--color-cat-transport)",
  "var(--color-cat-bills)",
  "var(--color-cat-fun)",
  "var(--color-cat-health)",
  "var(--color-cat-shop)",
  "var(--color-cat-home)",
  "var(--color-cat-edu)",
];

export function CategoriesScreen() {
  const categories = useFinanceStore((s) => s.categories);
  const addCategory = useFinanceStore((s) => s.addCategory);
  const updateCategory = useFinanceStore((s) => s.updateCategory);
  const removeCategory = useFinanceStore((s) => s.removeCategory);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [type, setType] = useState<TxType>("expense");
  const [icon, setIcon] = useState<string>("dots");
  const [color, setColor] = useState(COLORS[0]!);
  const [parentId, setParentId] = useState<string>("");

  const roots = categories.filter((c) => !c.parentId);

  function openNew() {
    setEditId(null);
    setName("");
    setType("expense");
    setIcon("dots");
    setColor(COLORS[0]!);
    setParentId("");
    setOpen(true);
  }

  function openEdit(id: string) {
    const c = categories.find((x) => x.id === id);
    if (!c) return;
    setEditId(id);
    setName(c.name);
    setType(c.type);
    setIcon(c.icon);
    setColor(c.color);
    setParentId(c.parentId ?? "");
    setOpen(true);
  }

  function save() {
    if (!name.trim()) return;
    if (editId) {
      updateCategory(editId, { name: name.trim(), icon, color, parentId: parentId || undefined, type });
    } else {
      addCategory({
        name: name.trim(),
        icon,
        color,
        type,
        parentId: parentId || undefined,
      });
    }
    setOpen(false);
  }

  return (
    <div className="fade-in pb-6">
      <ScreenHeader
        title="دسته‌بندی‌ها"
        backTo="/app/settings"
        action={
          <button
            type="button"
            onClick={openNew}
            className="flex size-11 items-center justify-center rounded-2xl bg-accent text-white"
            aria-label="دسته جدید"
          >
            <Plus className="size-5" />
          </button>
        }
      />
      <div className="space-y-2 px-4">
        {roots.map((c) => {
          const children = categories.filter((x) => x.parentId === c.id);
          return (
            <Card key={c.id}>
              <div className="flex items-center gap-3">
                <span
                  className="flex size-10 items-center justify-center rounded-xl text-white"
                  style={{ background: c.color }}
                >
                  <CategoryGlyph icon={c.icon} className="size-4" />
                </span>
                <span className="flex-1 font-bold">{c.name}</span>
                <span className="text-[11px] text-muted">{c.type === "income" ? "درآمد" : "هزینه"}</span>
                <button type="button" onClick={() => openEdit(c.id)} aria-label="ویرایش" className="p-2">
                  <Pencil className="size-4 text-muted" />
                </button>
                <button type="button" onClick={() => removeCategory(c.id)} aria-label="حذف" className="p-2">
                  <Trash2 className="size-4 text-danger" />
                </button>
              </div>
              {children.length > 0 ? (
                <ul className="mt-3 space-y-2 border-r border-line pr-3">
                  {children.map((ch) => (
                    <li key={ch.id} className="flex items-center justify-between text-sm">
                      <span>{ch.name}</span>
                      <span className="flex">
                        <button type="button" className="p-2" onClick={() => openEdit(ch.id)} aria-label="ویرایش">
                          <Pencil className="size-3.5 text-muted" />
                        </button>
                        <button type="button" className="p-2" onClick={() => removeCategory(ch.id)} aria-label="حذف">
                          <Trash2 className="size-3.5 text-danger" />
                        </button>
                      </span>
                    </li>
                  ))}
                </ul>
              ) : null}
            </Card>
          );
        })}
      </div>

      <Sheet open={open} onClose={() => setOpen(false)} title={editId ? "ویرایش دسته" : "دسته جدید"}>
        <div className="space-y-4">
          <Segmented
            value={type}
            onChange={setType}
            options={[
              { value: "expense", label: "هزینه" },
              { value: "income", label: "درآمد" },
            ]}
          />
          <TextField value={name} onChange={setName} label="نام دسته" />
          <label className="block">
            <span className="mb-1.5 block text-sm text-muted">زیرمجموعهٔ (اختیاری)</span>
            <select
              value={parentId}
              onChange={(e) => setParentId(e.target.value)}
              className="h-12 w-full rounded-2xl bg-background px-3 text-sm ring-1 ring-line"
            >
              <option value="">دسته اصلی</option>
              {roots
                .filter((c) => c.type === type && c.id !== editId)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
            </select>
          </label>
          <div>
            <p className="mb-2 text-sm text-muted">آیکون</p>
            <div className="flex flex-wrap gap-2">
              {ICONS.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setIcon(ic)}
                  className={cn(
                    "flex size-10 items-center justify-center rounded-xl",
                    icon === ic ? "bg-accent text-white" : "bg-background",
                  )}
                >
                  <CategoryGlyph icon={ic} className="size-4" />
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-2 text-sm text-muted">رنگ</p>
            <div className="flex flex-wrap gap-2">
              {COLORS.map((col) => (
                <button
                  key={col}
                  type="button"
                  onClick={() => setColor(col)}
                  className={cn("size-8 rounded-full ring-2", color === col ? "ring-ink" : "ring-transparent")}
                  style={{ background: col }}
                />
              ))}
            </div>
          </div>
          <Button className="w-full" onClick={save} disabled={!name.trim()}>
            ذخیره
          </Button>
        </div>
      </Sheet>
    </div>
  );
}
