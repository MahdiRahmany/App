import { useMemo, useState } from "react";
import { AmountField, TextField } from "@/components/AmountField";
import { Sheet } from "@/components/Sheet";
import { Button } from "@/components/ui/Button";
import { Segmented } from "@/components/Segmented";
import type { Category, TxType } from "@/data/types";
import { isoDate, toJalali } from "@/utils/jalali";
import { cn } from "@/lib/utils";

export function AddTransactionSheet({
  open,
  onClose,
  categories,
  onSubmit,
}: {
  open: boolean;
  onClose: () => void;
  categories: Category[];
  onSubmit: (payload: {
    amount: number;
    type: TxType;
    categoryId: string;
    title: string;
    merchant: string;
    date: string;
  }) => void;
}) {
  const [type, setType] = useState<TxType>("expense");
  const [amount, setAmount] = useState("");
  const [title, setTitle] = useState("");
  const [merchant, setMerchant] = useState("");
  const [categoryId, setCategoryId] = useState("food");
  const today = isoDate(new Date());
  const [date, setDate] = useState(today);

  const cats = useMemo(
    () => categories.filter((c) => c.type === type && !c.parentId),
    [categories, type],
  );

  function submit() {
    const n = Number(amount);
    if (!n || !title.trim()) return;
    onSubmit({
      amount: n,
      type,
      categoryId,
      title: title.trim(),
      merchant: merchant.trim() || title.trim(),
      date,
    });
    setAmount("");
    setTitle("");
    setMerchant("");
    onClose();
  }

  const { jy, jm, jd } = toJalali(date);

  return (
    <Sheet open={open} onClose={onClose} title="تراکنش جدید">
      <div className="space-y-4">
        <Segmented
          value={type}
          onChange={setType}
          options={[
            { value: "expense", label: "هزینه" },
            { value: "income", label: "درآمد" },
          ]}
        />
        <AmountField value={amount} onChange={setAmount} />
        <TextField value={title} onChange={setTitle} label="عنوان" placeholder="مثلاً ناهار کاری" />
        <TextField value={merchant} onChange={setMerchant} label="فروشگاه / مبدأ" placeholder="اختیاری" />
        <div>
          <p className="mb-2 text-sm font-medium text-muted">دسته‌بندی</p>
          <div className="flex flex-wrap gap-2">
            {cats.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCategoryId(c.id)}
                className={cn(
                  "rounded-full px-3 py-2 text-xs font-semibold",
                  categoryId === c.id ? "bg-accent text-white" : "bg-background text-ink",
                )}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>
        <TextField value={date} onChange={setDate} label={`تاریخ (میلادی برای ورودی) — ${jy}/${jm}/${jd}`} type="date" />
        <Button className="w-full" onClick={submit} disabled={!amount || !title.trim()}>
          ثبت تراکنش
        </Button>
      </div>
    </Sheet>
  );
}
