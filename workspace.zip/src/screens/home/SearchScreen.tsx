import { useMemo, useState } from "react";
import { ScreenHeader } from "@/components/ScreenHeader";
import { TransactionRow } from "@/components/TransactionRow";
import { Card } from "@/components/Card";
import { AmountField } from "@/components/AmountField";
import { useFinanceStore } from "@/store/finance-store";
import { cn } from "@/lib/utils";
import { formatJalali } from "@/utils/format";

const RANGES = [
  { id: "all", label: "همه" },
  { id: "week", label: "این هفته" },
  { id: "month", label: "این ماه" },
] as const;

export function SearchScreen() {
  const transactions = useFinanceStore((s) => s.transactions);
  const categories = useFinanceStore((s) => s.categories);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");
  const [range, setRange] = useState<(typeof RANGES)[number]["id"]>("all");
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const roots = categories.filter((c) => !c.parentId);

  const results = useMemo(() => {
    const now = new Date();
    const weekAgo = new Date(now);
    weekAgo.setDate(now.getDate() - 7);
    const monthAgo = new Date(now);
    monthAgo.setDate(now.getDate() - 31);
    const minN = min ? Number(min) : 0;
    const maxN = max ? Number(max) : Infinity;
    const query = q.trim();
    return transactions
      .filter((t) => {
        if (query && !`${t.title} ${t.merchant}`.includes(query)) return false;
        if (cat !== "all") {
          const c = categories.find((x) => x.id === t.categoryId);
          if (t.categoryId !== cat && c?.parentId !== cat) return false;
        }
        const d = new Date(t.date);
        if (range === "week" && d < weekAgo) return false;
        if (range === "month" && d < monthAgo) return false;
        if (t.amount < minN || t.amount > maxN) return false;
        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [transactions, categories, q, cat, range, min, max]);

  return (
    <div className="fade-in pb-6">
      <ScreenHeader title="جستجوی تراکنش" backTo="/app" />
      <div className="px-4">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="نام فروشگاه یا عنوان…"
          className="h-12 w-full rounded-2xl bg-card px-4 text-sm outline-none ring-1 ring-line card-shadow focus:ring-2 focus:ring-accent"
        />
        <button
          type="button"
          className="mt-3 text-xs font-semibold text-accent"
          onClick={() => setShowFilters((s) => !s)}
        >
          {showFilters ? "بستن فیلترها" : "فیلتر دسته، تاریخ و مبلغ"}
        </button>
        {showFilters ? (
          <Card className="mt-3 space-y-4">
            <div>
              <p className="mb-2 text-xs font-medium text-muted">بازه زمانی</p>
              <div className="flex gap-2">
                {RANGES.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setRange(r.id)}
                    className={cn(
                      "h-9 flex-1 rounded-xl text-xs font-semibold",
                      range === r.id ? "bg-accent text-white" : "bg-background",
                    )}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-2 text-xs font-medium text-muted">دسته</p>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setCat("all")}
                  className={cn(
                    "rounded-full px-3 py-1.5 text-xs font-semibold",
                    cat === "all" ? "bg-accent text-white" : "bg-background",
                  )}
                >
                  همه
                </button>
                {roots.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setCat(c.id)}
                    className={cn(
                      "rounded-full px-3 py-1.5 text-xs font-semibold",
                      cat === c.id ? "bg-accent text-white" : "bg-background",
                    )}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <AmountField value={min} onChange={setMin} label="حداقل مبلغ" />
              <AmountField value={max} onChange={setMax} label="حداکثر مبلغ" />
            </div>
          </Card>
        ) : null}

        <p className="mt-4 text-xs text-muted">{results.length.toLocaleString("fa-IR")} نتیجه</p>
        <Card className="mt-2 space-y-1">
          {results.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted">تراکنشی با این فیلتر پیدا نشد</p>
          ) : (
            results.map((tx) => (
              <div key={tx.id}>
                <TransactionRow tx={tx} categories={categories} />
                <p className="px-1 pb-2 text-[10px] text-muted">{formatJalali(tx.date)}</p>
              </div>
            ))
          )}
        </Card>
      </div>
    </div>
  );
}
