import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Bell, Plus, Search, TrendingDown, TrendingUp } from "lucide-react";
import { Card } from "@/components/Card";
import { MonthSwitcher } from "@/components/MonthSwitcher";
import { TransactionRow } from "@/components/TransactionRow";
import { BarTrend } from "@/components/charts/BarTrend";
import { Sheet } from "@/components/Sheet";
import { AddTransactionSheet } from "./AddTransactionSheet";
import { monthTotals, useFinanceStore } from "@/store/finance-store";
import { formatCompact, formatJalali, formatToman, toFaDigits } from "@/utils/format";
import { jalaliMonthKey, monthRange, parseMonthKey, isoDate } from "@/utils/jalali";

export function HomeScreen() {
  const userName = useFinanceStore((s) => s.userName);
  const transactions = useFinanceStore((s) => s.transactions);
  const categories = useFinanceStore((s) => s.categories);
  const addTransaction = useFinanceStore((s) => s.addTransaction);
  const smsGranted = useFinanceStore((s) => s.smsGranted);
  const [monthKey, setMonthKey] = useState(() => jalaliMonthKey(new Date()));
  const [openAdd, setOpenAdd] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);

  const { jy, jm } = parseMonthKey(monthKey);
  const { days } = monthRange(jy, jm);
  const { list, income, expense, net } = useMemo(
    () => monthTotals(transactions, monthKey),
    [transactions, monthKey],
  );

  const bars = useMemo(() => {
    const { start } = monthRange(jy, jm);
    return Array.from({ length: days }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const key = isoDate(d);
      const value = list
        .filter((t) => t.date === key && t.type === "expense")
        .reduce((s, t) => s + t.amount, 0);
      return { day: i + 1, value };
    });
  }, [days, jy, jm, list]);

  const recent = list.slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);
  const selectedTx = transactions.find((t) => t.id === selected);
  const firstName = userName.split(" ")[0] ?? userName;

  return (
    <div className="fade-in px-4 pb-6">
      <header className="flex items-center justify-between pt-5">
        <div>
          <p className="text-sm text-muted">{formatJalali(new Date(), { weekday: true })}</p>
          <h1 className="text-xl font-bold">سلام، {firstName}</h1>
        </div>
        <div className="flex gap-2">
          <Link
            to="/app/search"
            className="flex size-11 items-center justify-center rounded-2xl bg-card card-shadow"
            aria-label="جستجو"
          >
            <Search className="size-5" />
          </Link>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-2xl bg-card card-shadow"
            aria-label="اعلان‌ها"
          >
            <Bell className="size-5" />
          </button>
        </div>
      </header>

      {smsGranted ? (
        <p className="mt-3 rounded-2xl bg-primary-soft px-3 py-2 text-xs text-primary">
          {toFaDigits(12)} پیامک بانکی خوانده شد و به تراکنش‌ها اضافه گردید.
        </p>
      ) : null}

      <div className="mt-4">
        <MonthSwitcher monthKey={monthKey} onChange={setMonthKey} />
      </div>

      <Card className="mt-4 bg-primary-dark p-5 text-white">
        <p className="text-xs text-white/70">مانده این ماه</p>
        <p className="mt-1 text-3xl font-bold tabular">{formatToman(net)}</p>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-white/10 p-3">
            <p className="flex items-center gap-1 text-[11px] text-white/70">
              <TrendingUp className="size-3.5 text-success" /> درآمد
            </p>
            <p className="mt-1 font-bold tabular text-white">{formatCompact(income)}</p>
          </div>
          <div className="rounded-2xl bg-white/10 p-3">
            <p className="flex items-center gap-1 text-[11px] text-white/70">
              <TrendingDown className="size-3.5 text-accent" /> هزینه
            </p>
            <p className="mt-1 font-bold tabular text-white">{formatCompact(expense)}</p>
          </div>
        </div>
      </Card>

      <Card className="mt-4">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-bold">روند روزانه هزینه</h2>
          <span className="text-xs text-muted">{toFaDigits(days)} روز</span>
        </div>
        <BarTrend data={bars} />
      </Card>

      <div className="mt-5 flex items-center justify-between">
        <h2 className="font-bold">آخرین تراکنش‌ها</h2>
        <div className="flex items-center gap-2">
          <Link to="/app/search" className="text-xs font-semibold text-accent">
            همه
          </Link>
          <button
            type="button"
            onClick={() => setOpenAdd(true)}
            className="flex size-9 items-center justify-center rounded-xl bg-accent text-white"
            aria-label="تراکنش جدید"
          >
            <Plus className="size-4" />
          </button>
        </div>
      </div>
      <Card className="mt-2 space-y-1">
        {recent.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted">برای این ماه تراکنشی نیست</p>
        ) : (
          recent.map((tx) => (
            <TransactionRow
              key={tx.id}
              tx={tx}
              categories={categories}
              onClick={() => setSelected(tx.id)}
            />
          ))
        )}
      </Card>

      <AddTransactionSheet
        open={openAdd}
        onClose={() => setOpenAdd(false)}
        categories={categories}
        onSubmit={(payload) => addTransaction({ ...payload, source: "manual" })}
      />

      <Sheet
        open={!!selectedTx}
        onClose={() => setSelected(null)}
        title={selectedTx?.title}
      >
        {selectedTx ? (
          <div className="space-y-3 text-sm">
            <p className={selectedTx.type === "income" ? "text-2xl font-bold text-success" : "text-2xl font-bold text-danger"}>
              {selectedTx.type === "income" ? "+" : "−"}
              {formatToman(selectedTx.amount)}
            </p>
            <p className="text-muted">{selectedTx.merchant}</p>
            <p>{formatJalali(selectedTx.date, { weekday: true })}</p>
            <p className="text-xs text-muted">
              منبع: {selectedTx.source === "sms" ? "پیامک بانکی" : "ثبت دستی"}
            </p>
            {selectedTx.note ? <p>{selectedTx.note}</p> : null}
          </div>
        ) : null}
      </Sheet>
    </div>
  );
}
