import { useMemo, useState } from "react";
import { Moon, Sun, Smartphone } from "lucide-react";
import { Card } from "@/components/Card";
import { ProgressBar } from "@/components/ProgressBar";
import { Segmented } from "@/components/Segmented";
import { DonutChart } from "@/components/charts/DonutChart";
import { Switch } from "@/components/ui/Switch";
import { expenseByCategory, monthTotals, useFinanceStore } from "@/store/finance-store";
import { formatCompact, formatToman, toFaDigits } from "@/utils/format";
import { jalaliMonthKey, isoDate } from "@/utils/jalali";
import { cn } from "@/lib/utils";
import { CategoryGlyph } from "@/utils/icons";

export function ReportsScreen() {
  const transactions = useFinanceStore((s) => s.transactions);
  const categories = useFinanceStore((s) => s.categories);
  const budgets = useFinanceStore((s) => s.budgets);
  const checks = useFinanceStore((s) => s.checks);
  const darkMode = useFinanceStore((s) => s.darkMode);
  const setDarkMode = useFinanceStore((s) => s.setDarkMode);
  const [mode, setMode] = useState<"month" | "day">("month");

  const todayKey = isoDate(new Date());
  const monthKey = jalaliMonthKey(new Date());

  const slices = useMemo(() => {
    if (mode === "day") {
      const dayTx = transactions.filter((t) => t.date === todayKey && t.type === "expense");
      const map = new Map<string, number>();
      for (const t of dayTx) {
        const id = t.categoryId;
        map.set(id, (map.get(id) ?? 0) + t.amount);
      }
      return [...map.entries()]
        .map(([id, amount]) => {
          const c = categories.find((x) => x.id === id);
          return { name: c?.name ?? "سایر", value: amount, color: c?.color ?? "var(--color-cat-other)", icon: c?.icon ?? "dots" };
        })
        .sort((a, b) => b.value - a.value);
    }
    return expenseByCategory(transactions, categories, monthKey).map((x) => ({
      name: x.category!.name,
      value: x.amount,
      color: x.category!.color,
      icon: x.category!.icon,
    }));
  }, [mode, transactions, categories, todayKey, monthKey]);

  const totals = monthTotals(transactions, monthKey);
  const todaySpend = transactions
    .filter((t) => t.date === todayKey && t.type === "expense")
    .reduce((s, t) => s + t.amount, 0);
  const budgetSum = budgets.reduce((s, b) => s + b.amount, 0);
  const remaining = Math.max(0, budgetSum - totals.expense);
  const upcoming = checks.filter((c) => c.status !== "done").length;

  return (
    <div className="fade-in px-4 pb-6 pt-5">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">گزارش‌ها</h1>
        <button
          type="button"
          onClick={() => setDarkMode(!darkMode)}
          className="flex size-11 items-center justify-center rounded-2xl bg-card card-shadow"
          aria-label="حالت شب"
        >
          {darkMode ? <Sun className="size-5 text-accent" /> : <Moon className="size-5" />}
        </button>
      </div>

      <div className="mt-4">
        <Segmented
          value={mode}
          onChange={setMode}
          options={[
            { value: "day", label: "روزانه" },
            { value: "month", label: "ماهانه" },
          ]}
        />
      </div>

      <Card className="mt-4">
        {slices.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted">در این بازه هزینه‌ای ثبت نشده</p>
        ) : (
          <DonutChart data={slices} center={mode === "day" ? "امروز" : "این ماه"} />
        )}
      </Card>

      <h2 className="mt-5 font-bold">پرهزینه‌ترین‌ها</h2>
      <Card className="mt-2 space-y-4">
        {slices.slice(0, 6).map((s, i) => {
          const max = slices[0]?.value || 1;
          return (
            <div key={s.name} className="flex items-center gap-3">
              <span className="w-5 text-xs text-muted">{toFaDigits(i + 1)}</span>
              <span
                className="flex size-9 items-center justify-center rounded-xl text-white"
                style={{ background: s.color }}
              >
                <CategoryGlyph icon={s.icon} className="size-4" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex justify-between text-sm">
                  <span className="font-semibold">{s.name}</span>
                  <span className="tabular text-muted">{formatCompact(s.value)}</span>
                </div>
                <ProgressBar value={(s.value / max) * 100} />
              </div>
            </div>
          );
        })}
        {slices.length === 0 ? <p className="py-6 text-center text-sm text-muted">داده‌ای نیست</p> : null}
      </Card>

      <h2 className="mt-5 flex items-center gap-2 font-bold">
        <Smartphone className="size-4 text-accent" />
        ویجت خلاصه سریع
      </h2>
      <Card className={cn("mt-2 p-5", darkMode ? "bg-primary-dark text-white" : "bg-primary text-white")}>
        <p className="text-xs text-white/70">حسابینو · امروز</p>
        <p className="mt-2 text-sm">خرج امروز</p>
        <p className="text-2xl font-bold tabular">{formatToman(todaySpend)}</p>
        <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <div className="rounded-2xl bg-white/10 p-3">
            <p className="text-[11px] text-white/70">باقی بودجه</p>
            <p className="font-bold tabular">{formatCompact(remaining)}</p>
          </div>
          <div className="rounded-2xl bg-white/10 p-3">
            <p className="text-[11px] text-white/70">سررسید باز</p>
            <p className="font-bold tabular">{toFaDigits(upcoming)} مورد</p>
          </div>
        </div>
      </Card>

      <Card className="mt-4">
        <Switch
          label="حالت شب"
          description="پس‌زمینه تیره برای کل برنامه"
          checked={darkMode}
          onCheckedChange={setDarkMode}
        />
      </Card>
    </div>
  );
}
