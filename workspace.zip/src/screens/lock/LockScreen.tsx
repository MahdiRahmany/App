import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Fingerprint } from "lucide-react";
import { PhoneFrame } from "@/navigation/PhoneFrame";
import { PinDots, PinPad } from "@/components/PinPad";
import { Logo } from "@/components/Logo";
import { useFinanceStore } from "@/store/finance-store";

export function LockScreen() {
  const navigate = useNavigate();
  const unlockWithPin = useFinanceStore((s) => s.unlockWithPin);
  const unlockBiometric = useFinanceStore((s) => s.unlockBiometric);
  const biometric = useFinanceStore((s) => s.biometric);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  function tryUnlock(next: string) {
    setPin(next);
    setError("");
    if (next.length === 4) {
      if (unlockWithPin(next)) navigate({ to: "/app" });
      else {
        setError("رمز نادرست است");
        setPin("");
      }
    }
  }

  return (
    <PhoneFrame>
      <div className="flex min-h-svh flex-col items-center px-6 pt-16 pb-10">
        <Logo />
        <p className="mt-8 text-lg font-bold">قفل فقط برای خودت</p>
        <p className="mt-1 text-sm text-muted">رمز چهار رقمی را وارد کن</p>
        <div className="mt-8">
          <PinDots length={4} filled={pin.length} />
        </div>
        {error ? <p className="mt-3 text-sm font-medium text-danger">{error}</p> : <div className="mt-3 h-5" />}
        <div className="mt-6 w-full">
          <PinPad
            onDigit={(d) => {
              if (pin.length < 4) tryUnlock(pin + d);
            }}
            onBackspace={() => setPin((p) => p.slice(0, -1))}
          />
        </div>
        {biometric ? (
          <button
            type="button"
            className="mt-8 flex items-center gap-2 text-sm font-semibold text-accent"
            onClick={() => {
              if (unlockBiometric()) navigate({ to: "/app" });
            }}
          >
            <Fingerprint className="size-5" />
            ورود با اثر انگشت
          </button>
        ) : null}
      </div>
    </PhoneFrame>
  );
}
