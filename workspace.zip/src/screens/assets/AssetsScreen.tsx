import { Link } from "@tanstack/react-router";
import { ChevronLeft, Coins, FileSpreadsheet, Handshake, Receipt } from "lucide-react";
import { Card } from "@/components/Card";
import { LineTrend } from "@/components/charts/LineTrend";
import { useFinanceStore } from "@/store/finance-store";
import { formatCompact, formatToman, toFaDigits } from "@/utils/format";
import { cn } from "@/lib/utils";

const LINKS = [
  { to: "/app/loans", label: "قسط و وام", desc: "پرداختی و دریافتی", icon: Receipt },
  { to: "/app/people", label: "طلب و بدهی", desc: "حساب با اشخاص", icon: Handshake },
  { to: "/app/checks", label: "سررسید و چک", desc: "یادآور رویدادهای مالی", icon: FileSpreadsheet },
] as const;

export function AssetsScreen() {
  const assets = useFinanceStore((s) => s.assets);
  const total = assets.reduce((s, a) => s + a.currentValue, 0);
  const gold = assets.filter((a) => a.kind === "gold");
  const crypto = assets.filter((a) => a.kind === "crypto");
  const history = (assets[0]?.history ?? []).map((p, i) => ({
    date: p.date,
    value: assets.reduce((s, a) => s + (a.history[i]?.value ?? a.currentValue), 0),
  }));
  const prev = history.length > 1 ? history[history.length - 2]!.value : total;
  const change = prev ? ((total - prev) / prev) * 100 : 0;

  return (
    <div className="fade-in px-4 pb-6 pt-5">
      <h1 className="text-xl font-bold">دارایی‌ها</h1>
      <Card className="mt-4 bg-primary-dark p-5 text-white">
        <p className="text-xs text-white/70">ارزش کل پورتفو</p>
        <p className="mt-1 text-3xl font-bold tabular">{formatToman(total)}</p>
        <p className={cn("mt-2 text-sm font-semibold", change >= 0 ? "text-success" : "text-accent")}>
          {change >= 0 ? "+" : ""}
          {toFaDigits(change.toFixed(1))}٪ نسبت به ماه قبل
        </p>
      </Card>

      <Card className="mt-4">
        <h2 className="mb-1 font-bold">روند ارزش کل</h2>
        <LineTrend data={history} />
      </Card>

      <h2 className="mt-5 font-bold">طلا</h2>
      <div className="mt-2 space-y-2">
        {gold.map((a) => (
          <AssetRow key={a.id} name={a.name} meta={`${toFaDigits(a.amount)} ${a.unit}`} value={a.currentValue} pct={a.changePct} />
        ))}
      </div>
      <h2 className="mt-5 font-bold">ارز دیجیتال</h2>
      <div className="mt-2 space-y-2">
        {crypto.map((a) => (
          <AssetRow
            key={a.id}
            name={a.name}
            meta={`${toFaDigits(a.amount)} ${a.unit}`}
            value={a.currentValue}
            pct={a.changePct}
          />
        ))}
      </div>

      <div className="mt-5 space-y-2">
        {LINKS.map((l) => {
          const Icon = l.icon;
          return (
            <Link key={l.to} to={l.to} className="block">
              <Card className="flex items-center gap-3">
                <span className="flex size-11 items-center justify-center rounded-2xl bg-accent-soft text-accent">
                  <Icon className="size-5" />
                </span>
                <span className="flex-1">
                  <span className="block font-bold">{l.label}</span>
                  <span className="block text-xs text-muted">{l.desc}</span>
                </span>
                <ChevronLeft className="size-5 text-muted" />
              </Card>
            </Link>
          );
        })}
      </div>
      <p className="mt-4 flex items-center gap-2 text-[11px] text-muted">
        <Coins className="size-3.5" />
        قیمت‌ها نمونه و آفلاین هستند؛ نرخ لحظه‌ای بازار نیست.
      </p>
    </div>
  );
}

function AssetRow({
  name,
  meta,
  value,
  pct,
}: {
  name: string;
  meta: string;
  value: number;
  pct: number;
}) {
  return (
    <Card className="flex items-center justify-between gap-3">
      <div>
        <p className="font-bold">{name}</p>
        <p className="text-xs text-muted">{meta}</p>
      </div>
      <div className="text-left">
        <p className="font-bold tabular">{formatCompact(value)}</p>
        <p className={cn("text-xs font-semibold", pct >= 0 ? "text-success" : "text-danger")}>
          {pct >= 0 ? "+" : ""}
          {toFaDigits(pct.toFixed(1))}٪
        </p>
      </div>
    </Card>
  );
}
