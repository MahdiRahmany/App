import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronLeft, Plus } from "lucide-react";
import { ScreenHeader } from "@/components/ScreenHeader";
import { Card } from "@/components/Card";
import { Sheet } from "@/components/Sheet";
import { TextField } from "@/components/AmountField";
import { Button } from "@/components/ui/Button";
import { useFinanceStore } from "@/store/finance-store";
import { formatToman } from "@/utils/format";
import { cn } from "@/lib/utils";

export function PeopleScreen() {
  const people = useFinanceStore((s) => s.people);
  const addPerson = useFinanceStore((s) => s.addPerson);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const receivable = people.filter((p) => p.balance > 0).reduce((s, p) => s + p.balance, 0);
  const payable = people.filter((p) => p.balance < 0).reduce((s, p) => s + Math.abs(p.balance), 0);

  return (
    <div className="fade-in pb-6">
      <ScreenHeader
        title="طلب و بدهی"
        backTo="/app/assets"
        action={
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="flex size-11 items-center justify-center rounded-2xl bg-accent text-white"
            aria-label="شخص جدید"
          >
            <Plus className="size-5" />
          </button>
        }
      />
      <div className="px-4">
        <div className="grid grid-cols-2 gap-3">
          <Card>
            <p className="text-xs text-muted">طلب از دیگران</p>
            <p className="mt-1 font-bold tabular text-success">{formatToman(receivable, false)}</p>
          </Card>
          <Card>
            <p className="text-xs text-muted">بدهی به دیگران</p>
            <p className="mt-1 font-bold tabular text-danger">{formatToman(payable, false)}</p>
          </Card>
        </div>
        <div className="mt-4 space-y-2">
          {people.map((p) => (
            <Link key={p.id} to="/app/people/$personId" params={{ personId: p.id }} className="block">
              <Card className="flex items-center gap-3">
                <span
                  className="flex size-11 items-center justify-center rounded-2xl text-sm font-bold text-white"
                  style={{ background: p.color }}
                >
                  {p.initials}
                </span>
                <span className="flex-1">
                  <span className="block font-bold">{p.name}</span>
                  <span className="block text-xs text-muted">
                    {p.balance === 0 ? "حساب صفر" : p.balance > 0 ? "به تو بدهکار است" : "طلبکار از توست"}
                  </span>
                </span>
                <span
                  className={cn(
                    "font-bold tabular",
                    p.balance > 0 ? "text-success" : p.balance < 0 ? "text-danger" : "text-muted",
                  )}
                >
                  {formatToman(Math.abs(p.balance), false)}
                </span>
                <ChevronLeft className="size-4 text-muted" />
              </Card>
            </Link>
          ))}
        </div>
      </div>
      <Sheet open={open} onClose={() => setOpen(false)} title="شخص جدید">
        <div className="space-y-4">
          <TextField value={name} onChange={setName} label="نام و نام خانوادگی" placeholder="مثلاً رضا موسوی" />
          <Button
            className="w-full"
            disabled={!name.trim()}
            onClick={() => {
              addPerson(name.trim());
              setName("");
              setOpen(false);
            }}
          >
            افزودن
          </Button>
        </div>
      </Sheet>
    </div>
  );
}
