import { ScreenHeader } from "@/components/ScreenHeader";
import { Card } from "@/components/Card";
import { Button } from "@/components/ui/Button";
import { useFinanceStore } from "@/store/finance-store";
import { formatJalali, formatToman, relativeDue, toFaDigits } from "@/utils/format";
import { cn } from "@/lib/utils";

export function ChecksScreen() {
  const checks = useFinanceStore((s) => s.checks);
  const markDone = useFinanceStore((s) => s.markCheckDone);
  const sorted = [...checks].sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  return (
    <div className="fade-in pb-6">
      <ScreenHeader title="سررسید و چک" backTo="/app/assets" />
      <div className="space-y-3 px-4">
        {sorted.map((c) => {
          const due = relativeDue(c.dueDate);
          const done = c.status === "done";
          return (
            <Card key={c.id} className={cn(done && "opacity-55")}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-bold">{c.title}</p>
                  <p className="text-xs text-muted">{c.bank}</p>
                </div>
                <span
                  className={cn(
                    "rounded-full px-2.5 py-1 text-[11px] font-semibold",
                    c.kind === "receivable" ? "bg-success/15 text-success" : "bg-accent-soft text-accent",
                  )}
                >
                  {c.kind === "receivable" ? "دریافتی" : "پرداختی"}
                </span>
              </div>
              <p className="mt-3 text-lg font-bold tabular">{formatToman(c.amount)}</p>
              <div className="mt-2 flex items-center justify-between text-sm">
                <span className="text-muted">{formatJalali(c.dueDate)}</span>
                <span
                  className={cn(
                    "font-semibold",
                    done ? "text-muted" : due.tone === "late" ? "text-danger" : due.tone === "soon" ? "text-accent" : "text-muted",
                  )}
                >
                  {done ? "انجام شد" : due.label}
                </span>
              </div>
              {!done ? (
                <Button variant="soft" className="mt-3 h-10 w-full text-xs" onClick={() => markDone(c.id)}>
                  علامت به‌عنوان انجام‌شده
                </Button>
              ) : null}
            </Card>
          );
        })}
        <p className="text-center text-[11px] text-muted">
          شمارش معکوس بر اساس تاریخ امروز ({toFaDigits(new Date().toISOString().slice(0, 10))}) محاسبه می‌شود.
        </p>
      </div>
    </div>
  );
}
