import { useMemo, useState } from "react";
import { ScreenHeader } from "@/components/ScreenHeader";
import { Card } from "@/components/Card";
import { ProgressBar } from "@/components/ProgressBar";
import { Segmented } from "@/components/Segmented";
import { useFinanceStore } from "@/store/finance-store";
import { formatToman, relativeDue } from "@/utils/format";
import { cn } from "@/lib/utils";
import type { LoanKind } from "@/data/types";

const STATUS: Record<string, { label: string; className: string }> = {
  "on-time": { label: "سر وقت", className: "bg-success/15 text-success" },
  late: { label: "معوق", className: "bg-danger/15 text-danger" },
  paid: { label: "تسویه", className: "bg-primary-soft text-primary" },
};

export function LoansScreen() {
  const loans = useFinanceStore((s) => s.loans);
  const [kind, setKind] = useState<LoanKind>("payable");
  const list = useMemo(() => loans.filter((l) => l.kind === kind), [loans, kind]);

  return (
    <div className="fade-in pb-6">
      <ScreenHeader title="قسط و وام" backTo="/app/assets" />
      <div className="px-4">
        <Segmented
          value={kind}
          onChange={setKind}
          options={[
            { value: "payable", label: "پرداختی" },
            { value: "receivable", label: "دریافتی" },
          ]}
        />
        <div className="mt-4 space-y-3">
          {list.map((l) => {
            const paid = l.total - l.remaining;
            const pct = (paid / l.total) * 100;
            const due = relativeDue(l.dueDate);
            const st = STATUS[l.status] ?? STATUS["on-time"]!;
            return (
              <Card key={l.id}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-bold">{l.name}</p>
                    {l.bank ? <p className="text-xs text-muted">{l.bank}</p> : null}
                  </div>
                  <span className={cn("rounded-full px-2.5 py-1 text-[11px] font-semibold", st.className)}>
                    {st.label}
                  </span>
                </div>
                <p className="mt-3 text-lg font-bold tabular">{formatToman(l.remaining)}</p>
                <p className="text-xs text-muted">باقی‌مانده از {formatToman(l.total)}</p>
                <ProgressBar className="mt-3" value={pct} tone={l.status === "late" ? "danger" : "accent"} />
                <div className="mt-3 flex justify-between text-xs">
                  <span className="text-muted">قسط: {formatToman(l.installment)}</span>
                  <span className={cn("font-semibold", due.tone === "late" ? "text-danger" : due.tone === "soon" ? "text-accent" : "text-muted")}>
                    {due.label}
                  </span>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
