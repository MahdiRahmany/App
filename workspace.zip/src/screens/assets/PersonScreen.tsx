import { useState } from "react";
import { useParams } from "@tanstack/react-router";
import { ScreenHeader } from "@/components/ScreenHeader";
import { Card } from "@/components/Card";
import { Sheet } from "@/components/Sheet";
import { AmountField, TextField } from "@/components/AmountField";
import { Button } from "@/components/ui/Button";
import { useFinanceStore } from "@/store/finance-store";
import { formatJalali, formatToman } from "@/utils/format";
import { cn } from "@/lib/utils";

export function PersonScreen() {
  const { personId } = useParams({ strict: false });
  const person = useFinanceStore((s) => s.people.find((p) => p.id === personId));
  const settle = useFinanceStore((s) => s.settlePerson);
  const [mode, setMode] = useState<"in" | "out" | null>(null);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");

  if (!person) {
    return (
      <div>
        <ScreenHeader title="شخص پیدا نشد" backTo="/app/people" />
      </div>
    );
  }

  function apply() {
    const n = Number(amount);
    if (!n || !person) return;
    const signed = mode === "in" ? -n : n;
    settle(person.id, signed, note.trim() || (mode === "in" ? "دریافت" : "پرداخت"));
    setAmount("");
    setNote("");
    setMode(null);
  }

  return (
    <div className="fade-in pb-6">
      <ScreenHeader title={person.name} backTo="/app/people" />
      <div className="px-4">
        <Card className="flex flex-col items-center py-6">
          <span
            className="flex size-16 items-center justify-center rounded-3xl text-lg font-bold text-white"
            style={{ background: person.color }}
          >
            {person.initials}
          </span>
          <p className="mt-3 text-sm text-muted">مانده حساب</p>
          <p
            className={cn(
              "text-2xl font-bold tabular",
              person.balance > 0 ? "text-success" : person.balance < 0 ? "text-danger" : "text-ink",
            )}
          >
            {formatToman(Math.abs(person.balance))}
          </p>
          <p className="mt-1 text-xs text-muted">
            {person.balance > 0 ? "این شخص به تو بدهکار است" : person.balance < 0 ? "تو به این شخص بدهکاری" : "حساب صاف است"}
          </p>
          <div className="mt-5 grid w-full grid-cols-2 gap-3">
            <Button onClick={() => setMode("in")}>دریافت</Button>
            <Button variant="secondary" onClick={() => setMode("out")}>
              پرداخت
            </Button>
          </div>
        </Card>

        <h2 className="mt-5 font-bold">تاریخچه</h2>
        <Card className="mt-2 space-y-3">
          {person.history.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted">هنوز حرکتی نیست</p>
          ) : (
            person.history.map((h) => (
              <div key={h.id} className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold">{h.note}</p>
                  <p className="text-xs text-muted">{formatJalali(h.date)}</p>
                </div>
                <p className={cn("text-sm font-bold tabular", h.amount > 0 ? "text-success" : "text-danger")}>
                  {h.amount > 0 ? "+" : "−"}
                  {formatToman(Math.abs(h.amount), false)}
                </p>
              </div>
            ))
          )}
        </Card>
      </div>

      <Sheet
        open={mode !== null}
        onClose={() => setMode(null)}
        title={mode === "in" ? "ثبت دریافت" : "ثبت پرداخت"}
      >
        <div className="space-y-4">
          <AmountField value={amount} onChange={setAmount} />
          <TextField value={note} onChange={setNote} label="توضیح" placeholder="اختیاری" />
          <Button className="w-full" disabled={!amount} onClick={apply}>
            ثبت
          </Button>
        </div>
      </Sheet>
    </div>
  );
}
