import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import {
  Bell,
  Check,
  Fingerprint,
  LockKeyhole,
  MessageSquareText,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Switch } from "@/components/ui/Switch";
import { Logo } from "@/components/Logo";
import { PinDots, PinPad } from "@/components/PinPad";
import { PhoneFrame } from "@/navigation/PhoneFrame";
import { useFinanceStore } from "@/store/finance-store";
import { toFaDigits } from "@/utils/format";
import { cn } from "@/lib/utils";

const BENEFITS = [
  "دسته‌بندی خودکار تراکنش‌ها",
  "گزارش‌های ماهانه و بودجه هوشمند",
  "یادآور سررسید چک و قسط",
  "پشتیبان‌گیری آفلاین روی خود گوشی",
];

export function OnboardingFlow() {
  const navigate = useNavigate();
  const complete = useFinanceStore((s) => s.completeOnboarding);
  const [step, setStep] = useState(0);
  const [sms, setSms] = useState(false);
  const [pin, setPin] = useState("");
  const [confirm, setConfirm] = useState("");
  const [phase, setPhase] = useState<"set" | "confirm">("set");
  const [biometric, setBiometric] = useState(true);
  const [daily, setDaily] = useState(true);
  const [weekly, setWeekly] = useState(false);
  const [hour, setHour] = useState("21:00");
  const [pinError, setPinError] = useState("");

  function finish() {
    const [h, m] = hour.split(":").map(Number);
    complete({
      pin: pin.length === 4 ? pin : null,
      biometric,
      reminders: { daily, weekly, hour: h ?? 21, minute: m ?? 0 },
      smsGranted: sms,
    });
    navigate({ to: "/app" });
  }

  function onDigit(d: string) {
    setPinError("");
    if (phase === "set") {
      const next = (pin + d).slice(0, 4);
      setPin(next);
      if (next.length === 4) setPhase("confirm");
    } else {
      const next = (confirm + d).slice(0, 4);
      setConfirm(next);
      if (next.length === 4) {
        if (next !== pin) {
          setPinError("رمزها یکی نیستند. دوباره وارد کن.");
          setPin("");
          setConfirm("");
          setPhase("set");
        }
      }
    }
  }

  return (
    <PhoneFrame>
      <div className="flex min-h-svh flex-col px-6 pb-8 pt-10">
        <div className="mb-6 flex items-center justify-between">
          <Logo />
          <div className="flex gap-1.5">
            {[0, 1, 2, 3].map((i) => (
              <span
                key={i}
                className={cn("h-1.5 w-6 rounded-full", i <= step ? "bg-accent" : "bg-line")}
              />
            ))}
          </div>
        </div>

        {step === 0 && (
          <div className="flex flex-1 flex-col fade-in">
            <div className="mx-auto mt-4 flex size-24 items-center justify-center rounded-3xl bg-accent-soft text-accent">
              <MessageSquareText className="size-12" strokeWidth={1.6} />
            </div>
            <h1 className="mt-8 text-2xl font-bold leading-snug">خواندن پیامک‌های بانکی</h1>
            <p className="mt-3 text-sm leading-7 text-muted">
              حسابینو می‌تواند پیامک واریز و برداشت بانک را بخواند و تراکنش را خودکار ثبت کند. این دسترسی فقط روی خود
              گوشی می‌ماند و جایی ارسال نمی‌شود.
            </p>
            <ul className="mt-6 space-y-3 text-sm">
              {[
                "تشخیص مبلغ، کارت و فروشگاه از متن پیامک",
                "بدون نیاز به اتصال اینترنت",
                "هر زمان از تنظیمات قابل قطع است",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2">
                  <Check className="mt-0.5 size-4 shrink-0 text-accent" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
            <div className="mt-auto space-y-3 pt-8">
              <Button
                className="w-full"
                onClick={() => {
                  setSms(true);
                  setStep(1);
                }}
              >
                اجازه دسترسی به پیامک
              </Button>
              <Button variant="ghost" className="w-full" onClick={() => setStep(1)}>
                بعداً، ثبت دستی می‌کنم
              </Button>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="flex flex-1 flex-col fade-in">
            <div className="mx-auto mt-2 flex size-20 items-center justify-center rounded-3xl bg-primary-soft text-primary">
              <LockKeyhole className="size-10" strokeWidth={1.6} />
            </div>
            <h1 className="mt-6 text-2xl font-bold">قفل فقط برای خودت</h1>
            <p className="mt-2 text-sm text-muted">
              {phase === "set" ? "یک رمز ۴ رقمی انتخاب کن" : "همان رمز را دوباره وارد کن"}
            </p>
            <div className="mt-6">
              <PinDots length={4} filled={phase === "set" ? pin.length : confirm.length} />
            </div>
            {pinError ? <p className="mt-3 text-center text-sm text-danger">{pinError}</p> : <div className="mt-3 h-5" />}
            <PinPad
              onDigit={onDigit}
              onBackspace={() => {
                if (phase === "set") setPin((p) => p.slice(0, -1));
                else setConfirm((p) => p.slice(0, -1));
              }}
            />
            <div className="mt-6 rounded-2xl bg-card p-4 card-shadow">
              <div className="flex items-center gap-3">
                <Fingerprint className="size-6 text-accent" />
                <div className="flex-1">
                  <Switch
                    label="ورود با اثر انگشت"
                    description="در مرورگر به‌صورت شبیه‌سازی‌شده فعال می‌شود"
                    checked={biometric}
                    onCheckedChange={setBiometric}
                  />
                </div>
              </div>
            </div>
            <div className="mt-auto space-y-3 pt-6">
              <Button className="w-full" disabled={pin.length !== 4 || confirm !== pin} onClick={() => setStep(2)}>
                ادامه
              </Button>
              <Button
                variant="ghost"
                className="w-full"
                onClick={() => {
                  setPin("");
                  setConfirm("");
                  setBiometric(false);
                  setStep(2);
                }}
              >
                فعلاً بدون رمز
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-1 flex-col fade-in">
            <div className="mx-auto mt-4 flex size-20 items-center justify-center rounded-3xl bg-accent-soft text-accent">
              <Bell className="size-10" strokeWidth={1.6} />
            </div>
            <h1 className="mt-6 text-2xl font-bold">یادآور</h1>
            <p className="mt-2 text-sm leading-7 text-muted">
              یک زنگ کوچک تا دخل‌وخرج از یادت نرود. یادآورها روی همین دستگاه ذخیره می‌شوند.
            </p>
            <div className="mt-6 space-y-4 rounded-2xl bg-card p-4 card-shadow">
              <Switch label="یادآور روزانه" description="ثبت هزینه‌های همان روز" checked={daily} onCheckedChange={setDaily} />
              <Switch
                label="خلاصه هفتگی"
                description="جمع‌بندی جمعه‌ها"
                checked={weekly}
                onCheckedChange={setWeekly}
              />
              <label className="block pt-1">
                <span className="mb-1.5 block text-sm font-medium text-muted">ساعت یادآوری</span>
                <select
                  value={hour}
                  onChange={(e) => setHour(e.target.value)}
                  className="h-12 w-full rounded-2xl bg-background px-4 text-sm outline-none ring-1 ring-line"
                >
                  {Array.from({ length: 24 }, (_, i) => {
                    const h = String(i).padStart(2, "0");
                    return (
                      <option key={h} value={`${h}:00`}>
                        {toFaDigits(h)}:۰۰
                      </option>
                    );
                  })}
                </select>
              </label>
            </div>
            <div className="mt-auto pt-8">
              <Button className="w-full" onClick={() => setStep(3)}>
                ذخیره و ادامه
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="flex flex-1 flex-col fade-in">
            <div className="mx-auto mt-4 flex size-20 items-center justify-center rounded-3xl bg-primary text-accent">
              <ShieldCheck className="size-10" strokeWidth={1.6} />
            </div>
            <p className="mt-6 text-sm font-semibold text-accent">{toFaDigits(31)} روز اشتراک رایگان</p>
            <h1 className="mt-1 text-2xl font-bold leading-snug">همه امکانات، بدون هزینه برای یک ماه</h1>
            <ul className="mt-6 space-y-3">
              {BENEFITS.map((b) => (
                <li key={b} className="flex items-center gap-3 rounded-2xl bg-card p-3 card-shadow">
                  <span className="flex size-8 items-center justify-center rounded-xl bg-accent-soft text-accent">
                    <Check className="size-4" />
                  </span>
                  <span className="text-sm font-medium">{b}</span>
                </li>
              ))}
            </ul>
            <div className="mt-auto space-y-3 pt-8">
              <Button className="w-full" onClick={finish}>
                شروع دوره آزمایشی
              </Button>
              <p className="text-center text-xs leading-6 text-muted">
                بعد از {toFaDigits(31)} روز می‌توانی ادامه دهی یا با نسخه پایه کار کنی. پرداختی از تو گرفته نمی‌شود.
              </p>
            </div>
          </div>
        )}
      </div>
    </PhoneFrame>
  );
}
