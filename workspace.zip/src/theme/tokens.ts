/** Design tokens — source of truth is `src/styles.css` `@theme`. */
export const tokens = {
  primaryDark: "#1B1447",
  primary: "#2A1F6E",
  accent: "#FF6B47",
  background: "#F5F5F8",
  card: "#FFFFFF",
  danger: "#E53935",
  success: "#2E7D32",
  radiusCard: 16,
  font: "Vazirmatn Variable",
} as const;
