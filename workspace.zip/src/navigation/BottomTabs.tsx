import { Link, useRouterState } from "@tanstack/react-router";
import { Home, PieChart, Settings, Wallet, Landmark } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/app", label: "خانه", icon: Home, match: (p: string) => p === "/app" || p.startsWith("/app/search") },
  { to: "/app/reports", label: "گزارش‌ها", icon: PieChart, match: (p: string) => p.startsWith("/app/reports") },
  { to: "/app/budget", label: "بودجه", icon: Wallet, match: (p: string) => p.startsWith("/app/budget") },
  {
    to: "/app/assets",
    label: "دارایی‌ها",
    icon: Landmark,
    match: (p: string) =>
      p.startsWith("/app/assets") ||
      p.startsWith("/app/loans") ||
      p.startsWith("/app/people") ||
      p.startsWith("/app/checks"),
  },
  { to: "/app/settings", label: "تنظیمات", icon: Settings, match: (p: string) => p.startsWith("/app/settings") },
] as const;

export function BottomTabs() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="absolute inset-x-0 bottom-0 z-20 border-t border-line bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md">
      <ul className="grid grid-cols-5 px-1 pt-1">
        {TABS.map((tab) => {
          const active = tab.match(pathname);
          const Icon = tab.icon;
          return (
            <li key={tab.to}>
              <Link
                to={tab.to}
                className={cn(
                  "flex flex-col items-center gap-0.5 py-2 text-[10px] font-semibold",
                  active ? "text-accent" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.4 : 1.8} />
                {tab.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
