import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PhoneFrame({
  children,
  dark,
  className,
}: {
  children: ReactNode;
  dark?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("phone-shell relative mx-auto min-h-svh w-full max-w-[430px] overflow-hidden", dark && "dark", className)}>
      <div className="min-h-svh bg-background text-ink">{children}</div>
    </div>
  );
}
