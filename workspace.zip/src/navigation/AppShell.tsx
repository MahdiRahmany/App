import { Outlet, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { BottomTabs } from "./BottomTabs";
import { useFinanceStore } from "@/store/finance-store";
import { cn } from "@/lib/utils";

export function AppShell() {
  const navigate = useNavigate();
  const hydrated = useFinanceStore((s) => s.hydrated);
  const onboarded = useFinanceStore((s) => s.onboarded);
  const pin = useFinanceStore((s) => s.pin);
  const unlocked = useFinanceStore((s) => s.unlocked);
  const darkMode = useFinanceStore((s) => s.darkMode);

  useEffect(() => {
    if (!hydrated) return;
    if (!onboarded) navigate({ to: "/onboarding" });
    else if (pin && !unlocked) navigate({ to: "/lock" });
  }, [hydrated, onboarded, pin, unlocked, navigate]);

  return (
    <div className={cn("phone-shell relative mx-auto flex min-h-svh w-full max-w-[430px] flex-col", darkMode && "dark")}>
      <div className="flex min-h-svh flex-col bg-background text-ink">
        <main className="relative flex-1 overflow-y-auto pb-24">
          <Outlet />
        </main>
        <BottomTabs />
      </div>
    </div>
  );
}
