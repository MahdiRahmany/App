import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { createSeed } from "@/data/mock";
import type {
  Budget,
  Category,
  FinanceSnapshot,
  Person,
  Reminders,
  Transaction,
  TxType,
} from "@/data/types";
import { jalaliMonthKey } from "@/utils/jalali";

function uid(prefix = "id"): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

type FinanceState = FinanceSnapshot & {
  hydrated: boolean;
  unlocked: boolean;
  markHydrated: () => void;
  completeOnboarding: (payload: {
    pin: string | null;
    biometric: boolean;
    reminders: Reminders;
    smsGranted: boolean;
  }) => void;
  unlockWithPin: (pin: string) => boolean;
  unlockBiometric: () => boolean;
  lock: () => void;
  setDarkMode: (value: boolean) => void;
  addTransaction: (tx: Omit<Transaction, "id">) => void;
  removeTransaction: (id: string) => void;
  addBudget: (categoryId: string, amount: number) => void;
  updateBudget: (id: string, amount: number) => void;
  removeBudget: (id: string) => void;
  addCategory: (cat: Omit<Category, "id">) => void;
  updateCategory: (id: string, patch: Partial<Category>) => void;
  removeCategory: (id: string) => void;
  settlePerson: (personId: string, amount: number, note: string) => void;
  addPerson: (name: string) => void;
  markCheckDone: (id: string) => void;
  importSnapshot: (data: FinanceSnapshot) => void;
  exportSnapshot: () => FinanceSnapshot;
  resetDemo: () => void;
};

const seed = createSeed();

export const useFinanceStore = create<FinanceState>()(
  persist(
    (set, get) => ({
      ...seed,
      hydrated: false,
      unlocked: false,
      markHydrated: () => set({ hydrated: true }),
      completeOnboarding: ({ pin, biometric, reminders, smsGranted }) =>
        set({
          onboarded: true,
          pin,
          biometric,
          reminders,
          smsGranted,
          trialStartedAt: new Date().toISOString(),
          unlocked: true,
        }),
      unlockWithPin: (pin) => {
        if (get().pin && pin === get().pin) {
          set({ unlocked: true });
          return true;
        }
        return false;
      },
      unlockBiometric: () => {
        if (!get().biometric) return false;
        set({ unlocked: true });
        return true;
      },
      lock: () => set({ unlocked: false }),
      setDarkMode: (darkMode) => set({ darkMode }),
      addTransaction: (tx) =>
        set({
          transactions: [{ ...tx, id: uid("t") }, ...get().transactions],
        }),
      removeTransaction: (id) =>
        set({ transactions: get().transactions.filter((t) => t.id !== id) }),
      addBudget: (categoryId, amount) =>
        set({
          budgets: [
            ...get().budgets.filter((b) => b.categoryId !== categoryId),
            { id: uid("b"), categoryId, amount },
          ],
        }),
      updateBudget: (id, amount) =>
        set({
          budgets: get().budgets.map((b) => (b.id === id ? { ...b, amount } : b)),
        }),
      removeBudget: (id) => set({ budgets: get().budgets.filter((b) => b.id !== id) }),
      addCategory: (cat) =>
        set({ categories: [...get().categories, { ...cat, id: uid("cat") }] }),
      updateCategory: (id, patch) =>
        set({
          categories: get().categories.map((c) => (c.id === id ? { ...c, ...patch } : c)),
        }),
      removeCategory: (id) =>
        set({
          categories: get().categories.filter((c) => c.id !== id && c.parentId !== id),
          budgets: get().budgets.filter((b) => b.categoryId !== id),
        }),
      settlePerson: (personId, amount, note) =>
        set({
          people: get().people.map((p) => {
            if (p.id !== personId) return p;
            return {
              ...p,
              balance: p.balance + amount,
              history: [
                { id: uid("ph"), amount, date: new Date().toISOString().slice(0, 10), note },
                ...p.history,
              ],
            };
          }),
        }),
      addPerson: (name) => {
        const parts = name.trim().split(/\s+/);
        const initials = parts.map((p) => p[0] ?? "").join("").slice(0, 2);
        set({
          people: [
            ...get().people,
            {
              id: uid("p"),
              name,
              initials: initials || "؟",
              color: "#5c548c",
              balance: 0,
              history: [],
            },
          ],
        });
      },
      markCheckDone: (id) =>
        set({
          checks: get().checks.map((c) => (c.id === id ? { ...c, status: "done" } : c)),
        }),
      importSnapshot: (data) =>
        set({
          ...data,
          hydrated: true,
          unlocked: true,
        }),
      exportSnapshot: () => {
        const s = get();
        return {
          onboarded: s.onboarded,
          pin: s.pin,
          biometric: s.biometric,
          reminders: s.reminders,
          trialStartedAt: s.trialStartedAt,
          smsGranted: s.smsGranted,
          darkMode: s.darkMode,
          userName: s.userName,
          categories: s.categories,
          transactions: s.transactions,
          budgets: s.budgets,
          assets: s.assets,
          loans: s.loans,
          people: s.people,
          checks: s.checks,
        };
      },
      resetDemo: () =>
        set({
          ...createSeed(),
          onboarded: true,
          pin: get().pin,
          biometric: get().biometric,
          reminders: get().reminders,
          trialStartedAt: get().trialStartedAt,
          smsGranted: get().smsGranted,
          hydrated: true,
          unlocked: true,
        }),
    }),
    {
      name: "hesabino-v1",
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      partialize: (state) => ({
        onboarded: state.onboarded,
        pin: state.pin,
        biometric: state.biometric,
        reminders: state.reminders,
        trialStartedAt: state.trialStartedAt,
        smsGranted: state.smsGranted,
        darkMode: state.darkMode,
        userName: state.userName,
        categories: state.categories,
        transactions: state.transactions,
        budgets: state.budgets,
        assets: state.assets,
        loans: state.loans,
        people: state.people,
        checks: state.checks,
      }),
      skipHydration: true,
      onRehydrateStorage: () => (state) => {
        state?.markHydrated();
      },
    },
  ),
);

export function categoryById(id: string, list: Category[]) {
  return list.find((c) => c.id === id);
}

export function parentCategoryId(id: string, list: Category[]): string {
  const cat = list.find((c) => c.id === id);
  return cat?.parentId ?? id;
}

export function spentInMonth(
  transactions: Transaction[],
  categories: Category[],
  monthKey: string,
  categoryId: string,
): number {
  return transactions
    .filter((t) => t.type === "expense" && jalaliMonthKey(t.date) === monthKey)
    .filter((t) => parentCategoryId(t.categoryId, categories) === categoryId || t.categoryId === categoryId)
    .reduce((s, t) => s + t.amount, 0);
}

export function monthTotals(transactions: Transaction[], monthKey: string) {
  const list = transactions.filter((t) => jalaliMonthKey(t.date) === monthKey);
  const income = list.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const expense = list.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  return { list, income, expense, net: income - expense };
}

export function expenseByCategory(
  transactions: Transaction[],
  categories: Category[],
  monthKey: string | "all",
  type: TxType = "expense",
) {
  const list = transactions.filter((t) => {
    if (t.type !== type) return false;
    if (monthKey !== "all" && jalaliMonthKey(t.date) !== monthKey) return false;
    return true;
  });
  const map = new Map<string, number>();
  for (const t of list) {
    const id = parentCategoryId(t.categoryId, categories);
    map.set(id, (map.get(id) ?? 0) + t.amount);
  }
  return [...map.entries()]
    .map(([id, amount]) => ({
      category: categories.find((c) => c.id === id),
      amount,
    }))
    .filter((x) => x.category)
    .sort((a, b) => b.amount - a.amount);
}
