import { useEffect } from "react";
import { useFinanceStore } from "./finance-store";

export function StoreHydrator() {
  useEffect(() => {
    const unsub = useFinanceStore.persist.onFinishHydration(() => {
      useFinanceStore.getState().markHydrated();
    });
    void useFinanceStore.persist.rehydrate();
    const t = window.setTimeout(() => {
      if (!useFinanceStore.getState().hydrated) {
        useFinanceStore.getState().markHydrated();
      }
    }, 600);
    return () => {
      unsub();
      window.clearTimeout(t);
    };
  }, []);
  return null;
}
