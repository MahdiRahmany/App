export type TxType = "expense" | "income";
export type TxSource = "sms" | "manual";
export type LoanKind = "payable" | "receivable";
export type LoanStatus = "on-time" | "late" | "paid";
export type CheckStatus = "upcoming" | "due" | "overdue" | "done";
export type AssetKind = "gold" | "crypto";

export type Category = {
  id: string;
  name: string;
  icon: string;
  color: string;
  type: TxType;
  parentId?: string;
};

export type Transaction = {
  id: string;
  amount: number;
  type: TxType;
  categoryId: string;
  title: string;
  merchant: string;
  date: string;
  source: TxSource;
  note?: string;
};

export type Budget = {
  id: string;
  categoryId: string;
  amount: number;
};

export type AssetPoint = { date: string; value: number };

export type Asset = {
  id: string;
  kind: AssetKind;
  name: string;
  amount: number;
  unit: string;
  currentValue: number;
  changePct: number;
  history: AssetPoint[];
};

export type Loan = {
  id: string;
  name: string;
  kind: LoanKind;
  total: number;
  remaining: number;
  installment: number;
  dueDate: string;
  status: LoanStatus;
  bank?: string;
};

export type PersonTx = {
  id: string;
  amount: number;
  date: string;
  note: string;
};

export type Person = {
  id: string;
  name: string;
  initials: string;
  color: string;
  /** Positive = they owe you (طلب), negative = you owe them (بدهی) */
  balance: number;
  history: PersonTx[];
};

export type CheckItem = {
  id: string;
  title: string;
  amount: number;
  dueDate: string;
  kind: LoanKind;
  bank: string;
  status: CheckStatus;
};

export type Reminders = {
  daily: boolean;
  weekly: boolean;
  hour: number;
  minute: number;
};

export type FinanceSnapshot = {
  onboarded: boolean;
  pin: string | null;
  biometric: boolean;
  reminders: Reminders;
  trialStartedAt: string | null;
  smsGranted: boolean;
  darkMode: boolean;
  userName: string;
  categories: Category[];
  transactions: Transaction[];
  budgets: Budget[];
  assets: Asset[];
  loans: Loan[];
  people: Person[];
  checks: CheckItem[];
};
