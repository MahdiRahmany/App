import type {
  Asset,
  Budget,
  Category,
  CheckItem,
  FinanceSnapshot,
  Loan,
  Person,
  Transaction,
} from "./types";

export const CATEGORIES: Category[] = [
  { id: "food", name: "خوراک", icon: "utensils", color: "var(--color-cat-food)", type: "expense" },
  { id: "food-out", name: "رستوران و کافه", icon: "coffee", color: "var(--color-cat-food)", type: "expense", parentId: "food" },
  { id: "transport", name: "حمل‌ونقل", icon: "car", color: "var(--color-cat-transport)", type: "expense" },
  { id: "bills", name: "قبض", icon: "zap", color: "var(--color-cat-bills)", type: "expense" },
  { id: "fun", name: "تفریح", icon: "clapper", color: "var(--color-cat-fun)", type: "expense" },
  { id: "health", name: "سلامت", icon: "heart", color: "var(--color-cat-health)", type: "expense" },
  { id: "shop", name: "خرید", icon: "bag", color: "var(--color-cat-shop)", type: "expense" },
  { id: "home", name: "مسکن", icon: "home", color: "var(--color-cat-home)", type: "expense" },
  { id: "edu", name: "آموزش", icon: "edu", color: "var(--color-cat-edu)", type: "expense" },
  { id: "other", name: "سایر", icon: "dots", color: "var(--color-cat-other)", type: "expense" },
  { id: "salary", name: "حقوق", icon: "banknote", color: "var(--color-success)", type: "income" },
  { id: "invest", name: "سود و سرمایه‌گذاری", icon: "trend", color: "var(--color-success)", type: "income" },
  { id: "transfer-in", name: "دریافتی", icon: "in", color: "var(--color-success)", type: "income" },
];

function tx(
  id: string,
  amount: number,
  type: Transaction["type"],
  categoryId: string,
  title: string,
  merchant: string,
  date: string,
  source: Transaction["source"] = "sms",
  note?: string,
): Transaction {
  return { id, amount, type, categoryId, title, merchant, date, source, note };
}

export const TRANSACTIONS: Transaction[] = [
  // مهر ۱۴۰۵ (از ۲۳ سپتامبر)
  tx("t1", 48_500_000, "income", "salary", "حقوق مهر", "شرکت آریا نرم‌افزار", "2026-09-23", "manual"),
  tx("t2", 287_000, "expense", "food-out", "ناهار کاری", "اسنپ‌فود", "2026-09-23"),
  tx("t3", 96_000, "expense", "transport", "سفر تا محل کار", "تپسی", "2026-09-23"),
  tx("t4", 1_850_000, "expense", "food", "خرید هفته", "هایپراستار سعادت‌آباد", "2026-09-24"),
  tx("t5", 120_000, "expense", "bills", "بسته اینترنت", "ایرانسل", "2026-09-24"),
  tx("t6", 195_000, "expense", "food-out", "قهوه بعدازظهر", "کافه لمیز", "2026-09-24", "manual"),
  tx("t7", 450_000, "expense", "transport", "بنزین", "پمپ بنزین تهرانپارس", "2026-09-25"),
  tx("t8", 340_000, "expense", "health", "دارو و ویتامین", "داروخانه ۱۳ آبان", "2026-09-25"),
  tx("t9", 85_000, "expense", "food", "نان تازه", "نانوایی سنگکی محله", "2026-09-25", "manual"),

  // شهریور ۱۴۰۵
  tx("t10", 18_000_000, "expense", "home", "اجاره شهریور", "مالک آپارتمان", "2026-08-23", "manual"),
  tx("t11", 47_200_000, "income", "salary", "حقوق شهریور", "شرکت آریا نرم‌افزار", "2026-08-23", "manual"),
  tx("t12", 2_350_000, "expense", "shop", "هدفون و لوازم", "دیجی‌کالا", "2026-08-25"),
  tx("t13", 1_200_000, "expense", "food-out", "شام خانوادگی", "رستوران شاندیز", "2026-08-26", "manual"),
  tx("t14", 640_000, "expense", "bills", "قبض برق", "توانیر", "2026-08-27"),
  tx("t15", 210_000, "expense", "bills", "قبض گاز", "شرکت گاز", "2026-08-27"),
  tx("t16", 2_200_000, "expense", "edu", "شهریه کلاس زبان", "آموزشگاه ایرانمهر", "2026-08-28", "manual"),
  tx("t17", 240_000, "expense", "fun", "بلیط سینما", "سینما ایران‌مال", "2026-08-29"),
  tx("t18", 78_000, "expense", "transport", "ارسال بسته", "اسنپ‌باکس", "2026-08-30"),
  tx("t19", 410_000, "expense", "shop", "شوینده و بهداشتی", "فروشگاه گلرنگ", "2026-09-01"),
  tx("t20", 312_000, "expense", "food-out", "ناهار", "اسنپ‌فود", "2026-09-02"),
  tx("t21", 54_000, "expense", "transport", "شارژ مترو", "کارت بلیت مترو", "2026-09-03", "manual"),
  tx("t22", 1_640_000, "expense", "food", "خرید میوه و تره‌بار", "بازار تجریش", "2026-09-05", "manual"),
  tx("t23", 89_000, "expense", "transport", "اسنپ تا میدان ولیعصر", "اسنپ", "2026-09-06"),
  tx("t24", 320_000, "income", "invest", "سود سپرده کوتاه‌مدت", "بانک ملت", "2026-09-07"),
  tx("t25", 175_000, "expense", "fun", "اشتراک فیلیمو", "فیلیمو", "2026-09-08"),
  tx("t26", 980_000, "expense", "health", "ویزیت دندانپزشکی", "کلینیک دندان مهر", "2026-09-10", "manual"),
  tx("t27", 265_000, "expense", "food-out", "کافه با دوستان", "کافه نادری", "2026-09-12"),
  tx("t28", 3_800_000, "expense", "shop", "کفش و لباس پاییزه", "فروشگاه جین وست", "2026-09-14"),
  tx("t29", 155_000, "expense", "bills", "قبض آب", "آبفا تهران", "2026-09-16"),
  tx("t30", 500_000, "income", "transfer-in", "برگشت هزینه سفر", "علی رضایی", "2026-09-18", "manual"),
  tx("t31", 118_000, "expense", "transport", "تپسی شب", "تپسی", "2026-09-19"),
  tx("t32", 720_000, "expense", "food", "سوپرمارکت", "افق کوروش", "2026-09-20"),
  tx("t33", 95_000, "expense", "other", "کارمزد کارت به کارت", "بانک پاسارگاد", "2026-09-21"),

  // مرداد ۱۴۰۵
  tx("t34", 18_000_000, "expense", "home", "اجاره مرداد", "مالک آپارتمان", "2026-07-23", "manual"),
  tx("t35", 46_800_000, "income", "salary", "حقوق مرداد", "شرکت آریا نرم‌افزار", "2026-07-23", "manual"),
  tx("t36", 1_420_000, "expense", "food", "خرید ماهانه", "هایپراستار", "2026-07-26"),
  tx("t37", 2_900_000, "expense", "fun", "سفر یک‌روزه شمال", "رستوران رامسر", "2026-08-01", "manual"),
  tx("t38", 430_000, "expense", "transport", "بنزین جاده", "جایگاه قم", "2026-08-01"),
  tx("t39", 560_000, "expense", "bills", "قبض برق مرداد", "توانیر", "2026-08-08"),
  tx("t40", 198_000, "expense", "food-out", "اسنپ‌فود", "اسنپ‌فود", "2026-08-12"),
  tx("t41", 1_100_000, "expense", "shop", "کتاب و لوازم تحریر", "شهر کتاب", "2026-08-15", "manual"),
  tx("t42", 250_000, "income", "invest", "سود صندوق درآمد ثابت", "کارگزاری مفید", "2026-08-18"),
];

export const BUDGETS: Budget[] = [
  { id: "b1", categoryId: "food", amount: 8_000_000 },
  { id: "b2", categoryId: "transport", amount: 2_500_000 },
  { id: "b3", categoryId: "bills", amount: 2_000_000 },
  { id: "b4", categoryId: "fun", amount: 1_500_000 },
  { id: "b5", categoryId: "shop", amount: 4_000_000 },
  { id: "b6", categoryId: "health", amount: 1_200_000 },
  { id: "b7", categoryId: "home", amount: 18_000_000 },
  { id: "b8", categoryId: "edu", amount: 2_500_000 },
];

function hist(values: number[]): { date: string; value: number }[] {
  const months = [
    "2026-02-01",
    "2026-03-01",
    "2026-04-01",
    "2026-05-01",
    "2026-06-01",
    "2026-07-01",
    "2026-08-01",
    "2026-09-01",
  ];
  return months.map((date, i) => ({ date, value: values[i] ?? values[values.length - 1]! }));
}

export const ASSETS: Asset[] = [
  {
    id: "a1",
    kind: "gold",
    name: "طلای ۱۸ عیار",
    amount: 25,
    unit: "گرم",
    currentValue: 128_500_000,
    changePct: 4.2,
    history: hist([98, 102, 108, 112, 115, 118, 123, 128.5].map((n) => n * 1_000_000)),
  },
  {
    id: "a2",
    kind: "gold",
    name: "سکه تمام بهار آزادی",
    amount: 2,
    unit: "عدد",
    currentValue: 152_000_000,
    changePct: 2.8,
    history: hist([132, 136, 140, 143, 145, 147, 149, 152].map((n) => n * 1_000_000)),
  },
  {
    id: "a3",
    kind: "crypto",
    name: "بیت‌کوین",
    amount: 0.012,
    unit: "BTC",
    currentValue: 86_400_000,
    changePct: -3.1,
    history: hist([74, 81, 92, 88, 95, 91, 89, 86.4].map((n) => n * 1_000_000)),
  },
  {
    id: "a4",
    kind: "crypto",
    name: "تتر",
    amount: 520,
    unit: "USDT",
    currentValue: 49_400_000,
    changePct: 0.6,
    history: hist([44, 45.2, 46, 46.8, 47.5, 48.1, 48.9, 49.4].map((n) => n * 1_000_000)),
  },
];

export const LOANS: Loan[] = [
  {
    id: "l1",
    name: "وام مسکن",
    kind: "payable",
    total: 850_000_000,
    remaining: 412_000_000,
    installment: 8_400_000,
    dueDate: "2026-09-27",
    status: "on-time",
    bank: "بانک مسکن",
  },
  {
    id: "l2",
    name: "قسط گوشی",
    kind: "payable",
    total: 24_000_000,
    remaining: 8_000_000,
    installment: 2_000_000,
    dueDate: "2026-10-03",
    status: "on-time",
    bank: "دیجی‌پی",
  },
  {
    id: "l3",
    name: "قسط خودرو",
    kind: "payable",
    total: 180_000_000,
    remaining: 54_000_000,
    installment: 6_000_000,
    dueDate: "2026-09-20",
    status: "late",
    bank: "بانک سامان",
  },
  {
    id: "l4",
    name: "وام به برادر",
    kind: "receivable",
    total: 30_000_000,
    remaining: 12_000_000,
    installment: 3_000_000,
    dueDate: "2026-10-01",
    status: "on-time",
  },
];

export const PEOPLE: Person[] = [
  {
    id: "p1",
    name: "علی رضایی",
    initials: "ع‌ر",
    color: "#4A6FA5",
    balance: 2_500_000,
    history: [
      { id: "ph1", amount: 3_000_000, date: "2026-08-02", note: "قرض سفر شمال" },
      { id: "ph2", amount: -500_000, date: "2026-09-18", note: "بازپرداخت جزئی" },
    ],
  },
  {
    id: "p2",
    name: "مریم حسینی",
    initials: "م‌ح",
    color: "#C45C4A",
    balance: -800_000,
    history: [{ id: "ph3", amount: -800_000, date: "2026-09-10", note: "سهم شام تولد" }],
  },
  {
    id: "p3",
    name: "حسین کریمی",
    initials: "ح‌ک",
    color: "#2A9D8F",
    balance: 5_200_000,
    history: [
      { id: "ph4", amount: 5_200_000, date: "2026-07-15", note: "هزینه پروژه مشترک" },
    ],
  },
  {
    id: "p4",
    name: "نرگس احمدی",
    initials: "ن‌ا",
    color: "#6C63B0",
    balance: -1_400_000,
    history: [
      { id: "ph5", amount: -2_000_000, date: "2026-08-20", note: "قرض برای تعمیر ماشین" },
      { id: "ph6", amount: 600_000, date: "2026-09-05", note: "بازپرداخت اول" },
    ],
  },
];

export const CHECKS: CheckItem[] = [
  {
    id: "c1",
    title: "اجاره مغازه همکار",
    amount: 15_000_000,
    dueDate: "2026-10-07",
    kind: "payable",
    bank: "بانک ملت",
    status: "upcoming",
  },
  {
    id: "c2",
    title: "چک مشتری پروژه وب",
    amount: 8_500_000,
    dueDate: "2026-09-28",
    kind: "receivable",
    bank: "بانک صادرات",
    status: "due",
  },
  {
    id: "c3",
    title: "چک فروشگاه لوازم",
    amount: 4_200_000,
    dueDate: "2026-09-23",
    kind: "payable",
    bank: "بانک پارسیان",
    status: "overdue",
  },
  {
    id: "c4",
    title: "چک دریافتی قرارداد",
    amount: 22_000_000,
    dueDate: "2026-10-23",
    kind: "receivable",
    bank: "بانک تجارت",
    status: "upcoming",
  },
];

export function createSeed(): FinanceSnapshot {
  return {
    onboarded: false,
    pin: null,
    biometric: false,
    reminders: { daily: true, weekly: false, hour: 21, minute: 0 },
    trialStartedAt: null,
    smsGranted: false,
    darkMode: false,
    userName: "سارا محمدی",
    categories: CATEGORIES,
    transactions: TRANSACTIONS,
    budgets: BUDGETS,
    assets: ASSETS,
    loans: LOANS,
    people: PEOPLE,
    checks: CHECKS,
  };
}
