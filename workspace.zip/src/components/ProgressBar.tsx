import { cn } from "@/lib/utils";

export function ProgressBar({
  value,
  className,
  tone = "accent",
}: {
  value: number;
  className?: string;
  tone?: "accent" | "danger" | "success";
}) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-primary-soft", className)}>
      <div
        className={cn(
          "h-full rounded-full transition-[width] duration-300 ease-out",
          tone === "accent" && "bg-accent",
          tone === "danger" && "bg-danger",
          tone === "success" && "bg-success",
        )}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
