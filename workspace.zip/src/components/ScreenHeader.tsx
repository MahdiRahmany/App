import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";

export function ScreenHeader({
  title,
  backTo,
  action,
}: {
  title: string;
  backTo?: string;
  action?: ReactNode;
}) {
  return (
    <header className="flex items-center gap-2 px-4 pb-2 pt-3">
      {backTo ? (
        <Link
          to={backTo}
          className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-card card-shadow"
          aria-label="بازگشت"
        >
          <ChevronRight className="size-5" />
        </Link>
      ) : null}
      <h1 className="min-w-0 flex-1 text-lg font-bold">{title}</h1>
      {action}
    </header>
  );
}
