import { ChevronLeft, ChevronRight } from "lucide-react";
import { formatMonthTitle } from "@/utils/format";
import { addJalaliMonth, parseMonthKey } from "@/utils/jalali";

export function MonthSwitcher({
  monthKey,
  onChange,
}: {
  monthKey: string;
  onChange: (key: string) => void;
}) {
  const { jy, jm } = parseMonthKey(monthKey);
  const prev = addJalaliMonth(jy, jm, -1);
  const next = addJalaliMonth(jy, jm, 1);
  return (
    <div className="flex items-center justify-between">
      <button
        type="button"
        aria-label="ماه بعد"
        className="flex size-10 items-center justify-center rounded-xl bg-card card-shadow"
        onClick={() => onChange(`${next.jy}-${String(next.jm).padStart(2, "0")}`)}
      >
        <ChevronLeft className="size-5" />
      </button>
      <p className="text-base font-bold">{formatMonthTitle(jy, jm)}</p>
      <button
        type="button"
        aria-label="ماه قبل"
        className="flex size-10 items-center justify-center rounded-xl bg-card card-shadow"
        onClick={() => onChange(`${prev.jy}-${String(prev.jm).padStart(2, "0")}`)}
      >
        <ChevronRight className="size-5" />
      </button>
    </div>
  );
}
