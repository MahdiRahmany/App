import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { formatCompact, formatJalaliShort } from "@/utils/format";
import { ChartWrap } from "./ChartWrap";

type Point = { date: string; value: number };

function Tip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: { payload: Point }[];
}) {
  if (!active || !payload?.[0]) return null;
  const p = payload[0].payload;
  return (
    <div className="rounded-xl bg-primary-dark px-3 py-2 text-xs text-white" dir="rtl">
      {formatJalaliShort(p.date)} · {formatCompact(p.value)}
    </div>
  );
}

export function LineTrend({ data }: { data: Point[] }) {
  return (
    <ChartWrap className="h-48">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
          <defs>
            <linearGradient id="assetFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--app-accent)" stopOpacity={0.35} />
              <stop offset="100%" stopColor="var(--app-accent)" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <XAxis dataKey="date" hide />
          <Tooltip content={<Tip />} />
          <Area
            type="monotone"
            dataKey="value"
            stroke="var(--app-accent)"
            strokeWidth={2.4}
            fill="url(#assetFill)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </ChartWrap>
  );
}
