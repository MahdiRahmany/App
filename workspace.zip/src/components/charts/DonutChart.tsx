import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";
import { ChartWrap } from "./ChartWrap";
import { formatCompact } from "@/utils/format";

export type DonutSlice = { name: string; value: number; color: string };

export function DonutChart({ data, center }: { data: DonutSlice[]; center: string }) {
  const total = data.reduce((s, d) => s + d.value, 0);
  return (
    <ChartWrap className="relative h-52">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius={62}
            outerRadius={88}
            paddingAngle={2}
            stroke="none"
          >
            {data.map((d) => (
              <Cell key={d.name} fill={d.color} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center" dir="rtl">
        <span className="text-xs text-muted">مجموع هزینه</span>
        <span className="text-lg font-bold tabular">{formatCompact(total)}</span>
        <span className="text-[11px] text-muted">{center}</span>
      </div>
    </ChartWrap>
  );
}
