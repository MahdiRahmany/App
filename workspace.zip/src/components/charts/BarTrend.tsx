import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { toFaDigits } from "@/utils/format";
import { ChartWrap } from "./ChartWrap";

type Point = { day: number; value: number };

function Tip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: { payload: Point }[];
}) {
  if (!active || !payload?.[0]) return null;
  const p = payload[0].payload;
  return (
    <div className="rounded-xl bg-primary-dark px-3 py-2 text-xs text-white" dir="rtl">
      روز {toFaDigits(p.day)} · {toFaDigits(Math.round(p.value).toLocaleString("fa-IR"))}
    </div>
  );
}

export function BarTrend({ data }: { data: Point[] }) {
  return (
    <ChartWrap>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 4, left: 4, bottom: 0 }}>
          <XAxis
            dataKey="day"
            tickFormatter={(v) => toFaDigits(v)}
            tick={{ fontSize: 10, fill: "var(--app-muted)", fontFamily: "inherit" }}
            axisLine={false}
            tickLine={false}
            interval={4}
          />
          <Tooltip content={<Tip />} cursor={{ fill: "var(--app-primary-soft)" }} />
          <Bar dataKey="value" fill="var(--app-accent)" radius={[6, 6, 2, 2]} maxBarSize={10} />
        </BarChart>
      </ResponsiveContainer>
    </ChartWrap>
  );
}
