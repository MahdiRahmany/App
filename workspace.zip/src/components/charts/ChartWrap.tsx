import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function ChartWrap({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) {
    return <div className={cn("h-44 animate-pulse rounded-2xl bg-primary-soft", className)} />;
  }
  return <div className={cn("h-44", className)} dir="ltr">{children}</div>;
}
