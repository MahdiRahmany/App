import { categoryById } from "@/store/finance-store";
import type { Category, Transaction } from "@/data/types";
import { cn } from "@/lib/utils";
import { formatJalaliShort, formatToman } from "@/utils/format";
import { CategoryGlyph } from "@/utils/icons";

export function TransactionRow({
  tx,
  categories,
  onClick,
}: {
  tx: Transaction;
  categories: Category[];
  onClick?: () => void;
}) {
  const cat = categoryById(tx.categoryId, categories);
  const income = tx.type === "income";
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-right transition-colors hover:bg-primary-soft/60"
    >
      <span
        className="flex size-11 shrink-0 items-center justify-center rounded-2xl text-white"
        style={{ background: cat?.color ?? "var(--color-primary)" }}
      >
        <CategoryGlyph icon={cat?.icon ?? "dots"} className="size-5" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-semibold text-ink">{tx.title}</span>
        <span className="block truncate text-xs text-muted">
          {cat?.name ?? "بدون دسته"} · {formatJalaliShort(tx.date)}
        </span>
      </span>
      <span
        className={cn(
          "shrink-0 text-sm font-bold tabular",
          income ? "text-success" : "text-danger",
        )}
      >
        {income ? "+" : "−"}
        {formatToman(tx.amount, false)}
      </span>
    </button>
  );
}
