import { cn } from "@/lib/utils";

export function Logo({ className, markClass }: { className?: string; markClass?: string }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span
        className={cn(
          "flex size-11 items-center justify-center rounded-2xl bg-accent text-white",
          markClass,
        )}
        aria-hidden
      >
        <svg viewBox="0 0 24 24" className="size-6" fill="none">
          <rect x="3" y="7" width="18" height="13" rx="3" stroke="currentColor" strokeWidth="1.8" />
          <path d="M3 11h18" stroke="currentColor" strokeWidth="1.8" />
          <circle cx="16.5" cy="15.5" r="1.4" fill="currentColor" />
          <path d="M8 7V6a4 4 0 0 1 8 0v1" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      </span>
      <span className="text-lg font-bold tracking-tight">حسابینو</span>
    </div>
  );
}
