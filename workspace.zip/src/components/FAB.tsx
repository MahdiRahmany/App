import { Plus } from "lucide-react";
import { cn } from "@/lib/utils";

export function FAB({
  onClick,
  label,
  className,
}: {
  onClick: () => void;
  label: string;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className={cn(
        "absolute bottom-32 left-4 z-30 flex size-14 items-center justify-center rounded-full bg-accent text-white shadow-[0_10px_24px_rgba(255,107,71,0.4)] transition-transform duration-150 active:scale-95",
        className,
      )}
    >
      <Plus className="size-7" strokeWidth={2.4} />
    </button>
  );
}
