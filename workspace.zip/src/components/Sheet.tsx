import type { ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export function Sheet({
  open,
  onClose,
  title,
  children,
  className,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  className?: string;
}) {
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-end">
      <button
        type="button"
        aria-label="بستن"
        className="absolute inset-0 bg-primary-dark/45"
        onClick={onClose}
      />
      <div
        className={cn(
          "sheet-panel relative max-h-[88%] overflow-y-auto rounded-t-3xl bg-card px-5 pb-8 pt-3",
          className,
        )}
        role="dialog"
        aria-modal
        aria-label={title}
      >
        <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-line" />
        {title ? (
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-bold">{title}</h2>
            <button
              type="button"
              onClick={onClose}
              className="flex size-10 items-center justify-center rounded-xl bg-background"
              aria-label="بستن"
            >
              <X className="size-5" />
            </button>
          </div>
        ) : null}
        {children}
      </div>
    </div>
  );
}
