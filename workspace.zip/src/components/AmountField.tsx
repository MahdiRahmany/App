import { formatGrouped, toEnDigits, toFaDigits } from "@/utils/format";

export function AmountField({
  value,
  onChange,
  label = "مبلغ (تومان)",
}: {
  value: string;
  onChange: (v: string) => void;
  label?: string;
}) {
  const display = value ? formatGrouped(Number(toEnDigits(value) || 0)) : "";
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-muted">{label}</span>
      <input
        inputMode="numeric"
        value={display}
        onChange={(e) => {
          const raw = toEnDigits(e.target.value).replace(/[^\d]/g, "");
          onChange(raw);
        }}
        placeholder={toFaDigits("0")}
        className="h-12 w-full rounded-2xl bg-background px-4 text-base font-bold tabular outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
      />
    </label>
  );
}

export function TextField({
  value,
  onChange,
  label,
  placeholder,
  type = "text",
}: {
  value: string;
  onChange: (v: string) => void;
  label: string;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-muted">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-12 w-full rounded-2xl bg-background px-4 text-sm outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
      />
    </label>
  );
}
