import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "soft";

export function Button({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      className={cn(
        "inline-flex h-12 items-center justify-center gap-2 rounded-2xl px-4 text-sm font-semibold transition-transform duration-150 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-45",
        variant === "primary" && "bg-accent text-white",
        variant === "secondary" && "bg-primary text-white",
        variant === "ghost" && "bg-transparent text-primary",
        variant === "danger" && "bg-danger text-white",
        variant === "soft" && "bg-primary-soft text-primary",
        className,
      )}
      {...props}
    />
  );
}
