import { Delete } from "lucide-react";
import { cn } from "@/lib/utils";
import { toFaDigits } from "@/utils/format";

export function PinDots({ length, filled }: { length: number; filled: number }) {
  return (
    <div className="flex justify-center gap-3" dir="ltr">
      {Array.from({ length }).map((_, i) => (
        <span
          key={i}
          className={cn(
            "size-3.5 rounded-full transition-colors",
            i < filled ? "bg-accent" : "bg-line",
          )}
        />
      ))}
    </div>
  );
}

export function PinPad({
  onDigit,
  onBackspace,
}: {
  onDigit: (d: string) => void;
  onBackspace: () => void;
}) {
  const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "back"] as const;
  return (
    <div className="mx-auto grid w-full max-w-xs grid-cols-3 gap-3" dir="ltr">
      {keys.map((k, i) => {
        if (k === "") return <span key={i} />;
        if (k === "back") {
          return (
            <button
              key={k}
              type="button"
              onClick={onBackspace}
              aria-label="پاک کردن"
              className="flex h-16 items-center justify-center rounded-full text-ink transition-colors hover:bg-primary-soft"
            >
              <Delete className="size-6" />
            </button>
          );
        }
        return (
          <button
            key={k}
            type="button"
            onClick={() => onDigit(k)}
            className="flex h-16 items-center justify-center rounded-full bg-card text-2xl font-bold card-shadow transition-transform active:scale-95"
          >
            {toFaDigits(k)}
          </button>
        );
      })}
    </div>
  );
}
