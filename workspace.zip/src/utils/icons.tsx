import type { LucideIcon } from "lucide-react";
import {
  ArrowDownLeft,
  Banknote,
  CarFront,
  Clapperboard,
  Coffee,
  Ellipsis,
  GraduationCap,
  HeartPulse,
  House,
  ShoppingBag,
  TrendingUp,
  Utensils,
  Zap,
} from "lucide-react";

export const CATEGORY_ICONS: Record<string, LucideIcon> = {
  utensils: Utensils,
  coffee: Coffee,
  car: CarFront,
  zap: Zap,
  clapper: Clapperboard,
  heart: HeartPulse,
  bag: ShoppingBag,
  home: House,
  edu: GraduationCap,
  dots: Ellipsis,
  banknote: Banknote,
  trend: TrendingUp,
  in: ArrowDownLeft,
};

export function CategoryGlyph({
  icon,
  className,
}: {
  icon: string;
  className?: string;
}) {
  const Icon = CATEGORY_ICONS[icon] ?? Ellipsis;
  return <Icon className={className} strokeWidth={1.9} />;
}
