import { JALALI_MONTHS, WEEKDAYS, toJalali } from "./jalali";

const FA = "۰۱۲۳۴۵۶۷۸۹";

export function toFaDigits(value: string | number): string {
  return String(value).replace(/\d/g, (d) => FA[Number(d)] ?? d);
}

export function toEnDigits(value: string): string {
  return value
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}

export function formatGrouped(amount: number): string {
  const abs = Math.abs(Math.round(amount));
  const grouped = abs.toString().replace(/\B(?=(\d{3})+(?!\d))/g, "٬");
  return toFaDigits(grouped);
}

export function formatToman(amount: number, withUnit = true): string {
  const sign = amount < 0 ? "−" : "";
  return `${sign}${formatGrouped(amount)}${withUnit ? " تومان" : ""}`;
}

export function formatCompact(amount: number): string {
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) {
    const n = (abs / 1_000_000_000).toFixed(abs >= 10_000_000_000 ? 0 : 1).replace(/\.0$/, "");
    return `${toFaDigits(n.replace(".", "٫"))} میلیارد`;
  }
  if (abs >= 1_000_000) {
    const n = (abs / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1).replace(/\.0$/, "");
    return `${toFaDigits(n.replace(".", "٫"))} میلیون`;
  }
  if (abs >= 1000) return formatGrouped(amount);
  return toFaDigits(Math.round(abs));
}

export function formatJalali(input: Date | string, opts?: { weekday?: boolean; year?: boolean }): string {
  const { jy, jm, jd } = toJalali(input);
  const month = JALALI_MONTHS[jm - 1];
  const yearPart = opts?.year === false ? "" : ` ${toFaDigits(jy)}`;
  const base = `${toFaDigits(jd)} ${month}${yearPart}`;
  if (opts?.weekday) {
    const d = typeof input === "string" ? new Date(input + (input.length === 10 ? "T12:00:00" : "")) : input;
    return `${WEEKDAYS[d.getDay()]} ${base}`;
  }
  return base;
}

export function formatJalaliShort(input: Date | string): string {
  const { jm, jd } = toJalali(input);
  return `${toFaDigits(jd)} ${JALALI_MONTHS[jm - 1]}`;
}

export function formatMonthTitle(jy: number, jm: number): string {
  return `${JALALI_MONTHS[jm - 1]} ${toFaDigits(jy)}`;
}

export function relativeDue(iso: string, today = new Date()): { label: string; tone: "ok" | "soon" | "late" } {
  const target = new Date(iso + (iso.length === 10 ? "T12:00:00" : ""));
  const a = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const b = new Date(target.getFullYear(), target.getMonth(), target.getDate()).getTime();
  const days = Math.round((b - a) / 86400000);
  if (days < 0) return { label: `${toFaDigits(Math.abs(days))} روز گذشته`, tone: "late" };
  if (days === 0) return { label: "امروز", tone: "soon" };
  if (days === 1) return { label: "فردا", tone: "soon" };
  if (days <= 7) return { label: `${toFaDigits(days)} روز مانده`, tone: "soon" };
  return { label: `${toFaDigits(days)} روز مانده`, tone: "ok" };
}
