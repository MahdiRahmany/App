import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PhoneFrame-B1JbcYEA.js
var import_jsx_runtime = require_jsx_runtime();
function Logo({ className, markClass }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-2", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("flex size-11 items-center justify-center rounded-2xl bg-accent text-white", markClass),
			"aria-hidden": true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 24 24",
				className: "size-6",
				fill: "none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "3",
						y: "7",
						width: "18",
						height: "13",
						rx: "3",
						stroke: "currentColor",
						strokeWidth: "1.8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M3 11h18",
						stroke: "currentColor",
						strokeWidth: "1.8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "16.5",
						cy: "15.5",
						r: "1.4",
						fill: "currentColor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M8 7V6a4 4 0 0 1 8 0v1",
						stroke: "currentColor",
						strokeWidth: "1.8",
						strokeLinecap: "round"
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-lg font-bold tracking-tight",
			children: "حسابینو"
		})]
	});
}
function PhoneFrame({ children, dark, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("phone-shell relative mx-auto min-h-svh w-full max-w-[430px] overflow-hidden", dark && "dark", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-svh bg-background text-ink",
			children
		})
	});
}
//#endregion
export { PhoneFrame as n, Logo as t };
