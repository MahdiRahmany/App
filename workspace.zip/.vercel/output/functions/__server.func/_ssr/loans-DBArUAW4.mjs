import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { o as formatToman, s as relativeDue } from "./format-4ArJapjy.mjs";
import { t as ScreenHeader } from "./ScreenHeader-DH1YY_i2.mjs";
import { t as Segmented } from "./Segmented-B8LgG8ZS.mjs";
import { t as ProgressBar } from "./ProgressBar-DapDGsKS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/loans-DBArUAW4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS = {
	"on-time": {
		label: "سر وقت",
		className: "bg-success/15 text-success"
	},
	late: {
		label: "معوق",
		className: "bg-danger/15 text-danger"
	},
	paid: {
		label: "تسویه",
		className: "bg-primary-soft text-primary"
	}
};
function LoansScreen() {
	const loans = useFinanceStore((s) => s.loans);
	const [kind, setKind] = (0, import_react.useState)("payable");
	const list = (0, import_react.useMemo)(() => loans.filter((l) => l.kind === kind), [loans, kind]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "قسط و وام",
			backTo: "/app/assets"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				value: kind,
				onChange: setKind,
				options: [{
					value: "payable",
					label: "پرداختی"
				}, {
					value: "receivable",
					label: "دریافتی"
				}]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3",
				children: list.map((l) => {
					const pct = (l.total - l.remaining) / l.total * 100;
					const due = relativeDue(l.dueDate);
					const st = STATUS[l.status] ?? STATUS["on-time"];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: l.name
							}), l.bank ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: l.bank
							}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("rounded-full px-2.5 py-1 text-[11px] font-semibold", st.className),
								children: st.label
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-lg font-bold tabular",
							children: formatToman(l.remaining)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: ["باقی‌مانده از ", formatToman(l.total)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, {
							className: "mt-3",
							value: pct,
							tone: l.status === "late" ? "danger" : "accent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: ["قسط: ", formatToman(l.installment)]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-semibold", due.tone === "late" ? "text-danger" : due.tone === "soon" ? "text-accent" : "text-muted"),
								children: due.label
							})]
						})
					] }, l.id);
				})
			})]
		})]
	});
}
var SplitComponent = LoansScreen;
//#endregion
export { SplitComponent as component };
