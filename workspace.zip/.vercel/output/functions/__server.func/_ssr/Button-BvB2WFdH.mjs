import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Button-BvB2WFdH.js
var import_jsx_runtime = require_jsx_runtime();
function Button({ variant = "primary", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex h-12 items-center justify-center gap-2 rounded-2xl px-4 text-sm font-semibold transition-transform duration-150 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-45", variant === "primary" && "bg-accent text-white", variant === "secondary" && "bg-primary text-white", variant === "ghost" && "bg-transparent text-primary", variant === "danger" && "bg-danger text-white", variant === "soft" && "bg-primary-soft text-primary", className),
		...props
	});
}
//#endregion
export { Button as t };
