import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ProgressBar-DapDGsKS.js
var import_jsx_runtime = require_jsx_runtime();
function ProgressBar({ value, className, tone = "accent" }) {
	const pct = Math.max(0, Math.min(100, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-2 w-full overflow-hidden rounded-full bg-primary-soft", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full rounded-full transition-[width] duration-300 ease-out", tone === "accent" && "bg-accent", tone === "danger" && "bg-danger", tone === "success" && "bg-success"),
			style: { width: `${pct}%` }
		})
	});
}
//#endregion
export { ProgressBar as t };
