import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as ChevronLeft, D as Handshake, I as Coins, j as FileSpreadsheet, v as Receipt } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { i as formatJalaliShort, l as toFaDigits, o as formatToman, t as formatCompact } from "./format-4ArJapjy.mjs";
import { t as ChartWrap } from "./ChartWrap-CV7EbEsG.mjs";
import { a as Area, i as XAxis, l as ResponsiveContainer, t as AreaChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assets-CuyJ4J3A.js
var import_jsx_runtime = require_jsx_runtime();
function Tip({ active, payload }) {
	if (!active || !payload?.[0]) return null;
	const p = payload[0].payload;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-primary-dark px-3 py-2 text-xs text-white",
		dir: "rtl",
		children: [
			formatJalaliShort(p.date),
			" · ",
			formatCompact(p.value)
		]
	});
}
function LineTrend({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartWrap, {
		className: "h-48",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					left: 8,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "assetFill",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "var(--app-accent)",
							stopOpacity: .35
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "var(--app-accent)",
							stopOpacity: .02
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "date",
						hide: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "value",
						stroke: "var(--app-accent)",
						strokeWidth: 2.4,
						fill: "url(#assetFill)"
					})
				]
			})
		})
	});
}
var LINKS = [
	{
		to: "/app/loans",
		label: "قسط و وام",
		desc: "پرداختی و دریافتی",
		icon: Receipt
	},
	{
		to: "/app/people",
		label: "طلب و بدهی",
		desc: "حساب با اشخاص",
		icon: Handshake
	},
	{
		to: "/app/checks",
		label: "سررسید و چک",
		desc: "یادآور رویدادهای مالی",
		icon: FileSpreadsheet
	}
];
function AssetsScreen() {
	const assets = useFinanceStore((s) => s.assets);
	const total = assets.reduce((s, a) => s + a.currentValue, 0);
	const gold = assets.filter((a) => a.kind === "gold");
	const crypto = assets.filter((a) => a.kind === "crypto");
	const history = (assets[0]?.history ?? []).map((p, i) => ({
		date: p.date,
		value: assets.reduce((s, a) => s + (a.history[i]?.value ?? a.currentValue), 0)
	}));
	const prev = history.length > 1 ? history[history.length - 2].value : total;
	const change = prev ? (total - prev) / prev * 100 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in px-4 pb-6 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-bold",
				children: "دارایی‌ها"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4 bg-primary-dark p-5 text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-white/70",
						children: "ارزش کل پورتفو"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-3xl font-bold tabular",
						children: formatToman(total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("mt-2 text-sm font-semibold", change >= 0 ? "text-success" : "text-accent"),
						children: [
							change >= 0 ? "+" : "",
							toFaDigits(change.toFixed(1)),
							"٪ نسبت به ماه قبل"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-1 font-bold",
					children: "روند ارزش کل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineTrend, { data: history })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 font-bold",
				children: "طلا"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 space-y-2",
				children: gold.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetRow, {
					name: a.name,
					meta: `${toFaDigits(a.amount)} ${a.unit}`,
					value: a.currentValue,
					pct: a.changePct
				}, a.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 font-bold",
				children: "ارز دیجیتال"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 space-y-2",
				children: crypto.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssetRow, {
					name: a.name,
					meta: `${toFaDigits(a.amount)} ${a.unit}`,
					value: a.currentValue,
					pct: a.changePct
				}, a.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-2",
				children: LINKS.map((l) => {
					const Icon = l.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: l.to,
						className: "block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-11 items-center justify-center rounded-2xl bg-accent-soft text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-bold",
										children: l.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted",
										children: l.desc
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5 text-muted" })
							]
						})
					}, l.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 flex items-center gap-2 text-[11px] text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-3.5" }), "قیمت‌ها نمونه و آفلاین هستند؛ نرخ لحظه‌ای بازار نیست."]
			})
		]
	});
}
function AssetRow({ name, meta, value, pct }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-bold",
			children: name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: meta
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-bold tabular",
				children: formatCompact(value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("text-xs font-semibold", pct >= 0 ? "text-success" : "text-danger"),
				children: [
					pct >= 0 ? "+" : "",
					toFaDigits(pct.toFixed(1)),
					"٪"
				]
			})]
		})]
	});
}
var SplitComponent = AssetsScreen;
//#endregion
export { SplitComponent as component };
