import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as ChevronLeft, z as ChevronRight } from "../_libs/lucide-react.mjs";
import { l as addJalaliMonth, p as parseMonthKey } from "./router-CxVnniVP.mjs";
import { a as formatMonthTitle } from "./format-4ArJapjy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/MonthSwitcher-BIFoaZsj.js
var import_jsx_runtime = require_jsx_runtime();
function MonthSwitcher({ monthKey, onChange }) {
	const { jy, jm } = parseMonthKey(monthKey);
	const prev = addJalaliMonth(jy, jm, -1);
	const next = addJalaliMonth(jy, jm, 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "ماه بعد",
				className: "flex size-10 items-center justify-center rounded-xl bg-card card-shadow",
				onClick: () => onChange(`${next.jy}-${String(next.jm).padStart(2, "0")}`),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-base font-bold",
				children: formatMonthTitle(jy, jm)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "ماه قبل",
				className: "flex size-10 items-center justify-center rounded-xl bg-card card-shadow",
				onClick: () => onChange(`${prev.jy}-${String(prev.jm).padStart(2, "0")}`),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
			})
		]
	});
}
//#endregion
export { MonthSwitcher as t };
