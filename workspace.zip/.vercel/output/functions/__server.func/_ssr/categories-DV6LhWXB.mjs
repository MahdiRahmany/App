import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { b as Pencil, l as Trash2, y as Plus } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { t as Sheet } from "./Sheet-ZcYj---f.mjs";
import { n as TextField } from "./AmountField-jW0mV4jB.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { t as ScreenHeader } from "./ScreenHeader-DH1YY_i2.mjs";
import { t as CategoryGlyph } from "./icons-BQjgpZV9.mjs";
import { t as Segmented } from "./Segmented-B8LgG8ZS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/categories-DV6LhWXB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = [
	"utensils",
	"car",
	"zap",
	"clapper",
	"heart",
	"bag",
	"home",
	"edu",
	"dots",
	"banknote"
];
var COLORS = [
	"var(--color-cat-food)",
	"var(--color-cat-transport)",
	"var(--color-cat-bills)",
	"var(--color-cat-fun)",
	"var(--color-cat-health)",
	"var(--color-cat-shop)",
	"var(--color-cat-home)",
	"var(--color-cat-edu)"
];
function CategoriesScreen() {
	const categories = useFinanceStore((s) => s.categories);
	const addCategory = useFinanceStore((s) => s.addCategory);
	const updateCategory = useFinanceStore((s) => s.updateCategory);
	const removeCategory = useFinanceStore((s) => s.removeCategory);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("expense");
	const [icon, setIcon] = (0, import_react.useState)("dots");
	const [color, setColor] = (0, import_react.useState)(COLORS[0]);
	const [parentId, setParentId] = (0, import_react.useState)("");
	const roots = categories.filter((c) => !c.parentId);
	function openNew() {
		setEditId(null);
		setName("");
		setType("expense");
		setIcon("dots");
		setColor(COLORS[0]);
		setParentId("");
		setOpen(true);
	}
	function openEdit(id) {
		const c = categories.find((x) => x.id === id);
		if (!c) return;
		setEditId(id);
		setName(c.name);
		setType(c.type);
		setIcon(c.icon);
		setColor(c.color);
		setParentId(c.parentId ?? "");
		setOpen(true);
	}
	function save() {
		if (!name.trim()) return;
		if (editId) updateCategory(editId, {
			name: name.trim(),
			icon,
			color,
			parentId: parentId || void 0,
			type
		});
		else addCategory({
			name: name.trim(),
			icon,
			color,
			type,
			parentId: parentId || void 0
		});
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: "دسته‌بندی‌ها",
				backTo: "/app/settings",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: openNew,
					className: "flex size-11 items-center justify-center rounded-2xl bg-accent text-white",
					"aria-label": "دسته جدید",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 px-4",
				children: roots.map((c) => {
					const children = categories.filter((x) => x.parentId === c.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 items-center justify-center rounded-xl text-white",
								style: { background: c.color },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryGlyph, {
									icon: c.icon,
									className: "size-4"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 font-bold",
								children: c.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted",
								children: c.type === "income" ? "درآمد" : "هزینه"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => openEdit(c.id),
								"aria-label": "ویرایش",
								className: "p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4 text-muted" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => removeCategory(c.id),
								"aria-label": "حذف",
								className: "p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-danger" })
							})
						]
					}), children.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2 border-r border-line pr-3",
						children: children.map((ch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ch.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "p-2",
									onClick: () => openEdit(ch.id),
									"aria-label": "ویرایش",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5 text-muted" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "p-2",
									onClick: () => removeCategory(ch.id),
									"aria-label": "حذف",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 text-danger" })
								})]
							})]
						}, ch.id))
					}) : null] }, c.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open,
				onClose: () => setOpen(false),
				title: editId ? "ویرایش دسته" : "دسته جدید",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
							value: type,
							onChange: setType,
							options: [{
								value: "expense",
								label: "هزینه"
							}, {
								value: "income",
								label: "درآمد"
							}]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							value: name,
							onChange: setName,
							label: "نام دسته"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1.5 block text-sm text-muted",
								children: "زیرمجموعهٔ (اختیاری)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: parentId,
								onChange: (e) => setParentId(e.target.value),
								className: "h-12 w-full rounded-2xl bg-background px-3 text-sm ring-1 ring-line",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "دسته اصلی"
								}), roots.filter((c) => c.type === type && c.id !== editId).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: c.id,
									children: c.name
								}, c.id))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "آیکون"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: ICONS.map((ic) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setIcon(ic),
								className: cn("flex size-10 items-center justify-center rounded-xl", icon === ic ? "bg-accent text-white" : "bg-background"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryGlyph, {
									icon: ic,
									className: "size-4"
								})
							}, ic))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "رنگ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: COLORS.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setColor(col),
								className: cn("size-8 rounded-full ring-2", color === col ? "ring-ink" : "ring-transparent"),
								style: { background: col }
							}, col))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: save,
							disabled: !name.trim(),
							children: "ذخیره"
						})
					]
				})
			})
		]
	});
}
var SplitComponent = CategoriesScreen;
//#endregion
export { SplitComponent as component };
