import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as Fingerprint } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { n as PhoneFrame, t as Logo } from "./PhoneFrame-B1JbcYEA.mjs";
import { n as PinPad, t as PinDots } from "./PinPad-DqvaHiH0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lock-BxZFf00o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LockScreen() {
	const navigate = useNavigate();
	const unlockWithPin = useFinanceStore((s) => s.unlockWithPin);
	const unlockBiometric = useFinanceStore((s) => s.unlockBiometric);
	const biometric = useFinanceStore((s) => s.biometric);
	const [pin, setPin] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function tryUnlock(next) {
		setPin(next);
		setError("");
		if (next.length === 4) {
			if (unlockWithPin(next)) navigate({ to: "/app" });
			else {
				setError("رمز نادرست است");
				setPin("");
			}
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-svh flex-col items-center px-6 pt-16 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-lg font-bold",
				children: "قفل فقط برای خودت"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "رمز چهار رقمی را وارد کن"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinDots, {
					length: 4,
					filled: pin.length
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm font-medium text-danger",
				children: error
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinPad, {
					onDigit: (d) => {
						if (pin.length < 4) tryUnlock(pin + d);
					},
					onBackspace: () => setPin((p) => p.slice(0, -1))
				})
			}),
			biometric ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-8 flex items-center gap-2 text-sm font-semibold text-accent",
				onClick: () => {
					if (unlockBiometric()) navigate({ to: "/app" });
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "size-5" }), "ورود با اثر انگشت"]
			}) : null
		]
	}) });
}
var SplitComponent = LockScreen;
//#endregion
export { SplitComponent as component };
