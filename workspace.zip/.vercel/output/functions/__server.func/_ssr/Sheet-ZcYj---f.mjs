import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as X } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Sheet-ZcYj---f.js
var import_jsx_runtime = require_jsx_runtime();
function Sheet({ open, onClose, title, children, className }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-40 flex flex-col justify-end",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "بستن",
			className: "absolute inset-0 bg-primary-dark/45",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("sheet-panel relative max-h-[88%] overflow-y-auto rounded-t-3xl bg-card px-5 pb-8 pt-3", className),
			role: "dialog",
			"aria-modal": true,
			"aria-label": title,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1.5 w-12 rounded-full bg-line" }),
				title ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "flex size-10 items-center justify-center rounded-xl bg-background",
						"aria-label": "بستن",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}) : null,
				children
			]
		})]
	});
}
//#endregion
export { Sheet as t };
