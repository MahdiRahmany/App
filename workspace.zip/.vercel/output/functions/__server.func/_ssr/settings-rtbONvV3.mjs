import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as Fingerprint, B as ChevronLeft, F as DatabaseBackup, _ as RotateCcw, k as FolderTree, p as Shield } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { l as toFaDigits } from "./format-4ArJapjy.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { t as Switch } from "./Switch-Nt3W2yyJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-rtbONvV3.js
var import_jsx_runtime = require_jsx_runtime();
function trialLeft(iso) {
	if (!iso) return 31;
	const end = new Date(iso).getTime() + 26784e5;
	return Math.max(0, Math.ceil((end - Date.now()) / 864e5));
}
function SettingsScreen() {
	const darkMode = useFinanceStore((s) => s.darkMode);
	const setDarkMode = useFinanceStore((s) => s.setDarkMode);
	const biometric = useFinanceStore((s) => s.biometric);
	const pin = useFinanceStore((s) => s.pin);
	const smsGranted = useFinanceStore((s) => s.smsGranted);
	const trialStartedAt = useFinanceStore((s) => s.trialStartedAt);
	const userName = useFinanceStore((s) => s.userName);
	const resetDemo = useFinanceStore((s) => s.resetDemo);
	const days = trialLeft(trialStartedAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in px-4 pb-6 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-bold",
				children: "تنظیمات"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-12 items-center justify-center rounded-2xl bg-primary text-white font-bold",
					children: userName.split(" ").map((p) => p[0]).join("").slice(0, 2)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-bold",
					children: userName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: days > 0 ? `${toFaDigits(days)} روز از دوره آزمایشی باقی است` : "دوره آزمایشی تمام شده"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					to: "/app/settings/categories",
					icon: FolderTree,
					title: "دسته‌بندی‌ها",
					desc: "افزودن و ویرایش دسته و زیرمجموعه"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					to: "/app/settings/backup",
					icon: DatabaseBackup,
					title: "پشتیبان‌گیری",
					desc: "خروجی و بازیابی فایل JSON محلی"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						label: "حالت شب",
						checked: darkMode,
						onCheckedChange: setDarkMode
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "size-4 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["اثر انگشت: ", biometric ? "فعال" : "خاموش"] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["قفل PIN: ", pin ? "تنظیم شده" : "ندارد"] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-6 text-muted",
						children: smsGranted ? "دسترسی پیامک در همین دستگاه شبیه‌سازی شده. مرورگر وب نمی‌تواند پیامک واقعی بانک را بخواند." : "خواندن پیامک بانکی روی وب امکان‌پذیر نیست؛ تراکنش‌ها را دستی ثبت کن یا از داده نمونه استفاده کن."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "mt-0.5 size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "بازگشت به داده نمونه"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs leading-6 text-muted",
								children: "تراکنش‌ها و بودجه‌ها به حالت اولیه دمو برمی‌گردند."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "soft",
								className: "mt-3 h-10 text-xs",
								onClick: resetDemo,
								children: "بازنشانی داده"
							})
						]
					})]
				})
			})
		]
	});
}
function Row({ to, icon: Icon, title, desc }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: "block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-11 items-center justify-center rounded-2xl bg-primary-soft text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-bold",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: desc
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5 text-muted" })
			]
		})
	});
}
var SplitComponent = SettingsScreen;
//#endregion
export { SplitComponent as component };
