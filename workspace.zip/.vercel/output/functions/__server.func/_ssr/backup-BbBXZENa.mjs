import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { N as Download, a as Upload } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { t as ScreenHeader } from "./ScreenHeader-DH1YY_i2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/backup-BbBXZENa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function isSnapshot(v) {
	if (!v || typeof v !== "object") return false;
	const o = v;
	return Array.isArray(o.transactions) && Array.isArray(o.categories);
}
function BackupScreen() {
	const exportSnapshot = useFinanceStore((s) => s.exportSnapshot);
	const importSnapshot = useFinanceStore((s) => s.importSnapshot);
	const inputRef = (0, import_react.useRef)(null);
	const [message, setMessage] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function download() {
		const data = exportSnapshot();
		const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "hesabino-backup.json";
		a.click();
		URL.revokeObjectURL(url);
		setMessage("فایل پشتیبان دانلود شد.");
		setError("");
	}
	async function onFile(file) {
		try {
			const text = await file.text();
			const parsed = JSON.parse(text);
			if (!isSnapshot(parsed)) throw new Error("invalid");
			importSnapshot(parsed);
			setMessage("بازیابی با موفقیت انجام شد.");
			setError("");
		} catch {
			setError("فایل نامعتبر است. یک خروجی JSON حسابینو انتخاب کن.");
			setMessage("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "پشتیبان‌گیری و بازیابی",
			backTo: "/app/settings"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-7 text-muted",
					children: "همه داده‌ها فقط روی همین مرورگر ذخیره می‌شود. می‌توانی یک فایل JSON بگیری و بعداً همان را برگردانی — بدون سرور."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-2xl bg-accent-soft text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: "خروجی گرفتن"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs leading-6 text-muted",
								children: "تراکنش، بودجه، دارایی و تنظیمات در یک فایل."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "mt-3 h-10 text-xs",
								onClick: download,
								children: "دانلود JSON"
							})
						]
					})]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-11 items-center justify-center rounded-2xl bg-primary-soft text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: "بازیابی"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs leading-6 text-muted",
								children: "فایل قبلی جایگزین داده فعلی می‌شود."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								className: "mt-3 h-10 text-xs",
								onClick: () => inputRef.current?.click(),
								children: "انتخاب فایل"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: inputRef,
								type: "file",
								accept: "application/json,.json",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) onFile(f);
									e.target.value = "";
								}
							})
						]
					})]
				}) }),
				message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-success",
					children: message
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-danger",
					children: error
				}) : null
			]
		})]
	});
}
var SplitComponent = BackupScreen;
//#endregion
export { SplitComponent as component };
