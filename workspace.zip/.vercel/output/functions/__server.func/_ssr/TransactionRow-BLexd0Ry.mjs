import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as categoryById } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { i as formatJalaliShort, o as formatToman } from "./format-4ArJapjy.mjs";
import { t as CategoryGlyph } from "./icons-BQjgpZV9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/TransactionRow-BLexd0Ry.js
var import_jsx_runtime = require_jsx_runtime();
function TransactionRow({ tx, categories, onClick }) {
	const cat = categoryById(tx.categoryId, categories);
	const income = tx.type === "income";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-right transition-colors hover:bg-primary-soft/60",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-11 shrink-0 items-center justify-center rounded-2xl text-white",
				style: { background: cat?.color ?? "var(--color-primary)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryGlyph, {
					icon: cat?.icon ?? "dots",
					className: "size-5"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate font-semibold text-ink",
					children: tx.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block truncate text-xs text-muted",
					children: [
						cat?.name ?? "بدون دسته",
						" · ",
						formatJalaliShort(tx.date)
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("shrink-0 text-sm font-bold tabular", income ? "text-success" : "text-danger"),
				children: [income ? "+" : "−", formatToman(tx.amount, false)]
			})
		]
	});
}
//#endregion
export { TransactionRow as t };
