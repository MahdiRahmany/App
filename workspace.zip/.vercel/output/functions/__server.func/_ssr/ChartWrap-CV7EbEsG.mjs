import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ChartWrap-CV7EbEsG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChartWrap({ children, className }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-44 animate-pulse rounded-2xl bg-primary-soft", className) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-44", className),
		dir: "ltr",
		children
	});
}
//#endregion
export { ChartWrap as t };
