import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as ChevronLeft, y as Plus } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { o as formatToman } from "./format-4ArJapjy.mjs";
import { t as Sheet } from "./Sheet-ZcYj---f.mjs";
import { n as TextField } from "./AmountField-jW0mV4jB.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { t as ScreenHeader } from "./ScreenHeader-DH1YY_i2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/people-D4dOtb1B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PeopleScreen() {
	const people = useFinanceStore((s) => s.people);
	const addPerson = useFinanceStore((s) => s.addPerson);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const receivable = people.filter((p) => p.balance > 0).reduce((s, p) => s + p.balance, 0);
	const payable = people.filter((p) => p.balance < 0).reduce((s, p) => s + Math.abs(p.balance), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: "طلب و بدهی",
				backTo: "/app/assets",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOpen(true),
					className: "flex size-11 items-center justify-center rounded-2xl bg-accent text-white",
					"aria-label": "شخص جدید",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "طلب از دیگران"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-bold tabular text-success",
						children: formatToman(receivable, false)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "بدهی به دیگران"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-bold tabular text-danger",
						children: formatToman(payable, false)
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-2",
					children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/app/people/$personId",
						params: { personId: p.id },
						className: "block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-11 items-center justify-center rounded-2xl text-sm font-bold text-white",
									style: { background: p.color },
									children: p.initials
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-bold",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted",
										children: p.balance === 0 ? "حساب صفر" : p.balance > 0 ? "به تو بدهکار است" : "طلبکار از توست"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("font-bold tabular", p.balance > 0 ? "text-success" : p.balance < 0 ? "text-danger" : "text-muted"),
									children: formatToman(Math.abs(p.balance), false)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 text-muted" })
							]
						})
					}, p.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open,
				onClose: () => setOpen(false),
				title: "شخص جدید",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						value: name,
						onChange: setName,
						label: "نام و نام خانوادگی",
						placeholder: "مثلاً رضا موسوی"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: !name.trim(),
						onClick: () => {
							addPerson(name.trim());
							setName("");
							setOpen(false);
						},
						children: "افزودن"
					})]
				})
			})
		]
	});
}
var SplitComponent = PeopleScreen;
//#endregion
export { SplitComponent as component };
