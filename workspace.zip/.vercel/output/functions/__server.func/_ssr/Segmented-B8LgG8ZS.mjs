import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Segmented-B8LgG8ZS.js
var import_jsx_runtime = require_jsx_runtime();
function Segmented({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex rounded-2xl bg-primary-soft p-1",
		children: options.map((opt) => {
			const active = opt.value === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(opt.value),
				className: cn("h-10 flex-1 rounded-xl text-sm font-semibold transition-colors duration-150", active ? "bg-accent text-white shadow-sm" : "text-muted"),
				children: opt.label
			}, opt.value);
		})
	});
}
//#endregion
export { Segmented as t };
