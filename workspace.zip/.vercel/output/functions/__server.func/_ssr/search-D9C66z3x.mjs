import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { r as formatJalali } from "./format-4ArJapjy.mjs";
import { t as AmountField } from "./AmountField-jW0mV4jB.mjs";
import { t as ScreenHeader } from "./ScreenHeader-DH1YY_i2.mjs";
import { t as TransactionRow } from "./TransactionRow-BLexd0Ry.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-D9C66z3x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RANGES = [
	{
		id: "all",
		label: "همه"
	},
	{
		id: "week",
		label: "این هفته"
	},
	{
		id: "month",
		label: "این ماه"
	}
];
function SearchScreen() {
	const transactions = useFinanceStore((s) => s.transactions);
	const categories = useFinanceStore((s) => s.categories);
	const [q, setQ] = (0, import_react.useState)("");
	const [cat, setCat] = (0, import_react.useState)("all");
	const [range, setRange] = (0, import_react.useState)("all");
	const [min, setMin] = (0, import_react.useState)("");
	const [max, setMax] = (0, import_react.useState)("");
	const [showFilters, setShowFilters] = (0, import_react.useState)(false);
	const roots = categories.filter((c) => !c.parentId);
	const results = (0, import_react.useMemo)(() => {
		const now = /* @__PURE__ */ new Date();
		const weekAgo = new Date(now);
		weekAgo.setDate(now.getDate() - 7);
		const monthAgo = new Date(now);
		monthAgo.setDate(now.getDate() - 31);
		const minN = min ? Number(min) : 0;
		const maxN = max ? Number(max) : Infinity;
		const query = q.trim();
		return transactions.filter((t) => {
			if (query && !`${t.title} ${t.merchant}`.includes(query)) return false;
			if (cat !== "all") {
				const c = categories.find((x) => x.id === t.categoryId);
				if (t.categoryId !== cat && c?.parentId !== cat) return false;
			}
			const d = new Date(t.date);
			if (range === "week" && d < weekAgo) return false;
			if (range === "month" && d < monthAgo) return false;
			if (t.amount < minN || t.amount > maxN) return false;
			return true;
		}).sort((a, b) => b.date.localeCompare(a.date));
	}, [
		transactions,
		categories,
		q,
		cat,
		range,
		min,
		max
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "جستجوی تراکنش",
			backTo: "/app"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "نام فروشگاه یا عنوان…",
					className: "h-12 w-full rounded-2xl bg-card px-4 text-sm outline-none ring-1 ring-line card-shadow focus:ring-2 focus:ring-accent"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 text-xs font-semibold text-accent",
					onClick: () => setShowFilters((s) => !s),
					children: showFilters ? "بستن فیلترها" : "فیلتر دسته، تاریخ و مبلغ"
				}),
				showFilters ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "mt-3 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium text-muted",
							children: "بازه زمانی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: RANGES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setRange(r.id),
								className: cn("h-9 flex-1 rounded-xl text-xs font-semibold", range === r.id ? "bg-accent text-white" : "bg-background"),
								children: r.label
							}, r.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium text-muted",
							children: "دسته"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCat("all"),
								className: cn("rounded-full px-3 py-1.5 text-xs font-semibold", cat === "all" ? "bg-accent text-white" : "bg-background"),
								children: "همه"
							}), roots.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCat(c.id),
								className: cn("rounded-full px-3 py-1.5 text-xs font-semibold", cat === c.id ? "bg-accent text-white" : "bg-background"),
								children: c.name
							}, c.id))]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmountField, {
								value: min,
								onChange: setMin,
								label: "حداقل مبلغ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmountField, {
								value: max,
								onChange: setMax,
								label: "حداکثر مبلغ"
							})]
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs text-muted",
					children: [results.length.toLocaleString("fa-IR"), " نتیجه"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "mt-2 space-y-1",
					children: results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted",
						children: "تراکنشی با این فیلتر پیدا نشد"
					}) : results.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionRow, {
						tx,
						categories
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 pb-2 text-[10px] text-muted",
						children: formatJalali(tx.date)
					})] }, tx.id))
				})
			]
		})]
	});
}
var SplitComponent = SearchScreen;
//#endregion
export { SplitComponent as component };
