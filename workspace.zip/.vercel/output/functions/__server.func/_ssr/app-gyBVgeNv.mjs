import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, g as Outlet, p as useRouterState, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { H as ChartPie, T as House, h as Settings, r as Wallet, w as Landmark } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-gyBVgeNv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		to: "/app",
		label: "خانه",
		icon: House,
		match: (p) => p === "/app" || p.startsWith("/app/search")
	},
	{
		to: "/app/reports",
		label: "گزارش‌ها",
		icon: ChartPie,
		match: (p) => p.startsWith("/app/reports")
	},
	{
		to: "/app/budget",
		label: "بودجه",
		icon: Wallet,
		match: (p) => p.startsWith("/app/budget")
	},
	{
		to: "/app/assets",
		label: "دارایی‌ها",
		icon: Landmark,
		match: (p) => p.startsWith("/app/assets") || p.startsWith("/app/loans") || p.startsWith("/app/people") || p.startsWith("/app/checks")
	},
	{
		to: "/app/settings",
		label: "تنظیمات",
		icon: Settings,
		match: (p) => p.startsWith("/app/settings")
	}
];
function BottomTabs() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "absolute inset-x-0 bottom-0 z-20 border-t border-line bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid grid-cols-5 px-1 pt-1",
			children: TABS.map((tab) => {
				const active = tab.match(pathname);
				const Icon = tab.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: tab.to,
					className: cn("flex flex-col items-center gap-0.5 py-2 text-[10px] font-semibold", active ? "text-accent" : "text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: active ? 2.4 : 1.8
					}), tab.label]
				}) }, tab.to);
			})
		})
	});
}
function AppShell() {
	const navigate = useNavigate();
	const hydrated = useFinanceStore((s) => s.hydrated);
	const onboarded = useFinanceStore((s) => s.onboarded);
	const pin = useFinanceStore((s) => s.pin);
	const unlocked = useFinanceStore((s) => s.unlocked);
	const darkMode = useFinanceStore((s) => s.darkMode);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (!onboarded) navigate({ to: "/onboarding" });
		else if (pin && !unlocked) navigate({ to: "/lock" });
	}, [
		hydrated,
		onboarded,
		pin,
		unlocked,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("phone-shell relative mx-auto flex min-h-svh w-full max-w-[430px] flex-col", darkMode && "dark"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-svh flex-col bg-background text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "relative flex-1 overflow-y-auto pb-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomTabs, {})]
		})
	});
}
var SplitComponent = AppShell;
//#endregion
export { SplitComponent as component };
