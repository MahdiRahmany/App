import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { E as HeartPulse, G as Banknote, K as ArrowDownLeft, L as Coffee, M as Ellipsis, O as GraduationCap, R as Clapperboard, T as House, U as CarFront, f as ShoppingBag, i as Utensils, s as TrendingUp, t as Zap } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/icons-BQjgpZV9.js
var import_jsx_runtime = require_jsx_runtime();
var CATEGORY_ICONS = {
	utensils: Utensils,
	coffee: Coffee,
	car: CarFront,
	zap: Zap,
	clapper: Clapperboard,
	heart: HeartPulse,
	bag: ShoppingBag,
	home: House,
	edu: GraduationCap,
	dots: Ellipsis,
	banknote: Banknote,
	trend: TrendingUp,
	in: ArrowDownLeft
};
function CategoryGlyph({ icon, className }) {
	const Icon = CATEGORY_ICONS[icon] ?? Ellipsis;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.9
	});
}
//#endregion
export { CategoryGlyph as t };
