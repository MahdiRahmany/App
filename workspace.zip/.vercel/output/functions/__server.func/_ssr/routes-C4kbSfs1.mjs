import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { n as PhoneFrame, t as Logo } from "./PhoneFrame-B1JbcYEA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C4kbSfs1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Gate() {
	const navigate = useNavigate();
	const hydrated = useFinanceStore((s) => s.hydrated);
	const onboarded = useFinanceStore((s) => s.onboarded);
	const pin = useFinanceStore((s) => s.pin);
	const unlocked = useFinanceStore((s) => s.unlocked);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (!onboarded) navigate({ to: "/onboarding" });
		else if (pin && !unlocked) navigate({ to: "/lock" });
		else navigate({ to: "/app" });
	}, [
		hydrated,
		onboarded,
		pin,
		unlocked,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-svh flex-col items-center justify-center gap-4 px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { markClass: "size-16 rounded-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "دخل‌وخرجت، همیشه دمِ دست"
		})]
	}) });
}
//#endregion
export { Gate as component };
