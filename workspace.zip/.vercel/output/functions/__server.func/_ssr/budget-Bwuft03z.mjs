import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as Plus } from "../_libs/lucide-react.mjs";
import { a as spentInMonth, d as jalaliMonthKey, o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { l as toFaDigits, o as formatToman } from "./format-4ArJapjy.mjs";
import { t as Sheet } from "./Sheet-ZcYj---f.mjs";
import { t as AmountField } from "./AmountField-jW0mV4jB.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { t as MonthSwitcher } from "./MonthSwitcher-BIFoaZsj.mjs";
import { t as CategoryGlyph } from "./icons-BQjgpZV9.mjs";
import { t as ProgressBar } from "./ProgressBar-DapDGsKS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/budget-Bwuft03z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FAB({ onClick, label, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-label": label,
		className: cn("absolute bottom-24 left-4 z-30 flex size-14 items-center justify-center rounded-full bg-accent text-white shadow-[0_10px_24px_rgba(255,107,71,0.4)] transition-transform duration-150 active:scale-95", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
			className: "size-7",
			strokeWidth: 2.4
		})
	});
}
function BudgetScreen() {
	const budgets = useFinanceStore((s) => s.budgets);
	const categories = useFinanceStore((s) => s.categories);
	const transactions = useFinanceStore((s) => s.transactions);
	const addBudget = useFinanceStore((s) => s.addBudget);
	const updateBudget = useFinanceStore((s) => s.updateBudget);
	const removeBudget = useFinanceStore((s) => s.removeBudget);
	const [monthKey, setMonthKey] = (0, import_react.useState)(() => jalaliMonthKey(/* @__PURE__ */ new Date()));
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [catId, setCatId] = (0, import_react.useState)("food");
	const [amount, setAmount] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		return budgets.map((b) => {
			const cat = categories.find((c) => c.id === b.categoryId);
			const spent = spentInMonth(transactions, categories, monthKey, b.categoryId);
			return {
				b,
				cat,
				spent,
				pct: b.amount ? spent / b.amount * 100 : 0
			};
		}).sort((a, b) => b.pct - a.pct);
	}, [
		budgets,
		categories,
		transactions,
		monthKey
	]);
	const expenseCats = categories.filter((c) => c.type === "expense" && !c.parentId);
	function openNew() {
		setEditId(null);
		setCatId(expenseCats[0]?.id ?? "food");
		setAmount("");
		setOpen(true);
	}
	function openEdit(id, categoryId, value) {
		setEditId(id);
		setCatId(categoryId);
		setAmount(String(value));
		setOpen(true);
	}
	function save() {
		const n = Number(amount);
		if (!n) return;
		if (editId) updateBudget(editId, n);
		else addBudget(catId, n);
		setOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in relative px-4 pb-6 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-bold",
				children: "بودجه"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "سقف هزینه هر دسته در ماه انتخابی"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthSwitcher, {
					monthKey,
					onChange: setMonthKey
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3",
				children: rows.map(({ b, cat, spent, pct }) => {
					const over = pct >= 100;
					const warn = pct >= 80;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => openEdit(b.id, b.categoryId, b.amount),
						className: "w-full text-right",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-11 items-center justify-center rounded-2xl text-white",
								style: { background: cat?.color ?? "var(--color-primary)" },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryGlyph, {
									icon: cat?.icon ?? "dots",
									className: "size-5"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold",
											children: cat?.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: cn("text-xs font-semibold tabular", over ? "text-danger" : "text-muted"),
											children: [toFaDigits(Math.round(pct)), "٪"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-0.5 text-xs text-muted",
										children: [
											formatToman(spent, false),
											" از ",
											formatToman(b.amount, false)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, {
										className: "mt-2",
										value: pct,
										tone: over ? "danger" : warn ? "accent" : "success"
									})
								]
							})]
						}) })
					}, b.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FAB, {
				onClick: openNew,
				label: "بودجه جدید"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open,
				onClose: () => setOpen(false),
				title: editId ? "ویرایش بودجه" : "بودجه جدید",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						!editId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "دسته"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: expenseCats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCatId(c.id),
								className: cn("rounded-full px-3 py-2 text-xs font-semibold", catId === c.id ? "bg-accent text-white" : "bg-background"),
								children: c.name
							}, c.id))
						})] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmountField, {
							value: amount,
							onChange: setAmount,
							label: "سقف ماهانه"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: save,
							disabled: !amount,
							children: "ذخیره"
						}),
						editId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "w-full text-danger",
							onClick: () => {
								removeBudget(editId);
								setOpen(false);
							},
							children: "حذف بودجه"
						}) : null
					]
				})
			})
		]
	});
}
var SplitComponent = BudgetScreen;
//#endregion
export { SplitComponent as component };
