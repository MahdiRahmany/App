import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { W as Bell, c as TrendingDown, g as Search, s as TrendingUp, y as Plus } from "../_libs/lucide-react.mjs";
import { d as jalaliMonthKey, f as monthRange, i as monthTotals, m as toJalali, o as useFinanceStore, p as parseMonthKey, u as isoDate } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { l as toFaDigits, o as formatToman, r as formatJalali, t as formatCompact } from "./format-4ArJapjy.mjs";
import { t as Sheet } from "./Sheet-ZcYj---f.mjs";
import { n as TextField, t as AmountField } from "./AmountField-jW0mV4jB.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { t as ChartWrap } from "./ChartWrap-CV7EbEsG.mjs";
import { t as MonthSwitcher } from "./MonthSwitcher-BIFoaZsj.mjs";
import { t as TransactionRow } from "./TransactionRow-BLexd0Ry.mjs";
import { t as Segmented } from "./Segmented-B8LgG8ZS.mjs";
import { i as XAxis, l as ResponsiveContainer, o as Bar, r as BarChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-BjE1aFht.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Tip({ active, payload }) {
	if (!active || !payload?.[0]) return null;
	const p = payload[0].payload;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-primary-dark px-3 py-2 text-xs text-white",
		dir: "rtl",
		children: [
			"روز ",
			toFaDigits(p.day),
			" · ",
			toFaDigits(Math.round(p.value).toLocaleString("fa-IR"))
		]
	});
}
function BarTrend({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			margin: {
				top: 8,
				right: 4,
				left: 4,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "day",
					tickFormatter: (v) => toFaDigits(v),
					tick: {
						fontSize: 10,
						fill: "var(--app-muted)",
						fontFamily: "inherit"
					},
					axisLine: false,
					tickLine: false,
					interval: 4
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}),
					cursor: { fill: "var(--app-primary-soft)" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: "value",
					fill: "var(--app-accent)",
					radius: [
						6,
						6,
						2,
						2
					],
					maxBarSize: 10
				})
			]
		})
	}) });
}
function AddTransactionSheet({ open, onClose, categories, onSubmit }) {
	const [type, setType] = (0, import_react.useState)("expense");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [merchant, setMerchant] = (0, import_react.useState)("");
	const [categoryId, setCategoryId] = (0, import_react.useState)("food");
	const today = isoDate(/* @__PURE__ */ new Date());
	const [date, setDate] = (0, import_react.useState)(today);
	const cats = (0, import_react.useMemo)(() => categories.filter((c) => c.type === type && !c.parentId), [categories, type]);
	function submit() {
		const n = Number(amount);
		if (!n || !title.trim()) return;
		onSubmit({
			amount: n,
			type,
			categoryId,
			title: title.trim(),
			merchant: merchant.trim() || title.trim(),
			date
		});
		setAmount("");
		setTitle("");
		setMerchant("");
		onClose();
	}
	const { jy, jm, jd } = toJalali(date);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onClose,
		title: "تراکنش جدید",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
					value: type,
					onChange: setType,
					options: [{
						value: "expense",
						label: "هزینه"
					}, {
						value: "income",
						label: "درآمد"
					}]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmountField, {
					value: amount,
					onChange: setAmount
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					value: title,
					onChange: setTitle,
					label: "عنوان",
					placeholder: "مثلاً ناهار کاری"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					value: merchant,
					onChange: setMerchant,
					label: "فروشگاه / مبدأ",
					placeholder: "اختیاری"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium text-muted",
					children: "دسته‌بندی"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: cats.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCategoryId(c.id),
						className: cn("rounded-full px-3 py-2 text-xs font-semibold", categoryId === c.id ? "bg-accent text-white" : "bg-background text-ink"),
						children: c.name
					}, c.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					value: date,
					onChange: setDate,
					label: `تاریخ (میلادی برای ورودی) — ${jy}/${jm}/${jd}`,
					type: "date"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					onClick: submit,
					disabled: !amount || !title.trim(),
					children: "ثبت تراکنش"
				})
			]
		})
	});
}
function HomeScreen() {
	const userName = useFinanceStore((s) => s.userName);
	const transactions = useFinanceStore((s) => s.transactions);
	const categories = useFinanceStore((s) => s.categories);
	const addTransaction = useFinanceStore((s) => s.addTransaction);
	const smsGranted = useFinanceStore((s) => s.smsGranted);
	const [monthKey, setMonthKey] = (0, import_react.useState)(() => jalaliMonthKey(/* @__PURE__ */ new Date()));
	const [openAdd, setOpenAdd] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const { jy, jm } = parseMonthKey(monthKey);
	const { days } = monthRange(jy, jm);
	const { list, income, expense, net } = (0, import_react.useMemo)(() => monthTotals(transactions, monthKey), [transactions, monthKey]);
	const bars = (0, import_react.useMemo)(() => {
		const { start } = monthRange(jy, jm);
		return Array.from({ length: days }, (_, i) => {
			const d = new Date(start);
			d.setDate(start.getDate() + i);
			const key = isoDate(d);
			const value = list.filter((t) => t.date === key && t.type === "expense").reduce((s, t) => s + t.amount, 0);
			return {
				day: i + 1,
				value
			};
		});
	}, [
		days,
		jy,
		jm,
		list
	]);
	const recent = list.slice().sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);
	const selectedTx = transactions.find((t) => t.id === selected);
	const firstName = userName.split(" ")[0] ?? userName;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in px-4 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: formatJalali(/* @__PURE__ */ new Date(), { weekday: true })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "text-xl font-bold",
					children: ["سلام، ", firstName]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/app/search",
						className: "flex size-11 items-center justify-center rounded-2xl bg-card card-shadow",
						"aria-label": "جستجو",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-2xl bg-card card-shadow",
						"aria-label": "اعلان‌ها",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" })
					})]
				})]
			}),
			smsGranted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 rounded-2xl bg-primary-soft px-3 py-2 text-xs text-primary",
				children: [toFaDigits(12), " پیامک بانکی خوانده شد و به تراکنش‌ها اضافه گردید."]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthSwitcher, {
					monthKey,
					onChange: setMonthKey
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4 bg-primary-dark p-5 text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-white/70",
						children: "مانده این ماه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-3xl font-bold tabular",
						children: formatToman(net)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-white/10 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-1 text-[11px] text-white/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3.5 text-success" }), " درآمد"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-bold tabular text-white",
								children: formatCompact(income)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-white/10 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-1 text-[11px] text-white/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "size-3.5 text-accent" }), " هزینه"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-bold tabular text-white",
								children: formatCompact(expense)
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold",
						children: "روند روزانه هزینه"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted",
						children: [toFaDigits(days), " روز"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BarTrend, { data: bars })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-bold",
					children: "آخرین تراکنش‌ها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/app/search",
						className: "text-xs font-semibold text-accent",
						children: "همه"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpenAdd(true),
						className: "flex size-9 items-center justify-center rounded-xl bg-accent text-white",
						"aria-label": "تراکنش جدید",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mt-2 space-y-1",
				children: recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted",
					children: "برای این ماه تراکنشی نیست"
				}) : recent.map((tx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionRow, {
					tx,
					categories,
					onClick: () => setSelected(tx.id)
				}, tx.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddTransactionSheet, {
				open: openAdd,
				onClose: () => setOpenAdd(false),
				categories,
				onSubmit: (payload) => addTransaction({
					...payload,
					source: "manual"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!selectedTx,
				onClose: () => setSelected(null),
				title: selectedTx?.title,
				children: selectedTx ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: selectedTx.type === "income" ? "text-2xl font-bold text-success" : "text-2xl font-bold text-danger",
							children: [selectedTx.type === "income" ? "+" : "−", formatToman(selectedTx.amount)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: selectedTx.merchant
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatJalali(selectedTx.date, { weekday: true }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: ["منبع: ", selectedTx.source === "sms" ? "پیامک بانکی" : "ثبت دستی"]
						}),
						selectedTx.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: selectedTx.note }) : null
					]
				}) : null
			})
		]
	});
}
var SplitComponent = HomeScreen;
//#endregion
export { SplitComponent as component };
