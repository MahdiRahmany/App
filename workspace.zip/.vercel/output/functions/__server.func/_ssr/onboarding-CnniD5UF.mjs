import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { A as Fingerprint, C as LockKeyhole, S as MessageSquareText, V as Check, W as Bell, m as ShieldCheck } from "../_libs/lucide-react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { l as toFaDigits } from "./format-4ArJapjy.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { n as PhoneFrame, t as Logo } from "./PhoneFrame-B1JbcYEA.mjs";
import { n as PinPad, t as PinDots } from "./PinPad-DqvaHiH0.mjs";
import { t as Switch } from "./Switch-Nt3W2yyJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboarding-CnniD5UF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BENEFITS = [
	"دسته‌بندی خودکار تراکنش‌ها",
	"گزارش‌های ماهانه و بودجه هوشمند",
	"یادآور سررسید چک و قسط",
	"پشتیبان‌گیری آفلاین روی خود گوشی"
];
function OnboardingFlow() {
	const navigate = useNavigate();
	const complete = useFinanceStore((s) => s.completeOnboarding);
	const [step, setStep] = (0, import_react.useState)(0);
	const [sms, setSms] = (0, import_react.useState)(false);
	const [pin, setPin] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [phase, setPhase] = (0, import_react.useState)("set");
	const [biometric, setBiometric] = (0, import_react.useState)(true);
	const [daily, setDaily] = (0, import_react.useState)(true);
	const [weekly, setWeekly] = (0, import_react.useState)(false);
	const [hour, setHour] = (0, import_react.useState)("21:00");
	const [pinError, setPinError] = (0, import_react.useState)("");
	function finish() {
		const [h, m] = hour.split(":").map(Number);
		complete({
			pin: pin.length === 4 ? pin : null,
			biometric,
			reminders: {
				daily,
				weekly,
				hour: h ?? 21,
				minute: m ?? 0
			},
			smsGranted: sms
		});
		navigate({ to: "/app" });
	}
	function onDigit(d) {
		setPinError("");
		if (phase === "set") {
			const next = (pin + d).slice(0, 4);
			setPin(next);
			if (next.length === 4) setPhase("confirm");
		} else {
			const next = (confirm + d).slice(0, 4);
			setConfirm(next);
			if (next.length === 4) {
				if (next !== pin) {
					setPinError("رمزها یکی نیستند. دوباره وارد کن.");
					setPin("");
					setConfirm("");
					setPhase("set");
				}
			}
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-svh flex-col px-6 pb-8 pt-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1.5",
					children: [
						0,
						1,
						2,
						3
					].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 w-6 rounded-full", i <= step ? "bg-accent" : "bg-line") }, i))
				})]
			}),
			step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col fade-in",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-4 flex size-24 items-center justify-center rounded-3xl bg-accent-soft text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquareText, {
							className: "size-12",
							strokeWidth: 1.6
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-8 text-2xl font-bold leading-snug",
						children: "خواندن پیامک‌های بانکی"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-7 text-muted",
						children: "حسابینو می‌تواند پیامک واریز و برداشت بانک را بخواند و تراکنش را خودکار ثبت کند. این دسترسی فقط روی خود گوشی می‌ماند و جایی ارسال نمی‌شود."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-3 text-sm",
						children: [
							"تشخیص مبلغ، کارت و فروشگاه از متن پیامک",
							"بدون نیاز به اتصال اینترنت",
							"هر زمان از تنظیمات قابل قطع است"
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t })]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto space-y-3 pt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: () => {
								setSms(true);
								setStep(1);
							},
							children: "اجازه دسترسی به پیامک"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "w-full",
							onClick: () => setStep(1),
							children: "بعداً، ثبت دستی می‌کنم"
						})]
					})
				]
			}),
			step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col fade-in",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-2 flex size-20 items-center justify-center rounded-3xl bg-primary-soft text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {
							className: "size-10",
							strokeWidth: 1.6
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 text-2xl font-bold",
						children: "قفل فقط برای خودت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: phase === "set" ? "یک رمز ۴ رقمی انتخاب کن" : "همان رمز را دوباره وارد کن"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinDots, {
							length: 4,
							filled: phase === "set" ? pin.length : confirm.length
						})
					}),
					pinError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-sm text-danger",
						children: pinError
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 h-5" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinPad, {
						onDigit,
						onBackspace: () => {
							if (phase === "set") setPin((p) => p.slice(0, -1));
							else setConfirm((p) => p.slice(0, -1));
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 rounded-2xl bg-card p-4 card-shadow",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "size-6 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									label: "ورود با اثر انگشت",
									description: "در مرورگر به‌صورت شبیه‌سازی‌شده فعال می‌شود",
									checked: biometric,
									onCheckedChange: setBiometric
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto space-y-3 pt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: pin.length !== 4 || confirm !== pin,
							onClick: () => setStep(2),
							children: "ادامه"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "w-full",
							onClick: () => {
								setPin("");
								setConfirm("");
								setStep(2);
							},
							children: "فعلاً بدون رمز"
						})]
					})
				]
			}),
			step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col fade-in",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-4 flex size-20 items-center justify-center rounded-3xl bg-accent-soft text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
							className: "size-10",
							strokeWidth: 1.6
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-6 text-2xl font-bold",
						children: "یادآور"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-7 text-muted",
						children: "یک زنگ کوچک تا دخل‌وخرج از یادت نرود. یادآورها روی همین دستگاه ذخیره می‌شوند."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-4 rounded-2xl bg-card p-4 card-shadow",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								label: "یادآور روزانه",
								description: "ثبت هزینه‌های همان روز",
								checked: daily,
								onCheckedChange: setDaily
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								label: "خلاصه هفتگی",
								description: "جمع‌بندی جمعه‌ها",
								checked: weekly,
								onCheckedChange: setWeekly
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1.5 block text-sm font-medium text-muted",
									children: "ساعت یادآوری"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "time",
									value: hour,
									onChange: (e) => setHour(e.target.value),
									className: "h-12 w-full rounded-2xl bg-background px-4 outline-none ring-1 ring-line"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-auto pt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: () => setStep(3),
							children: "ذخیره و ادامه"
						})
					})
				]
			}),
			step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col fade-in",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-4 flex size-20 items-center justify-center rounded-3xl bg-primary text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
							className: "size-10",
							strokeWidth: 1.6
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 text-sm font-semibold text-accent",
						children: [toFaDigits(31), " روز اشتراک رایگان"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-bold leading-snug",
						children: "همه امکانات، بدون هزینه برای یک ماه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-3",
						children: BENEFITS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-2xl bg-card p-3 card-shadow",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-8 items-center justify-center rounded-xl bg-accent-soft text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-medium",
								children: b
							})]
						}, b))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto space-y-3 pt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: finish,
							children: "شروع دوره آزمایشی"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-center text-xs leading-6 text-muted",
							children: [
								"بعد از ",
								toFaDigits(31),
								" روز می‌توانی ادامه دهی یا با نسخه پایه کار کنی. پرداختی از تو گرفته نمی‌شود."
							]
						})]
					})
				]
			})
		]
	}) });
}
var SplitComponent = OnboardingFlow;
//#endregion
export { SplitComponent as component };
