import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useRouter, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CxVnniVP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "خطای پیش‌بینی‌نشده رخ داد. صفحه را دوباره بارگذاری کن.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-background px-6 text-center text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-danger",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "مشکلی پیش آمد"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var CATEGORIES = [
	{
		id: "food",
		name: "خوراک",
		icon: "utensils",
		color: "var(--color-cat-food)",
		type: "expense"
	},
	{
		id: "food-out",
		name: "رستوران و کافه",
		icon: "coffee",
		color: "var(--color-cat-food)",
		type: "expense",
		parentId: "food"
	},
	{
		id: "transport",
		name: "حمل‌ونقل",
		icon: "car",
		color: "var(--color-cat-transport)",
		type: "expense"
	},
	{
		id: "bills",
		name: "قبض",
		icon: "zap",
		color: "var(--color-cat-bills)",
		type: "expense"
	},
	{
		id: "fun",
		name: "تفریح",
		icon: "clapper",
		color: "var(--color-cat-fun)",
		type: "expense"
	},
	{
		id: "health",
		name: "سلامت",
		icon: "heart",
		color: "var(--color-cat-health)",
		type: "expense"
	},
	{
		id: "shop",
		name: "خرید",
		icon: "bag",
		color: "var(--color-cat-shop)",
		type: "expense"
	},
	{
		id: "home",
		name: "مسکن",
		icon: "home",
		color: "var(--color-cat-home)",
		type: "expense"
	},
	{
		id: "edu",
		name: "آموزش",
		icon: "edu",
		color: "var(--color-cat-edu)",
		type: "expense"
	},
	{
		id: "other",
		name: "سایر",
		icon: "dots",
		color: "var(--color-cat-other)",
		type: "expense"
	},
	{
		id: "salary",
		name: "حقوق",
		icon: "banknote",
		color: "var(--color-success)",
		type: "income"
	},
	{
		id: "invest",
		name: "سود و سرمایه‌گذاری",
		icon: "trend",
		color: "var(--color-success)",
		type: "income"
	},
	{
		id: "transfer-in",
		name: "دریافتی",
		icon: "in",
		color: "var(--color-success)",
		type: "income"
	}
];
function tx(id, amount, type, categoryId, title, merchant, date, source = "sms", note) {
	return {
		id,
		amount,
		type,
		categoryId,
		title,
		merchant,
		date,
		source,
		note
	};
}
var TRANSACTIONS = [
	tx("t1", 485e5, "income", "salary", "حقوق مهر", "شرکت آریا نرم‌افزار", "2026-09-23", "manual"),
	tx("t2", 287e3, "expense", "food-out", "ناهار کاری", "اسنپ‌فود", "2026-09-23"),
	tx("t3", 96e3, "expense", "transport", "سفر تا محل کار", "تپسی", "2026-09-23"),
	tx("t4", 185e4, "expense", "food", "خرید هفته", "هایپراستار سعادت‌آباد", "2026-09-24"),
	tx("t5", 12e4, "expense", "bills", "بسته اینترنت", "ایرانسل", "2026-09-24"),
	tx("t6", 195e3, "expense", "food-out", "قهوه بعدازظهر", "کافه لمیز", "2026-09-24", "manual"),
	tx("t7", 45e4, "expense", "transport", "بنزین", "پمپ بنزین تهرانپارس", "2026-09-25"),
	tx("t8", 34e4, "expense", "health", "دارو و ویتامین", "داروخانه ۱۳ آبان", "2026-09-25"),
	tx("t9", 85e3, "expense", "food", "نان تازه", "نانوایی سنگکی محله", "2026-09-25", "manual"),
	tx("t10", 18e6, "expense", "home", "اجاره شهریور", "مالک آپارتمان", "2026-08-23", "manual"),
	tx("t11", 472e5, "income", "salary", "حقوق شهریور", "شرکت آریا نرم‌افزار", "2026-08-23", "manual"),
	tx("t12", 235e4, "expense", "shop", "هدفون و لوازم", "دیجی‌کالا", "2026-08-25"),
	tx("t13", 12e5, "expense", "food-out", "شام خانوادگی", "رستوران شاندیز", "2026-08-26", "manual"),
	tx("t14", 64e4, "expense", "bills", "قبض برق", "توانیر", "2026-08-27"),
	tx("t15", 21e4, "expense", "bills", "قبض گاز", "شرکت گاز", "2026-08-27"),
	tx("t16", 22e5, "expense", "edu", "شهریه کلاس زبان", "آموزشگاه ایرانمهر", "2026-08-28", "manual"),
	tx("t17", 24e4, "expense", "fun", "بلیط سینما", "سینما ایران‌مال", "2026-08-29"),
	tx("t18", 78e3, "expense", "transport", "ارسال بسته", "اسنپ‌باکس", "2026-08-30"),
	tx("t19", 41e4, "expense", "shop", "شوینده و بهداشتی", "فروشگاه گلرنگ", "2026-09-01"),
	tx("t20", 312e3, "expense", "food-out", "ناهار", "اسنپ‌فود", "2026-09-02"),
	tx("t21", 54e3, "expense", "transport", "شارژ مترو", "کارت بلیت مترو", "2026-09-03", "manual"),
	tx("t22", 164e4, "expense", "food", "خرید میوه و تره‌بار", "بازار تجریش", "2026-09-05", "manual"),
	tx("t23", 89e3, "expense", "transport", "اسنپ تا میدان ولیعصر", "اسنپ", "2026-09-06"),
	tx("t24", 32e4, "income", "invest", "سود سپرده کوتاه‌مدت", "بانک ملت", "2026-09-07"),
	tx("t25", 175e3, "expense", "fun", "اشتراک فیلیمو", "فیلیمو", "2026-09-08"),
	tx("t26", 98e4, "expense", "health", "ویزیت دندانپزشکی", "کلینیک دندان مهر", "2026-09-10", "manual"),
	tx("t27", 265e3, "expense", "food-out", "کافه با دوستان", "کافه نادری", "2026-09-12"),
	tx("t28", 38e5, "expense", "shop", "کفش و لباس پاییزه", "فروشگاه جین وست", "2026-09-14"),
	tx("t29", 155e3, "expense", "bills", "قبض آب", "آبفا تهران", "2026-09-16"),
	tx("t30", 5e5, "income", "transfer-in", "برگشت هزینه سفر", "علی رضایی", "2026-09-18", "manual"),
	tx("t31", 118e3, "expense", "transport", "تپسی شب", "تپسی", "2026-09-19"),
	tx("t32", 72e4, "expense", "food", "سوپرمارکت", "افق کوروش", "2026-09-20"),
	tx("t33", 95e3, "expense", "other", "کارمزد کارت به کارت", "بانک پاسارگاد", "2026-09-21"),
	tx("t34", 18e6, "expense", "home", "اجاره مرداد", "مالک آپارتمان", "2026-07-23", "manual"),
	tx("t35", 468e5, "income", "salary", "حقوق مرداد", "شرکت آریا نرم‌افزار", "2026-07-23", "manual"),
	tx("t36", 142e4, "expense", "food", "خرید ماهانه", "هایپراستار", "2026-07-26"),
	tx("t37", 29e5, "expense", "fun", "سفر یک‌روزه شمال", "رستوران رامسر", "2026-08-01", "manual"),
	tx("t38", 43e4, "expense", "transport", "بنزین جاده", "جایگاه قم", "2026-08-01"),
	tx("t39", 56e4, "expense", "bills", "قبض برق مرداد", "توانیر", "2026-08-08"),
	tx("t40", 198e3, "expense", "food-out", "اسنپ‌فود", "اسنپ‌فود", "2026-08-12"),
	tx("t41", 11e5, "expense", "shop", "کتاب و لوازم تحریر", "شهر کتاب", "2026-08-15", "manual"),
	tx("t42", 25e4, "income", "invest", "سود صندوق درآمد ثابت", "کارگزاری مفید", "2026-08-18")
];
var BUDGETS = [
	{
		id: "b1",
		categoryId: "food",
		amount: 8e6
	},
	{
		id: "b2",
		categoryId: "transport",
		amount: 25e5
	},
	{
		id: "b3",
		categoryId: "bills",
		amount: 2e6
	},
	{
		id: "b4",
		categoryId: "fun",
		amount: 15e5
	},
	{
		id: "b5",
		categoryId: "shop",
		amount: 4e6
	},
	{
		id: "b6",
		categoryId: "health",
		amount: 12e5
	},
	{
		id: "b7",
		categoryId: "home",
		amount: 18e6
	},
	{
		id: "b8",
		categoryId: "edu",
		amount: 25e5
	}
];
function hist(values) {
	return [
		"2026-02-01",
		"2026-03-01",
		"2026-04-01",
		"2026-05-01",
		"2026-06-01",
		"2026-07-01",
		"2026-08-01",
		"2026-09-01"
	].map((date, i) => ({
		date,
		value: values[i] ?? values[values.length - 1]
	}));
}
var ASSETS = [
	{
		id: "a1",
		kind: "gold",
		name: "طلای ۱۸ عیار",
		amount: 25,
		unit: "گرم",
		currentValue: 1285e5,
		changePct: 4.2,
		history: hist([
			98,
			102,
			108,
			112,
			115,
			118,
			123,
			128.5
		].map((n) => n * 1e6))
	},
	{
		id: "a2",
		kind: "gold",
		name: "سکه تمام بهار آزادی",
		amount: 2,
		unit: "عدد",
		currentValue: 152e6,
		changePct: 2.8,
		history: hist([
			132,
			136,
			140,
			143,
			145,
			147,
			149,
			152
		].map((n) => n * 1e6))
	},
	{
		id: "a3",
		kind: "crypto",
		name: "بیت‌کوین",
		amount: .012,
		unit: "BTC",
		currentValue: 864e5,
		changePct: -3.1,
		history: hist([
			74,
			81,
			92,
			88,
			95,
			91,
			89,
			86.4
		].map((n) => n * 1e6))
	},
	{
		id: "a4",
		kind: "crypto",
		name: "تتر",
		amount: 520,
		unit: "USDT",
		currentValue: 494e5,
		changePct: .6,
		history: hist([
			44,
			45.2,
			46,
			46.8,
			47.5,
			48.1,
			48.9,
			49.4
		].map((n) => n * 1e6))
	}
];
var LOANS = [
	{
		id: "l1",
		name: "وام مسکن",
		kind: "payable",
		total: 85e7,
		remaining: 412e6,
		installment: 84e5,
		dueDate: "2026-09-27",
		status: "on-time",
		bank: "بانک مسکن"
	},
	{
		id: "l2",
		name: "قسط گوشی",
		kind: "payable",
		total: 24e6,
		remaining: 8e6,
		installment: 2e6,
		dueDate: "2026-10-03",
		status: "on-time",
		bank: "دیجی‌پی"
	},
	{
		id: "l3",
		name: "قسط خودرو",
		kind: "payable",
		total: 18e7,
		remaining: 54e6,
		installment: 6e6,
		dueDate: "2026-09-20",
		status: "late",
		bank: "بانک سامان"
	},
	{
		id: "l4",
		name: "وام به برادر",
		kind: "receivable",
		total: 3e7,
		remaining: 12e6,
		installment: 3e6,
		dueDate: "2026-10-01",
		status: "on-time"
	}
];
var PEOPLE = [
	{
		id: "p1",
		name: "علی رضایی",
		initials: "ع‌ر",
		color: "#4A6FA5",
		balance: 25e5,
		history: [{
			id: "ph1",
			amount: 3e6,
			date: "2026-08-02",
			note: "قرض سفر شمال"
		}, {
			id: "ph2",
			amount: -5e5,
			date: "2026-09-18",
			note: "بازپرداخت جزئی"
		}]
	},
	{
		id: "p2",
		name: "مریم حسینی",
		initials: "م‌ح",
		color: "#C45C4A",
		balance: -8e5,
		history: [{
			id: "ph3",
			amount: -8e5,
			date: "2026-09-10",
			note: "سهم شام تولد"
		}]
	},
	{
		id: "p3",
		name: "حسین کریمی",
		initials: "ح‌ک",
		color: "#2A9D8F",
		balance: 52e5,
		history: [{
			id: "ph4",
			amount: 52e5,
			date: "2026-07-15",
			note: "هزینه پروژه مشترک"
		}]
	},
	{
		id: "p4",
		name: "نرگس احمدی",
		initials: "ن‌ا",
		color: "#6C63B0",
		balance: -14e5,
		history: [{
			id: "ph5",
			amount: -2e6,
			date: "2026-08-20",
			note: "قرض برای تعمیر ماشین"
		}, {
			id: "ph6",
			amount: 6e5,
			date: "2026-09-05",
			note: "بازپرداخت اول"
		}]
	}
];
var CHECKS = [
	{
		id: "c1",
		title: "اجاره مغازه همکار",
		amount: 15e6,
		dueDate: "2026-10-07",
		kind: "payable",
		bank: "بانک ملت",
		status: "upcoming"
	},
	{
		id: "c2",
		title: "چک مشتری پروژه وب",
		amount: 85e5,
		dueDate: "2026-09-28",
		kind: "receivable",
		bank: "بانک صادرات",
		status: "due"
	},
	{
		id: "c3",
		title: "چک فروشگاه لوازم",
		amount: 42e5,
		dueDate: "2026-09-23",
		kind: "payable",
		bank: "بانک پارسیان",
		status: "overdue"
	},
	{
		id: "c4",
		title: "چک دریافتی قرارداد",
		amount: 22e6,
		dueDate: "2026-10-23",
		kind: "receivable",
		bank: "بانک تجارت",
		status: "upcoming"
	}
];
function createSeed() {
	return {
		onboarded: false,
		pin: null,
		biometric: false,
		reminders: {
			daily: true,
			weekly: false,
			hour: 21,
			minute: 0
		},
		trialStartedAt: null,
		smsGranted: false,
		darkMode: false,
		userName: "سارا محمدی",
		categories: CATEGORIES,
		transactions: TRANSACTIONS,
		budgets: BUDGETS,
		assets: ASSETS,
		loans: LOANS,
		people: PEOPLE,
		checks: CHECKS
	};
}
var G_DAYS = [
	0,
	31,
	59,
	90,
	120,
	151,
	181,
	212,
	243,
	273,
	304,
	334
];
function toJalali(date) {
	const d = typeof date === "string" ? /* @__PURE__ */ new Date(date + (date.length === 10 ? "T12:00:00" : "")) : date;
	const gy = d.getFullYear();
	const gm = d.getMonth() + 1;
	const gd = d.getDate();
	const gy2 = gm > 2 ? gy + 1 : gy;
	let days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + G_DAYS[gm - 1];
	let jy = -1595 + 33 * Math.floor(days / 12053);
	days %= 12053;
	jy += 4 * Math.floor(days / 1461);
	days %= 1461;
	if (days > 365) {
		jy += Math.floor((days - 1) / 365);
		days = (days - 1) % 365;
	}
	const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
	const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
	return {
		jy,
		jm,
		jd
	};
}
function jalaliToGregorian(jy, jm, jd) {
	let jy2 = jy + 1595;
	let days = -355668 + 365 * jy2 + Math.floor(jy2 / 33) * 8 + Math.floor((jy2 % 33 + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
	let gy = 400 * Math.floor(days / 146097);
	days %= 146097;
	if (days > 36524) {
		gy += 100 * Math.floor(--days / 36524);
		days %= 36524;
		if (days >= 365) days++;
	}
	gy += 4 * Math.floor(days / 1461);
	days %= 1461;
	if (days > 365) {
		gy += Math.floor((days - 1) / 365);
		days = (days - 1) % 365;
	}
	let gd = days + 1;
	const sal_a = [
		0,
		31,
		gy % 4 === 0 && gy % 100 !== 0 || gy % 400 === 0 ? 29 : 28,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	];
	let gm = 0;
	for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
	return new Date(gy, gm - 1, gd, 12, 0, 0);
}
var JALALI_MONTHS = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند"
];
var WEEKDAYS = [
	"یکشنبه",
	"دوشنبه",
	"سه‌شنبه",
	"چهارشنبه",
	"پنجشنبه",
	"جمعه",
	"شنبه"
];
function jalaliMonthKey(input) {
	const { jy, jm } = toJalali(input);
	return `${jy}-${String(jm).padStart(2, "0")}`;
}
function daysInJalaliMonth(jy, jm) {
	if (jm <= 6) return 31;
	if (jm <= 11) return 30;
	const yp = ((jy - 474) % 2820 + 2820) % 2820 % 33;
	return yp === 1 || yp === 5 || yp === 9 || yp === 13 || yp === 17 || yp === 22 || yp === 26 || yp === 30 ? 30 : 29;
}
function monthRange(jy, jm) {
	const days = jm <= 6 ? 31 : jm <= 11 ? 30 : daysInJalaliMonth(jy, jm);
	return {
		start: jalaliToGregorian(jy, jm, 1),
		end: jalaliToGregorian(jy, jm, days),
		days
	};
}
function addJalaliMonth(jy, jm, delta) {
	let m = jm + delta;
	let y = jy;
	while (m < 1) {
		m += 12;
		y -= 1;
	}
	while (m > 12) {
		m -= 12;
		y += 1;
	}
	return {
		jy: y,
		jm: m
	};
}
function isoDate(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function parseMonthKey(key) {
	const [jy, jm] = key.split("-").map(Number);
	return {
		jy: jy ?? 1405,
		jm: jm ?? 1
	};
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}
var seed = createSeed();
var useFinanceStore = create()(persist((set, get) => ({
	...seed,
	hydrated: false,
	unlocked: false,
	markHydrated: () => set({ hydrated: true }),
	completeOnboarding: ({ pin, biometric, reminders, smsGranted }) => set({
		onboarded: true,
		pin,
		biometric,
		reminders,
		smsGranted,
		trialStartedAt: (/* @__PURE__ */ new Date()).toISOString(),
		unlocked: true
	}),
	unlockWithPin: (pin) => {
		if (get().pin && pin === get().pin) {
			set({ unlocked: true });
			return true;
		}
		return false;
	},
	unlockBiometric: () => {
		if (!get().biometric) return false;
		set({ unlocked: true });
		return true;
	},
	lock: () => set({ unlocked: false }),
	setDarkMode: (darkMode) => set({ darkMode }),
	addTransaction: (tx) => set({ transactions: [{
		...tx,
		id: uid("t")
	}, ...get().transactions] }),
	removeTransaction: (id) => set({ transactions: get().transactions.filter((t) => t.id !== id) }),
	addBudget: (categoryId, amount) => set({ budgets: [...get().budgets.filter((b) => b.categoryId !== categoryId), {
		id: uid("b"),
		categoryId,
		amount
	}] }),
	updateBudget: (id, amount) => set({ budgets: get().budgets.map((b) => b.id === id ? {
		...b,
		amount
	} : b) }),
	removeBudget: (id) => set({ budgets: get().budgets.filter((b) => b.id !== id) }),
	addCategory: (cat) => set({ categories: [...get().categories, {
		...cat,
		id: uid("cat")
	}] }),
	updateCategory: (id, patch) => set({ categories: get().categories.map((c) => c.id === id ? {
		...c,
		...patch
	} : c) }),
	removeCategory: (id) => set({
		categories: get().categories.filter((c) => c.id !== id && c.parentId !== id),
		budgets: get().budgets.filter((b) => b.categoryId !== id)
	}),
	settlePerson: (personId, amount, note) => set({ people: get().people.map((p) => {
		if (p.id !== personId) return p;
		return {
			...p,
			balance: p.balance + amount,
			history: [{
				id: uid("ph"),
				amount,
				date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
				note
			}, ...p.history]
		};
	}) }),
	addPerson: (name) => {
		const initials = name.trim().split(/\s+/).map((p) => p[0] ?? "").join("").slice(0, 2);
		set({ people: [...get().people, {
			id: uid("p"),
			name,
			initials: initials || "؟",
			color: "#5c548c",
			balance: 0,
			history: []
		}] });
	},
	markCheckDone: (id) => set({ checks: get().checks.map((c) => c.id === id ? {
		...c,
		status: "done"
	} : c) }),
	importSnapshot: (data) => set({
		...data,
		hydrated: true,
		unlocked: true
	}),
	exportSnapshot: () => {
		const s = get();
		return {
			onboarded: s.onboarded,
			pin: s.pin,
			biometric: s.biometric,
			reminders: s.reminders,
			trialStartedAt: s.trialStartedAt,
			smsGranted: s.smsGranted,
			darkMode: s.darkMode,
			userName: s.userName,
			categories: s.categories,
			transactions: s.transactions,
			budgets: s.budgets,
			assets: s.assets,
			loans: s.loans,
			people: s.people,
			checks: s.checks
		};
	},
	resetDemo: () => set({
		...createSeed(),
		onboarded: true,
		pin: get().pin,
		biometric: get().biometric,
		reminders: get().reminders,
		trialStartedAt: get().trialStartedAt,
		smsGranted: get().smsGranted,
		hydrated: true,
		unlocked: true
	})
}), {
	name: "hesabino-v1",
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	partialize: (state) => ({
		onboarded: state.onboarded,
		pin: state.pin,
		biometric: state.biometric,
		reminders: state.reminders,
		trialStartedAt: state.trialStartedAt,
		smsGranted: state.smsGranted,
		darkMode: state.darkMode,
		userName: state.userName,
		categories: state.categories,
		transactions: state.transactions,
		budgets: state.budgets,
		assets: state.assets,
		loans: state.loans,
		people: state.people,
		checks: state.checks
	}),
	skipHydration: true,
	onRehydrateStorage: () => (state) => {
		state?.markHydrated();
	}
}));
function categoryById(id, list) {
	return list.find((c) => c.id === id);
}
function parentCategoryId(id, list) {
	return list.find((c) => c.id === id)?.parentId ?? id;
}
function spentInMonth(transactions, categories, monthKey, categoryId) {
	return transactions.filter((t) => t.type === "expense" && jalaliMonthKey(t.date) === monthKey).filter((t) => parentCategoryId(t.categoryId, categories) === categoryId || t.categoryId === categoryId).reduce((s, t) => s + t.amount, 0);
}
function monthTotals(transactions, monthKey) {
	const list = transactions.filter((t) => jalaliMonthKey(t.date) === monthKey);
	const income = list.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
	const expense = list.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
	return {
		list,
		income,
		expense,
		net: income - expense
	};
}
function expenseByCategory(transactions, categories, monthKey, type = "expense") {
	const list = transactions.filter((t) => {
		if (t.type !== type) return false;
		if (monthKey !== "all" && jalaliMonthKey(t.date) !== monthKey) return false;
		return true;
	});
	const map = /* @__PURE__ */ new Map();
	for (const t of list) {
		const id = parentCategoryId(t.categoryId, categories);
		map.set(id, (map.get(id) ?? 0) + t.amount);
	}
	return [...map.entries()].map(([id, amount]) => ({
		category: categories.find((c) => c.id === id),
		amount
	})).filter((x) => x.category).sort((a, b) => b.amount - a.amount);
}
function StoreHydrator() {
	(0, import_react.useEffect)(() => {
		const unsub = useFinanceStore.persist.onFinishHydration(() => {
			useFinanceStore.getState().markHydrated();
		});
		useFinanceStore.persist.rehydrate();
		const t = window.setTimeout(() => {
			if (!useFinanceStore.getState().hydrated) useFinanceStore.getState().markHydrated();
		}, 600);
		return () => {
			unsub();
			window.clearTimeout(t);
		};
	}, []);
	return null;
}
var styles_default = "/assets/styles-qZsZQEP2.css";
var APP_NAME = "حسابینو";
var Route$18 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#1B1447"
			},
			{
				name: "description",
				content: "مدیریت مالی شخصی فارسی — دخل‌وخرج، بودجه و دارایی‌ها، کاملاً آفلاین"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fa",
		dir: "rtl",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreHydrator, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$17 = () => import("./routes-C4kbSfs1.mjs");
var Route$17 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("./app-gyBVgeNv.mjs");
var Route$16 = createFileRoute("/app")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./lock-BxZFf00o.mjs");
var Route$15 = createFileRoute("/lock")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./onboarding-CnniD5UF.mjs");
var Route$14 = createFileRoute("/onboarding")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./app-BjE1aFht.mjs");
var Route$13 = createFileRoute("/app/")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./assets-CuyJ4J3A.mjs");
var Route$12 = createFileRoute("/app/assets")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./budget-Bwuft03z.mjs");
var Route$11 = createFileRoute("/app/budget")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./checks-Dl9yi7WR.mjs");
var Route$10 = createFileRoute("/app/checks")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./loans-DBArUAW4.mjs");
var Route$9 = createFileRoute("/app/loans")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./people-Byav2tRR.mjs");
var Route$8 = createFileRoute("/app/people")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./reports-iHDoi2IG.mjs");
var Route$7 = createFileRoute("/app/reports")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./search-D9C66z3x.mjs");
var Route$6 = createFileRoute("/app/search")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./settings-DhLS7v1R.mjs");
var Route$5 = createFileRoute("/app/settings")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./people-D4dOtb1B.mjs");
var Route$4 = createFileRoute("/app/people/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("../_personId-8qApAg7m.mjs");
var Route$3 = createFileRoute("/app/people/$personId")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./settings-rtbONvV3.mjs");
var Route$2 = createFileRoute("/app/settings/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./backup-BbBXZENa.mjs");
var Route$1 = createFileRoute("/app/settings/backup")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./categories-DV6LhWXB.mjs");
var Route = createFileRoute("/app/settings/categories")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$17.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$18
});
var AppRoute = Route$16.update({
	id: "/app",
	path: "/app",
	getParentRoute: () => Route$18
});
var LockRoute = Route$15.update({
	id: "/lock",
	path: "/lock",
	getParentRoute: () => Route$18
});
var OnboardingRoute = Route$14.update({
	id: "/onboarding",
	path: "/onboarding",
	getParentRoute: () => Route$18
});
var AppIndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => AppRoute
});
var AppAssetsRoute = Route$12.update({
	id: "/assets",
	path: "/assets",
	getParentRoute: () => AppRoute
});
var AppBudgetRoute = Route$11.update({
	id: "/budget",
	path: "/budget",
	getParentRoute: () => AppRoute
});
var AppChecksRoute = Route$10.update({
	id: "/checks",
	path: "/checks",
	getParentRoute: () => AppRoute
});
var AppLoansRoute = Route$9.update({
	id: "/loans",
	path: "/loans",
	getParentRoute: () => AppRoute
});
var AppPeopleRoute = Route$8.update({
	id: "/people",
	path: "/people",
	getParentRoute: () => AppRoute
});
var AppReportsRoute = Route$7.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AppRoute
});
var AppSearchRoute = Route$6.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => AppRoute
});
var AppSettingsRoute = Route$5.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AppRoute
});
var AppPeopleIndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => AppPeopleRoute
});
var AppPeoplePersonIdRoute = Route$3.update({
	id: "/$personId",
	path: "/$personId",
	getParentRoute: () => AppPeopleRoute
});
var AppSettingsIndexRoute = Route$2.update({
	id: "/",
	path: "/",
	getParentRoute: () => AppSettingsRoute
});
var AppSettingsBackupRoute = Route$1.update({
	id: "/backup",
	path: "/backup",
	getParentRoute: () => AppSettingsRoute
});
var AppSettingsCategoriesRoute = Route.update({
	id: "/categories",
	path: "/categories",
	getParentRoute: () => AppSettingsRoute
});
var AppPeopleRouteChildren = {
	AppPeoplePersonIdRoute,
	AppPeopleIndexRoute
};
var AppPeopleRouteWithChildren = AppPeopleRoute._addFileChildren(AppPeopleRouteChildren);
var AppSettingsRouteChildren = {
	AppSettingsBackupRoute,
	AppSettingsCategoriesRoute,
	AppSettingsIndexRoute
};
var AppRouteChildren = {
	AppAssetsRoute,
	AppBudgetRoute,
	AppChecksRoute,
	AppLoansRoute,
	AppPeopleRoute: AppPeopleRouteWithChildren,
	AppReportsRoute,
	AppSearchRoute,
	AppSettingsRoute: AppSettingsRoute._addFileChildren(AppSettingsRouteChildren),
	AppIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AppRoute: AppRoute._addFileChildren(AppRouteChildren),
	LockRoute,
	OnboardingRoute
};
var routeTree = Route$18._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { spentInMonth as a, WEEKDAYS as c, jalaliMonthKey as d, monthRange as f, monthTotals as i, addJalaliMonth as l, toJalali as m, categoryById as n, useFinanceStore as o, parseMonthKey as p, expenseByCategory as r, JALALI_MONTHS as s, router_exports as t, isoDate as u };
