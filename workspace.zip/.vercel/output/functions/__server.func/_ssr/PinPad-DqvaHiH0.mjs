import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { P as Delete } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { l as toFaDigits } from "./format-4ArJapjy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PinPad-DqvaHiH0.js
var import_jsx_runtime = require_jsx_runtime();
function PinDots({ length, filled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex justify-center gap-3",
		dir: "ltr",
		children: Array.from({ length }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-3.5 rounded-full transition-colors", i < filled ? "bg-accent" : "bg-line") }, i))
	});
}
function PinPad({ onDigit, onBackspace }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto grid w-full max-w-xs grid-cols-3 gap-3",
		dir: "ltr",
		children: [
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"",
			"0",
			"back"
		].map((k, i) => {
			if (k === "") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}, i);
			if (k === "back") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBackspace,
				"aria-label": "پاک کردن",
				className: "flex h-16 items-center justify-center rounded-full text-ink transition-colors hover:bg-primary-soft",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, { className: "size-6" })
			}, k);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onDigit(k),
				className: "flex h-16 items-center justify-center rounded-full bg-card text-2xl font-bold card-shadow transition-transform active:scale-95",
				children: toFaDigits(k)
			}, k);
		})
	});
}
//#endregion
export { PinPad as n, PinDots as t };
