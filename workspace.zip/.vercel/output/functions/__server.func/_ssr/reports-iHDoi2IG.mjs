import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Smartphone, u as Sun, x as Moon } from "../_libs/lucide-react.mjs";
import { d as jalaliMonthKey, i as monthTotals, o as useFinanceStore, r as expenseByCategory, u as isoDate } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { l as toFaDigits, o as formatToman, t as formatCompact } from "./format-4ArJapjy.mjs";
import { t as ChartWrap } from "./ChartWrap-CV7EbEsG.mjs";
import { t as CategoryGlyph } from "./icons-BQjgpZV9.mjs";
import { t as Segmented } from "./Segmented-B8LgG8ZS.mjs";
import { c as Cell, l as ResponsiveContainer, n as PieChart, s as Pie } from "../_libs/recharts+[...].mjs";
import { t as ProgressBar } from "./ProgressBar-DapDGsKS.mjs";
import { t as Switch } from "./Switch-Nt3W2yyJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-iHDoi2IG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DonutChart({ data, center }) {
	const total = data.reduce((s, d) => s + d.value, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ChartWrap, {
		className: "relative h-52",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
				data,
				dataKey: "value",
				nameKey: "name",
				innerRadius: 62,
				outerRadius: 88,
				paddingAngle: 2,
				stroke: "none",
				children: data.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: d.color }, d.name))
			}) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 flex flex-col items-center justify-center",
			dir: "rtl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted",
					children: "مجموع هزینه"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-lg font-bold tabular",
					children: formatCompact(total)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] text-muted",
					children: center
				})
			]
		})]
	});
}
function ReportsScreen() {
	const transactions = useFinanceStore((s) => s.transactions);
	const categories = useFinanceStore((s) => s.categories);
	const budgets = useFinanceStore((s) => s.budgets);
	const checks = useFinanceStore((s) => s.checks);
	const darkMode = useFinanceStore((s) => s.darkMode);
	const setDarkMode = useFinanceStore((s) => s.setDarkMode);
	const [mode, setMode] = (0, import_react.useState)("month");
	const todayKey = isoDate(/* @__PURE__ */ new Date());
	const monthKey = jalaliMonthKey(/* @__PURE__ */ new Date());
	const slices = (0, import_react.useMemo)(() => {
		if (mode === "day") {
			const dayTx = transactions.filter((t) => t.date === todayKey && t.type === "expense");
			const map = /* @__PURE__ */ new Map();
			for (const t of dayTx) {
				const id = t.categoryId;
				map.set(id, (map.get(id) ?? 0) + t.amount);
			}
			return [...map.entries()].map(([id, amount]) => {
				const c = categories.find((x) => x.id === id);
				return {
					name: c?.name ?? "سایر",
					value: amount,
					color: c?.color ?? "var(--color-cat-other)",
					icon: c?.icon ?? "dots"
				};
			}).sort((a, b) => b.value - a.value);
		}
		return expenseByCategory(transactions, categories, monthKey).map((x) => ({
			name: x.category.name,
			value: x.amount,
			color: x.category.color,
			icon: x.category.icon
		}));
	}, [
		mode,
		transactions,
		categories,
		todayKey,
		monthKey
	]);
	const totals = monthTotals(transactions, monthKey);
	const todaySpend = transactions.filter((t) => t.date === todayKey && t.type === "expense").reduce((s, t) => s + t.amount, 0);
	const budgetSum = budgets.reduce((s, b) => s + b.amount, 0);
	const remaining = Math.max(0, budgetSum - totals.expense);
	const upcoming = checks.filter((c) => c.status !== "done").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in px-4 pb-6 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-bold",
					children: "گزارش‌ها"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setDarkMode(!darkMode),
					className: "flex size-11 items-center justify-center rounded-2xl bg-card card-shadow",
					"aria-label": "حالت شب",
					children: darkMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5 text-accent" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
					value: mode,
					onChange: setMode,
					options: [{
						value: "day",
						label: "روزانه"
					}, {
						value: "month",
						label: "ماهانه"
					}]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mt-4",
				children: slices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-12 text-center text-sm text-muted",
					children: "در این بازه هزینه‌ای ثبت نشده"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonutChart, {
					data: slices,
					center: mode === "day" ? "امروز" : "این ماه"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 font-bold",
				children: "پرهزینه‌ترین‌ها"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-2 space-y-4",
				children: [slices.slice(0, 6).map((s, i) => {
					const max = slices[0]?.value || 1;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-5 text-xs text-muted",
								children: toFaDigits(i + 1)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-9 items-center justify-center rounded-xl text-white",
								style: { background: s.color },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryGlyph, {
									icon: s.icon,
									className: "size-4"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1 flex justify-between text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: s.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular text-muted",
										children: formatCompact(s.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: s.value / max * 100 })]
							})
						]
					}, s.name);
				}), slices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-6 text-center text-sm text-muted",
					children: "داده‌ای نیست"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-5 flex items-center gap-2 font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4 text-accent" }), "ویجت خلاصه سریع"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: cn("mt-2 p-5", darkMode ? "bg-primary-dark text-white" : "bg-primary text-white"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-white/70",
						children: "حسابینو · امروز"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm",
						children: "خرج امروز"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xl font-bold tabular",
						children: formatToman(todaySpend)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-white/10 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-white/70",
								children: "باقی بودجه"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold tabular",
								children: formatCompact(remaining)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-white/10 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-white/70",
								children: "سررسید باز"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-bold tabular",
								children: [toFaDigits(upcoming), " مورد"]
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					label: "حالت شب",
					description: "پس‌زمینه تیره برای کل برنامه",
					checked: darkMode,
					onCheckedChange: setDarkMode
				})
			})
		]
	});
}
var SplitComponent = ReportsScreen;
//#endregion
export { SplitComponent as component };
