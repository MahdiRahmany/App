import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as useFinanceStore } from "./router-CxVnniVP.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Card } from "./Card-BNYFoj6L.mjs";
import { l as toFaDigits, o as formatToman, r as formatJalali, s as relativeDue } from "./format-4ArJapjy.mjs";
import { t as Button } from "./Button-BvB2WFdH.mjs";
import { t as ScreenHeader } from "./ScreenHeader-DH1YY_i2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checks-Dl9yi7WR.js
var import_jsx_runtime = require_jsx_runtime();
function ChecksScreen() {
	const checks = useFinanceStore((s) => s.checks);
	const markDone = useFinanceStore((s) => s.markCheckDone);
	const sorted = [...checks].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in pb-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
			title: "سررسید و چک",
			backTo: "/app/assets"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 px-4",
			children: [sorted.map((c) => {
				const due = relativeDue(c.dueDate);
				const done = c.status === "done";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: cn(done && "opacity-55"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: c.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: c.bank
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("rounded-full px-2.5 py-1 text-[11px] font-semibold", c.kind === "receivable" ? "bg-success/15 text-success" : "bg-accent-soft text-accent"),
								children: c.kind === "receivable" ? "دریافتی" : "پرداختی"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-lg font-bold tabular",
							children: formatToman(c.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: formatJalali(c.dueDate)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-semibold", done ? "text-muted" : due.tone === "late" ? "text-danger" : due.tone === "soon" ? "text-accent" : "text-muted"),
								children: done ? "انجام شد" : due.label
							})]
						}),
						!done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "soft",
							className: "mt-3 h-10 w-full text-xs",
							onClick: () => markDone(c.id),
							children: "علامت به‌عنوان انجام‌شده"
						}) : null
					]
				}, c.id);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-[11px] text-muted",
				children: [
					"شمارش معکوس بر اساس تاریخ امروز (",
					toFaDigits((/* @__PURE__ */ new Date()).toISOString().slice(0, 10)),
					") محاسبه می‌شود."
				]
			})]
		})]
	});
}
var SplitComponent = ChecksScreen;
//#endregion
export { SplitComponent as component };
