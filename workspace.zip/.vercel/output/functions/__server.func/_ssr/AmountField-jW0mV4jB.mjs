import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as toEnDigits, l as toFaDigits, n as formatGrouped } from "./format-4ArJapjy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AmountField-jW0mV4jB.js
var import_jsx_runtime = require_jsx_runtime();
function AmountField({ value, onChange, label = "مبلغ (تومان)" }) {
	const display = value ? formatGrouped(Number(toEnDigits(value) || 0)) : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-sm font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			inputMode: "numeric",
			value: display,
			onChange: (e) => {
				onChange(toEnDigits(e.target.value).replace(/[^\d]/g, ""));
			},
			placeholder: toFaDigits("0"),
			className: "h-12 w-full rounded-2xl bg-background px-4 text-base font-bold tabular outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
		})]
	});
}
function TextField({ value, onChange, label, placeholder, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-sm font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			value,
			onChange: (e) => onChange(e.target.value),
			placeholder,
			className: "h-12 w-full rounded-2xl bg-background px-4 text-sm outline-none ring-1 ring-line focus:ring-2 focus:ring-accent"
		})]
	});
}
//#endregion
export { TextField as n, AmountField as t };
