import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { z as ChevronRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ScreenHeader-DH1YY_i2.js
var import_jsx_runtime = require_jsx_runtime();
function ScreenHeader({ title, backTo, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center gap-2 px-4 pb-2 pt-3",
		children: [
			backTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: backTo,
				className: "flex size-11 shrink-0 items-center justify-center rounded-2xl bg-card card-shadow",
				"aria-label": "بازگشت",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "min-w-0 flex-1 text-lg font-bold",
				children: title
			}),
			action
		]
	});
}
//#endregion
export { ScreenHeader as t };
