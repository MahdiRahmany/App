import { c as WEEKDAYS, m as toJalali, s as JALALI_MONTHS } from "./router-CxVnniVP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-4ArJapjy.js
var FA = "۰۱۲۳۴۵۶۷۸۹";
function toFaDigits(value) {
	return String(value).replace(/\d/g, (d) => FA[Number(d)] ?? d);
}
function toEnDigits(value) {
	return value.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}
function formatGrouped(amount) {
	return toFaDigits(Math.abs(Math.round(amount)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "٬"));
}
function formatToman(amount, withUnit = true) {
	return `${amount < 0 ? "−" : ""}${formatGrouped(amount)}${withUnit ? " تومان" : ""}`;
}
function formatCompact(amount) {
	const abs = Math.abs(amount);
	if (abs >= 1e9) return `${toFaDigits((abs / 1e9).toFixed(abs >= 1e10 ? 0 : 1).replace(/\.0$/, "").replace(".", "٫"))} میلیارد`;
	if (abs >= 1e6) return `${toFaDigits((abs / 1e6).toFixed(abs >= 1e7 ? 0 : 1).replace(/\.0$/, "").replace(".", "٫"))} میلیون`;
	if (abs >= 1e3) return formatGrouped(amount);
	return toFaDigits(Math.round(abs));
}
function formatJalali(input, opts) {
	const { jy, jm, jd } = toJalali(input);
	const month = JALALI_MONTHS[jm - 1];
	const yearPart = opts?.year === false ? "" : ` ${toFaDigits(jy)}`;
	const base = `${toFaDigits(jd)} ${month}${yearPart}`;
	if (opts?.weekday) {
		const d = typeof input === "string" ? /* @__PURE__ */ new Date(input + (input.length === 10 ? "T12:00:00" : "")) : input;
		return `${WEEKDAYS[d.getDay()]} ${base}`;
	}
	return base;
}
function formatJalaliShort(input) {
	const { jm, jd } = toJalali(input);
	return `${toFaDigits(jd)} ${JALALI_MONTHS[jm - 1]}`;
}
function formatMonthTitle(jy, jm) {
	return `${JALALI_MONTHS[jm - 1]} ${toFaDigits(jy)}`;
}
function relativeDue(iso, today = /* @__PURE__ */ new Date()) {
	const target = /* @__PURE__ */ new Date(iso + (iso.length === 10 ? "T12:00:00" : ""));
	const a = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
	const b = new Date(target.getFullYear(), target.getMonth(), target.getDate()).getTime();
	const days = Math.round((b - a) / 864e5);
	if (days < 0) return {
		label: `${toFaDigits(Math.abs(days))} روز گذشته`,
		tone: "late"
	};
	if (days === 0) return {
		label: "امروز",
		tone: "soon"
	};
	if (days === 1) return {
		label: "فردا",
		tone: "soon"
	};
	if (days <= 7) return {
		label: `${toFaDigits(days)} روز مانده`,
		tone: "soon"
	};
	return {
		label: `${toFaDigits(days)} روز مانده`,
		tone: "ok"
	};
}
//#endregion
export { formatMonthTitle as a, toEnDigits as c, formatJalaliShort as i, toFaDigits as l, formatGrouped as n, formatToman as o, formatJalali as r, relativeDue as s, formatCompact as t };
