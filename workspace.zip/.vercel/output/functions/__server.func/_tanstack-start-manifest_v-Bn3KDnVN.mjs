//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bn3KDnVN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/app",
			"/lock",
			"/onboarding"
		],
		preloads: [
			"/assets/index-Bn5nhFja.js",
			"/assets/jsx-runtime-D3jfb0Ew.js",
			"/assets/link-_NCJwNvk.js",
			"/assets/useSelector-BP6qyW-I.js",
			"/assets/useRouter-DyqCsckV.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bn5nhFja.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CjZJHoAC.js", "/assets/PhoneFrame-DyWm1Mf2.js"]
	},
	"/app": {
		filePath: "/workspace/src/routes/app.tsx",
		children: [
			"/app/assets",
			"/app/budget",
			"/app/checks",
			"/app/loans",
			"/app/people",
			"/app/reports",
			"/app/search",
			"/app/settings",
			"/app/"
		],
		preloads: [
			"/assets/app-BQ8ieyIH.js",
			"/assets/house-CYee1hjX.js",
			"/assets/utils-DOQQTBMN.js"
		]
	},
	"/lock": {
		filePath: "/workspace/src/routes/lock.tsx",
		children: void 0,
		preloads: [
			"/assets/lock-Dg1gSTTM.js",
			"/assets/PinPad-E4Wm7VzH.js",
			"/assets/fingerprint-Bcqi-AA7.js",
			"/assets/PhoneFrame-DyWm1Mf2.js"
		]
	},
	"/onboarding": {
		filePath: "/workspace/src/routes/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-D3BmBH5N.js",
			"/assets/bell-DAkH8BMt.js",
			"/assets/PinPad-E4Wm7VzH.js",
			"/assets/fingerprint-Bcqi-AA7.js",
			"/assets/utils-DOQQTBMN.js",
			"/assets/format-BRfGctih.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/Switch-BWlrnxfI.js",
			"/assets/PhoneFrame-DyWm1Mf2.js"
		]
	},
	"/app/assets": {
		filePath: "/workspace/src/routes/app/assets.tsx",
		children: void 0,
		preloads: [
			"/assets/assets-YJ9IjSVk.js",
			"/assets/chevron-left-CASAygPu.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/ChartWrap-Ca1BQh-E.js",
			"/assets/YAxis-CkCJ2VhF.js",
			"/assets/format-BRfGctih.js"
		]
	},
	"/app/budget": {
		filePath: "/workspace/src/routes/app/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-tmTDiOAy.js",
			"/assets/icons-DsNlv8JF.js",
			"/assets/plus-CByZ_AV2.js",
			"/assets/Sheet-0vjS0FlJ.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/format-BRfGctih.js",
			"/assets/MonthSwitcher-C6HcEBks.js",
			"/assets/ProgressBar-pvx2nzJs.js",
			"/assets/AmountField-D_jYauAm.js",
			"/assets/Button-CR1zht0u.js"
		]
	},
	"/app/checks": {
		filePath: "/workspace/src/routes/app/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-Pm257Ir1.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/format-BRfGctih.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/ScreenHeader-BaOy7ykq.js"
		]
	},
	"/app/loans": {
		filePath: "/workspace/src/routes/app/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-BV1QgXDt.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/format-BRfGctih.js",
			"/assets/ProgressBar-pvx2nzJs.js",
			"/assets/ScreenHeader-BaOy7ykq.js",
			"/assets/Segmented-CQoPg-D3.js"
		]
	},
	"/app/people": {
		filePath: "/workspace/src/routes/app/people.tsx",
		children: ["/app/people/$personId", "/app/people/"],
		preloads: ["/assets/people-dsCROn1w.js"]
	},
	"/app/reports": {
		filePath: "/workspace/src/routes/app/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-COysP3VQ.js",
			"/assets/icons-DsNlv8JF.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/ChartWrap-Ca1BQh-E.js",
			"/assets/format-BRfGctih.js",
			"/assets/ProgressBar-pvx2nzJs.js",
			"/assets/Segmented-CQoPg-D3.js",
			"/assets/Switch-BWlrnxfI.js"
		]
	},
	"/app/search": {
		filePath: "/workspace/src/routes/app/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-BSt-sLhB.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/format-BRfGctih.js",
			"/assets/AmountField-D_jYauAm.js",
			"/assets/ScreenHeader-BaOy7ykq.js",
			"/assets/TransactionRow-DFx-hbxK.js"
		]
	},
	"/app/settings": {
		filePath: "/workspace/src/routes/app/settings.tsx",
		children: [
			"/app/settings/backup",
			"/app/settings/categories",
			"/app/settings/"
		],
		preloads: ["/assets/settings-dsCROn1w.js"]
	},
	"/app/": {
		filePath: "/workspace/src/routes/app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/app-3fp_w3pw.js",
			"/assets/icons-DsNlv8JF.js",
			"/assets/bell-DAkH8BMt.js",
			"/assets/plus-CByZ_AV2.js",
			"/assets/Sheet-0vjS0FlJ.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/ChartWrap-Ca1BQh-E.js",
			"/assets/YAxis-CkCJ2VhF.js",
			"/assets/format-BRfGctih.js",
			"/assets/MonthSwitcher-C6HcEBks.js",
			"/assets/AmountField-D_jYauAm.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/TransactionRow-DFx-hbxK.js",
			"/assets/Segmented-CQoPg-D3.js"
		]
	},
	"/app/people/$personId": {
		filePath: "/workspace/src/routes/app/people/$personId.tsx",
		children: void 0,
		preloads: [
			"/assets/_personId-DRVOsulj.js",
			"/assets/Sheet-0vjS0FlJ.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/format-BRfGctih.js",
			"/assets/AmountField-D_jYauAm.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/ScreenHeader-BaOy7ykq.js"
		]
	},
	"/app/settings/backup": {
		filePath: "/workspace/src/routes/app/settings/backup.tsx",
		children: void 0,
		preloads: [
			"/assets/backup-D425ILI3.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/ScreenHeader-BaOy7ykq.js"
		]
	},
	"/app/settings/categories": {
		filePath: "/workspace/src/routes/app/settings/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BIapd6H0.js",
			"/assets/icons-DsNlv8JF.js",
			"/assets/plus-CByZ_AV2.js",
			"/assets/Sheet-0vjS0FlJ.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/AmountField-D_jYauAm.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/ScreenHeader-BaOy7ykq.js",
			"/assets/Segmented-CQoPg-D3.js"
		]
	},
	"/app/people/": {
		filePath: "/workspace/src/routes/app/people/index.tsx",
		children: void 0,
		preloads: [
			"/assets/people-DLbthP5d.js",
			"/assets/chevron-left-CASAygPu.js",
			"/assets/plus-CByZ_AV2.js",
			"/assets/Sheet-0vjS0FlJ.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/format-BRfGctih.js",
			"/assets/AmountField-D_jYauAm.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/ScreenHeader-BaOy7ykq.js"
		]
	},
	"/app/settings/": {
		filePath: "/workspace/src/routes/app/settings/index.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-LYfYGaH1.js",
			"/assets/chevron-left-CASAygPu.js",
			"/assets/fingerprint-Bcqi-AA7.js",
			"/assets/Card-C9PwOfwf.js",
			"/assets/format-BRfGctih.js",
			"/assets/Button-CR1zht0u.js",
			"/assets/Switch-BWlrnxfI.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
