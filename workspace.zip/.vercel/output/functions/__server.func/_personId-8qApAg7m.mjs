import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useParams } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "./_libs/radix-ui__react-context+react.mjs";
import { o as useFinanceStore } from "./_ssr/router-CxVnniVP.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { t as Card } from "./_ssr/Card-BNYFoj6L.mjs";
import { o as formatToman, r as formatJalali } from "./_ssr/format-4ArJapjy.mjs";
import { t as Sheet } from "./_ssr/Sheet-ZcYj---f.mjs";
import { n as TextField, t as AmountField } from "./_ssr/AmountField-jW0mV4jB.mjs";
import { t as Button } from "./_ssr/Button-BvB2WFdH.mjs";
import { t as ScreenHeader } from "./_ssr/ScreenHeader-DH1YY_i2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_personId-8qApAg7m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PersonScreen() {
	const { personId } = useParams({ strict: false });
	const person = useFinanceStore((s) => s.people.find((p) => p.id === personId));
	const settle = useFinanceStore((s) => s.settlePerson);
	const [mode, setMode] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	if (!person) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
		title: "شخص پیدا نشد",
		backTo: "/app/people"
	}) });
	function apply() {
		const n = Number(amount);
		if (!n || !person) return;
		const signed = mode === "in" ? -n : n;
		settle(person.id, signed, note.trim() || (mode === "in" ? "دریافت" : "پرداخت"));
		setAmount("");
		setNote("");
		setMode(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fade-in pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenHeader, {
				title: person.name,
				backTo: "/app/people"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex flex-col items-center py-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-16 items-center justify-center rounded-3xl text-lg font-bold text-white",
								style: { background: person.color },
								children: person.initials
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted",
								children: "مانده حساب"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("text-2xl font-bold tabular", person.balance > 0 ? "text-success" : person.balance < 0 ? "text-danger" : "text-ink"),
								children: formatToman(Math.abs(person.balance))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: person.balance > 0 ? "این شخص به تو بدهکار است" : person.balance < 0 ? "تو به این شخص بدهکاری" : "حساب صاف است"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 grid w-full grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => setMode("in"),
									children: "دریافت"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									onClick: () => setMode("out"),
									children: "پرداخت"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 font-bold",
						children: "تاریخچه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "mt-2 space-y-3",
						children: person.history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-6 text-center text-sm text-muted",
							children: "هنوز حرکتی نیست"
						}) : person.history.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold",
								children: h.note
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: formatJalali(h.date)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn("text-sm font-bold tabular", h.amount > 0 ? "text-success" : "text-danger"),
								children: [h.amount > 0 ? "+" : "−", formatToman(Math.abs(h.amount), false)]
							})]
						}, h.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: mode !== null,
				onClose: () => setMode(null),
				title: mode === "in" ? "ثبت دریافت" : "ثبت پرداخت",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmountField, {
							value: amount,
							onChange: setAmount
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							value: note,
							onChange: setNote,
							label: "توضیح",
							placeholder: "اختیاری"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: !amount,
							onClick: apply,
							children: "ثبت"
						})
					]
				})
			})
		]
	});
}
var SplitComponent = PersonScreen;
//#endregion
export { SplitComponent as component };
