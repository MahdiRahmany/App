// AppContext.js — Context API ساده برای state سراسری اپ (جایگزین سبک به‌جای Redux)

import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import KEYS, { getItem, setItem } from "../utils/storage";
import { mockTransactions, mockBudgets, categories as defaultCategories } from "../utils/mockData";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [isReady, setIsReady] = useState(false);
  const [onboardingDone, setOnboardingDone] = useState(false);
  const [pin, setPin] = useState(null);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [reminder, setReminder] = useState({ enabled: false, frequency: "daily", hour: "21:00" });
  const [transactions, setTransactions] = useState(mockTransactions);
  const [budgets, setBudgets] = useState(mockBudgets);
  const [userCategories, setUserCategories] = useState(defaultCategories);

  useEffect(() => {
    (async () => {
      const done = await getItem(KEYS.ONBOARDING_DONE, false);
      const savedPin = await getItem(KEYS.PIN, null);
      const bio = await getItem(KEYS.BIOMETRIC_ENABLED, false);
      const rem = await getItem(KEYS.REMINDER, reminder);
      const tx = await getItem(KEYS.TRANSACTIONS, null);
      const bud = await getItem(KEYS.BUDGETS, null);
      const cats = await getItem(KEYS.CATEGORIES, null);

      setOnboardingDone(done);
      setPin(savedPin);
      setBiometricEnabled(bio);
      setReminder(rem);
      if (tx) setTransactions(tx);
      if (bud) setBudgets(bud);
      if (cats) setUserCategories(cats);
      setIsReady(true);
    })();
  }, []);

  const completeOnboarding = async () => {
    await setItem(KEYS.ONBOARDING_DONE, true);
    setOnboardingDone(true);
  };

  const savePin = async (newPin) => {
    await setItem(KEYS.PIN, newPin);
    setPin(newPin);
  };

  const saveBiometric = async (val) => {
    await setItem(KEYS.BIOMETRIC_ENABLED, val);
    setBiometricEnabled(val);
  };

  const saveReminder = async (val) => {
    await setItem(KEYS.REMINDER, val);
    setReminder(val);
  };

  const addTransaction = async (tx) => {
    const next = [{ ...tx, id: `tx_${Date.now()}` }, ...transactions];
    setTransactions(next);
    await setItem(KEYS.TRANSACTIONS, next);
  };

  const upsertBudget = async (budget) => {
    const exists = budgets.some((b) => b.id === budget.id);
    const next = exists
      ? budgets.map((b) => (b.id === budget.id ? budget : b))
      : [...budgets, { ...budget, id: `b_${Date.now()}` }];
    setBudgets(next);
    await setItem(KEYS.BUDGETS, next);
  };

  const upsertCategory = async (category) => {
    const exists = userCategories.some((c) => c.id === category.id);
    const next = exists
      ? userCategories.map((c) => (c.id === category.id ? category : c))
      : [...userCategories, { ...category, id: category.id || `cat_${Date.now()}` }];
    setUserCategories(next);
    await setItem(KEYS.CATEGORIES, next);
  };

  const value = useMemo(
    () => ({
      isReady,
      onboardingDone,
      completeOnboarding,
      pin,
      savePin,
      biometricEnabled,
      saveBiometric,
      reminder,
      saveReminder,
      transactions,
      addTransaction,
      budgets,
      upsertBudget,
      userCategories,
      upsertCategory,
    }),
    [isReady, onboardingDone, pin, biometricEnabled, reminder, transactions, budgets, userCategories]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
