// theme.js — سیستم طراحی یکپارچه اپ. همه‌جای اپ فقط از این فایل رنگ/فاصله/فونت بگیرید.

export const colors = {
  primaryDark: "#1B1447",
  primary: "#2A1F6E",
  accent: "#FF6B47",
  background: "#F5F5F8",
  cardWhite: "#FFFFFF",
  textDanger: "#E53935", // خرج / بدهی
  textSuccess: "#2E7D32", // درآمد / طلب
  textPrimary: "#1B1447",
  textSecondary: "#8A8A99",
  border: "#EAEAF0",
  shadow: "rgba(27, 20, 71, 0.08)",
  white: "#FFFFFF",
  overlay: "rgba(27,20,71,0.55)",
};

export const radius = {
  card: 16,
  pill: 999,
  sm: 10,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const fonts = {
  regular: "Vazirmatn_400Regular",
  medium: "Vazirmatn_500Medium",
  bold: "Vazirmatn_700Bold",
};

export const typography = {
  h1: { fontFamily: fonts.bold, fontSize: 24, color: colors.textPrimary },
  h2: { fontFamily: fonts.bold, fontSize: 19, color: colors.textPrimary },
  title: { fontFamily: fonts.medium, fontSize: 16, color: colors.textPrimary },
  body: { fontFamily: fonts.regular, fontSize: 14, color: colors.textPrimary },
  caption: { fontFamily: fonts.regular, fontSize: 12, color: colors.textSecondary },
  amountLg: { fontFamily: fonts.bold, fontSize: 28, color: colors.white },
};

export const shadowStyle = {
  shadowColor: colors.primaryDark,
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.08,
  shadowRadius: 12,
  elevation: 3,
};

export default { colors, radius, spacing, fonts, typography, shadowStyle };
