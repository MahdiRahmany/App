import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import SmsPermissionScreen from "../screens/onboarding/SmsPermissionScreen";
import LockSetupScreen from "../screens/onboarding/LockSetupScreen";
import ReminderScreen from "../screens/onboarding/ReminderScreen";
import TrialOfferScreen from "../screens/onboarding/TrialOfferScreen";

const Stack = createNativeStackNavigator();

export default function OnboardingNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="SmsPermission" component={SmsPermissionScreen} />
      <Stack.Screen name="LockSetup" component={LockSetupScreen} />
      <Stack.Screen name="Reminder" component={ReminderScreen} />
      <Stack.Screen name="TrialOffer" component={TrialOfferScreen} />
    </Stack.Navigator>
  );
}
