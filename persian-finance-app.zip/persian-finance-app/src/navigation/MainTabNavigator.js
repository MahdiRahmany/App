import React from "react";
import { Text } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { colors } from "../theme/theme";

import HomeScreen from "../screens/home/HomeScreen";
import SearchScreen from "../screens/home/SearchScreen";

import ReportsScreen from "../screens/reports/ReportsScreen";

import BudgetScreen from "../screens/budget/BudgetScreen";
import AddBudgetScreen from "../screens/budget/AddBudgetScreen";

import AssetsScreen from "../screens/assets/AssetsScreen";
import LoansScreen from "../screens/assets/LoansScreen";
import DebtsScreen from "../screens/assets/DebtsScreen";
import DueDatesScreen from "../screens/assets/DueDatesScreen";

import SettingsScreen from "../screens/settings/SettingsScreen";
import CategoriesScreen from "../screens/settings/CategoriesScreen";
import BackupScreen from "../screens/settings/BackupScreen";

const Tab = createBottomTabNavigator();
const HomeStack = createNativeStackNavigator();
const BudgetStack = createNativeStackNavigator();
const AssetsStack = createNativeStackNavigator();
const SettingsStack = createNativeStackNavigator();

const TAB_ICONS = {
  خانه: "🏠",
  گزارش‌ها: "📊",
  بودجه: "🎯",
  دارایی‌ها: "💼",
  تنظیمات: "⚙️",
};

function HomeStackNavigator() {
  return (
    <HomeStack.Navigator screenOptions={{ headerShown: false }}>
      <HomeStack.Screen name="HomeMain" component={HomeScreen} />
      <HomeStack.Screen name="Search" component={SearchScreen} />
    </HomeStack.Navigator>
  );
}

function BudgetStackNavigator() {
  return (
    <BudgetStack.Navigator screenOptions={{ headerShown: false }}>
      <BudgetStack.Screen name="BudgetMain" component={BudgetScreen} />
      <BudgetStack.Screen name="AddBudget" component={AddBudgetScreen} />
    </BudgetStack.Navigator>
  );
}

function AssetsStackNavigator() {
  return (
    <AssetsStack.Navigator screenOptions={{ headerShown: false }}>
      <AssetsStack.Screen name="AssetsMain" component={AssetsScreen} />
      <AssetsStack.Screen name="Loans" component={LoansScreen} />
      <AssetsStack.Screen name="Debts" component={DebtsScreen} />
      <AssetsStack.Screen name="DueDates" component={DueDatesScreen} />
    </AssetsStack.Navigator>
  );
}

function SettingsStackNavigator() {
  return (
    <SettingsStack.Navigator screenOptions={{ headerShown: false }}>
      <SettingsStack.Screen name="SettingsMain" component={SettingsScreen} />
      <SettingsStack.Screen name="Categories" component={CategoriesScreen} />
      <SettingsStack.Screen name="Backup" component={BackupScreen} />
    </SettingsStack.Navigator>
  );
}

export default function MainTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarStyle: { height: 64, paddingBottom: 8, paddingTop: 8 },
        tabBarLabelStyle: { fontFamily: "Vazirmatn_500Medium", fontSize: 11 },
        tabBarIcon: () => <Text style={{ fontSize: 18 }}>{TAB_ICONS[route.name]}</Text>,
      })}
    >
      <Tab.Screen name="خانه" component={HomeStackNavigator} />
      <Tab.Screen name="گزارش‌ها" component={ReportsScreen} />
      <Tab.Screen name="بودجه" component={BudgetStackNavigator} />
      <Tab.Screen name="دارایی‌ها" component={AssetsStackNavigator} />
      <Tab.Screen name="تنظیمات" component={SettingsStackNavigator} />
    </Tab.Navigator>
  );
}
