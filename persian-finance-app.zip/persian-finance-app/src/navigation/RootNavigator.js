import React from "react";
import { View, ActivityIndicator } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { useApp } from "../context/AppContext";
import OnboardingNavigator from "./OnboardingNavigator";
import MainTabNavigator from "./MainTabNavigator";
import { colors } from "../theme/theme";

export default function RootNavigator() {
  const { isReady, onboardingDone } = useApp();

  if (!isReady) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.primaryDark }}>
        <ActivityIndicator color={colors.accent} size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {onboardingDone ? <MainTabNavigator /> : <OnboardingNavigator />}
    </NavigationContainer>
  );
}
