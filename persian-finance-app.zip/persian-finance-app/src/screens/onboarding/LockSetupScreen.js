import React, { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Switch } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import { toFaDigits } from "../../utils/format";
import { useApp } from "../../context/AppContext";

const KEYPAD = ["۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "بیومتریک", "۰", "پاک"];

export default function LockSetupScreen({ navigation }) {
  const { savePin, saveBiometric } = useApp();
  const [pin, setPin] = useState("");
  const [biometric, setBiometric] = useState(true);

  const handleKey = (key) => {
    if (key === "پاک") return setPin((p) => p.slice(0, -1));
    if (key === "بیومتریک") return; // فقط نمایشی در این صفحه
    if (pin.length < 4) setPin((p) => p + key);
  };

  const handleContinue = async () => {
    await savePin(pin || "1234");
    await saveBiometric(biometric);
    navigation.navigate("Reminder");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>قفل، فقط برای خودت</Text>
      <Text style={styles.body}>یک پین ۴ رقمی تنظیم کن تا فقط خودت به اطلاعات مالی‌ات دسترسی داشته باشی.</Text>

      <View style={styles.dotsRow}>
        {[0, 1, 2, 3].map((i) => (
          <View key={i} style={[styles.dot, pin.length > i && styles.dotFilled]} />
        ))}
      </View>

      <View style={styles.keypad}>
        {KEYPAD.map((key) => (
          <TouchableOpacity key={key} style={styles.key} onPress={() => handleKey(key)}>
            <Text style={styles.keyText}>{key === "بیومتریک" ? "🔒" : key}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.biometricRow}>
        <Text style={styles.biometricLabel}>فعال‌سازی ورود با اثر انگشت / Face ID</Text>
        <Switch
          value={biometric}
          onValueChange={setBiometric}
          trackColor={{ true: colors.accent, false: colors.border }}
          thumbColor={colors.white}
        />
      </View>

      <TouchableOpacity
        style={[styles.primaryBtn, pin.length < 4 && styles.disabled]}
        disabled={pin.length < 4}
        onPress={handleContinue}
      >
        <Text style={styles.primaryBtnText}>ادامه</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.xl, paddingTop: 80 },
  title: { ...typography.h1, textAlign: "center" },
  body: { ...typography.body, textAlign: "center", marginTop: spacing.sm, color: colors.textSecondary },
  dotsRow: { flexDirection: "row-reverse", justifyContent: "center", gap: 14, marginVertical: spacing.xl },
  dot: { width: 16, height: 16, borderRadius: 8, borderWidth: 2, borderColor: colors.primary },
  dotFilled: { backgroundColor: colors.accent, borderColor: colors.accent },
  keypad: { flexDirection: "row-reverse", flexWrap: "wrap", justifyContent: "center" },
  key: {
    width: 76,
    height: 76,
    borderRadius: 38,
    alignItems: "center",
    justifyContent: "center",
    margin: 8,
    backgroundColor: colors.cardWhite,
  },
  keyText: { ...typography.h2 },
  biometricRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: spacing.lg,
    backgroundColor: colors.cardWhite,
    padding: spacing.md,
    borderRadius: radius.card,
  },
  biometricLabel: { ...typography.body, flex: 1, textAlign: "right", marginEnd: spacing.sm },
  primaryBtn: {
    backgroundColor: colors.accent,
    paddingVertical: 16,
    borderRadius: radius.pill,
    marginTop: spacing.xl,
    alignItems: "center",
  },
  disabled: { opacity: 0.4 },
  primaryBtnText: { ...typography.title, color: colors.white },
});
