import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import { useApp } from "../../context/AppContext";

const BENEFITS = [
  "ثبت خودکار تراکنش از پیامک بانکی",
  "گزارش‌های نامحدود و نمودارهای پیشرفته",
  "بودجه‌بندی هوشمند برای همه دسته‌ها",
  "پیگیری دارایی، طلا و ارز دیجیتال",
  "پشتیبان‌گیری ابری و همگام‌سازی",
];

export default function TrialOfferScreen({ navigation }) {
  const { completeOnboarding } = useApp();

  const finish = async () => {
    await completeOnboarding();
  };

  return (
    <View style={styles.container}>
      <View style={styles.badge}>
        <Text style={styles.badgeText}>پیشنهاد ویژه</Text>
      </View>
      <Text style={styles.title}>۳۱ روز اشتراک رایگان</Text>
      <Text style={styles.body}>همه امکانات نسخه کامل رو یک ماه رایگان امتحان کن. هر زمان خواستی می‌تونی لغو کنی.</Text>

      <View style={styles.benefits}>
        {BENEFITS.map((b) => (
          <View key={b} style={styles.benefitRow}>
            <Text style={styles.check}>✓</Text>
            <Text style={styles.benefitText}>{b}</Text>
          </View>
        ))}
      </View>

      <TouchableOpacity style={styles.primaryBtn} onPress={finish}>
        <Text style={styles.primaryBtnText}>شروع دوره آزمایشی رایگان</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={finish}>
        <Text style={styles.skip}>فعلاً نه</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primaryDark, padding: spacing.xl, justifyContent: "center" },
  badge: { alignSelf: "center", backgroundColor: colors.accent, borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 6, marginBottom: spacing.md },
  badgeText: { color: colors.white, ...typography.caption, fontFamily: "Vazirmatn_700Bold" },
  title: { ...typography.h1, color: colors.white, textAlign: "center" },
  body: { ...typography.body, color: "rgba(255,255,255,0.75)", textAlign: "center", marginTop: spacing.sm },
  benefits: { marginTop: spacing.xl, gap: 12 },
  benefitRow: { flexDirection: "row-reverse", alignItems: "center" },
  check: { color: colors.accent, ...typography.title, marginStart: spacing.sm },
  benefitText: { color: colors.white, ...typography.body, textAlign: "right", flex: 1 },
  primaryBtn: { backgroundColor: colors.accent, paddingVertical: 16, borderRadius: radius.pill, marginTop: spacing.xl, alignItems: "center" },
  primaryBtnText: { ...typography.title, color: colors.white },
  skip: { ...typography.body, color: "rgba(255,255,255,0.6)", textAlign: "center", marginTop: spacing.md },
});
