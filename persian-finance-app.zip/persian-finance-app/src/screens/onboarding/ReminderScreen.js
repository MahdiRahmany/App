import React, { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Switch } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import { useApp } from "../../context/AppContext";

const HOURS = ["۹:۰۰", "۱۳:۰۰", "۱۸:۰۰", "۲۱:۰۰", "۲۲:۳۰"];

export default function ReminderScreen({ navigation }) {
  const { saveReminder } = useApp();
  const [enabled, setEnabled] = useState(true);
  const [frequency, setFrequency] = useState("daily");
  const [hour, setHour] = useState("۲۱:۰۰");

  const handleContinue = async () => {
    await saveReminder({ enabled, frequency, hour });
    navigation.navigate("TrialOffer");
  };

  return (
    <View style={styles.container}>
      <Text style={{ fontSize: 56, textAlign: "center" }}>⏰</Text>
      <Text style={styles.title}>یادآور ثبت هزینه‌ها</Text>
      <Text style={styles.body}>هر روز یا هر هفته یک یادآوری بگیر تا هیچ‌وقت ثبت تراکنش‌هات یادت نره.</Text>

      <View style={styles.row}>
        <Text style={styles.label}>فعال‌سازی یادآور</Text>
        <Switch value={enabled} onValueChange={setEnabled} trackColor={{ true: colors.accent, false: colors.border }} thumbColor={colors.white} />
      </View>

      <View style={styles.segment}>
        {[
          { key: "daily", label: "روزانه" },
          { key: "weekly", label: "هفتگی" },
        ].map((opt) => (
          <TouchableOpacity
            key={opt.key}
            style={[styles.segmentItem, frequency === opt.key && styles.segmentItemActive]}
            onPress={() => setFrequency(opt.key)}
          >
            <Text style={[styles.segmentText, frequency === opt.key && styles.segmentTextActive]}>{opt.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.subLabel}>ساعت یادآوری</Text>
      <View style={styles.hoursRow}>
        {HOURS.map((h) => (
          <TouchableOpacity key={h} style={[styles.hourChip, hour === h && styles.hourChipActive]} onPress={() => setHour(h)}>
            <Text style={[styles.hourText, hour === h && styles.hourTextActive]}>{h}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity style={styles.primaryBtn} onPress={handleContinue}>
        <Text style={styles.primaryBtnText}>ادامه</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.xl, paddingTop: 70 },
  title: { ...typography.h1, textAlign: "center", marginTop: spacing.md },
  body: { ...typography.body, textAlign: "center", color: colors.textSecondary, marginTop: spacing.sm },
  row: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: colors.cardWhite,
    padding: spacing.md,
    borderRadius: radius.card,
    marginTop: spacing.xl,
  },
  label: { ...typography.title, fontSize: 14 },
  segment: { flexDirection: "row-reverse", backgroundColor: colors.cardWhite, borderRadius: radius.pill, padding: 4, marginTop: spacing.md },
  segmentItem: { flex: 1, paddingVertical: 10, borderRadius: radius.pill, alignItems: "center" },
  segmentItemActive: { backgroundColor: colors.accent },
  segmentText: { ...typography.body },
  segmentTextActive: { color: colors.white, fontFamily: "Vazirmatn_700Bold" },
  subLabel: { ...typography.caption, textAlign: "right", marginTop: spacing.lg, marginBottom: spacing.sm },
  hoursRow: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  hourChip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: radius.pill, backgroundColor: colors.cardWhite },
  hourChipActive: { backgroundColor: colors.primary },
  hourText: { ...typography.body },
  hourTextActive: { color: colors.white },
  primaryBtn: { backgroundColor: colors.accent, paddingVertical: 16, borderRadius: radius.pill, marginTop: spacing.xl, alignItems: "center" },
  primaryBtnText: { ...typography.title, color: colors.white },
});
