import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Platform } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";

export default function SmsPermissionScreen({ navigation }) {
  const handleAllow = () => {
    // NOTE: خواندن خودکار پیامک‌های بانکی روی iOS اصلاً مجاز نیست (محدودیت اپل)
    // و روی اندروید هم نیازمند مجوز حساس READ_SMS + بررسی Play Console است.
    // اینجا فقط UI شبیه‌سازی شده و مستقیم به مرحله بعد می‌رویم.
    navigation.navigate("LockSetup");
  };

  return (
    <View style={styles.container}>
      <View style={styles.illustration}>
        <Text style={{ fontSize: 64 }}>💬</Text>
      </View>

      <Text style={styles.title}>خواندن پیامک‌های بانکی</Text>
      <Text style={styles.body}>
        با اجازه دسترسی به پیامک‌ها، تراکنش‌های بانکی‌ات به‌صورت خودکار شناسایی و دسته‌بندی می‌شن — دیگه لازم
        نیست هیچ‌چیزی رو دستی وارد کنی.
      </Text>

      {Platform.OS === "ios" && (
        <Text style={styles.note}>
          توجه: iOS اجازه خواندن خودکار پیامک را به اپ‌ها نمی‌دهد؛ در نسخه iOS این بخش به «افزودن دستی تراکنش»
          تبدیل می‌شود.
        </Text>
      )}

      <TouchableOpacity style={styles.primaryBtn} onPress={handleAllow}>
        <Text style={styles.primaryBtnText}>اجازه دسترسی</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("LockSetup")}>
        <Text style={styles.skip}>فعلاً نه، بعداً تصمیم می‌گیرم</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primaryDark,
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.xl,
  },
  illustration: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "rgba(255,255,255,0.08)",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.lg,
  },
  title: { ...typography.h1, color: colors.white, textAlign: "center", marginBottom: spacing.sm },
  body: { ...typography.body, color: "rgba(255,255,255,0.75)", textAlign: "center", lineHeight: 22 },
  note: { ...typography.caption, color: colors.accent, textAlign: "center", marginTop: spacing.md },
  primaryBtn: {
    backgroundColor: colors.accent,
    paddingVertical: 16,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.pill,
    marginTop: spacing.xl,
    width: "100%",
    alignItems: "center",
  },
  primaryBtnText: { ...typography.title, color: colors.white },
  skip: { ...typography.body, color: "rgba(255,255,255,0.6)", marginTop: spacing.md },
});
