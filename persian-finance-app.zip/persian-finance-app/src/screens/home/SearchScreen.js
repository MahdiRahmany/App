import React, { useMemo, useState } from "react";
import { View, Text, TextInput, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import TransactionRow from "../../components/TransactionRow";
import { useApp } from "../../context/AppContext";
import { categories } from "../../utils/mockData";

export default function SearchScreen({ navigation }) {
  const { transactions } = useApp();
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState(null);

  const filtered = useMemo(() => {
    return transactions.filter((t) => {
      const matchesQuery = t.title.includes(query);
      const matchesCategory = !activeCategory || t.categoryId === activeCategory;
      return matchesQuery && matchesCategory;
    });
  }, [transactions, query, activeCategory]);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ بازگشت</Text>
        </TouchableOpacity>
        <Text style={styles.title}>جستجوی تراکنش</Text>
      </View>

      <TextInput
        style={styles.input}
        placeholder="نام فروشگاه یا توضیحات را جستجو کن..."
        placeholderTextColor={colors.textSecondary}
        value={query}
        onChangeText={setQuery}
        textAlign="right"
      />

      <FlatList
        horizontal
        inverted
        data={[{ id: null, name: "همه" }, ...categories]}
        keyExtractor={(c) => String(c.id)}
        style={{ marginVertical: spacing.md, flexGrow: 0 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => setActiveCategory(item.id)}
            style={[styles.chip, activeCategory === item.id && styles.chipActive]}
          >
            <Text style={[styles.chipText, activeCategory === item.id && styles.chipTextActive]}>
              {item.icon ? `${item.icon} ` : ""}
              {item.name}
            </Text>
          </TouchableOpacity>
        )}
      />

      <FlatList
        data={filtered}
        keyExtractor={(t) => t.id}
        ListEmptyComponent={<Text style={styles.empty}>موردی پیدا نشد</Text>}
        renderItem={({ item }) => <TransactionRow transaction={item} />}
        ItemSeparatorComponent={() => <View style={styles.divider} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md, paddingTop: 56 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  back: { color: colors.accent, ...typography.body },
  title: { ...typography.h2 },
  input: { backgroundColor: colors.cardWhite, borderRadius: radius.card, padding: spacing.md, ...typography.body },
  chip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: radius.pill, backgroundColor: colors.cardWhite, marginStart: 8 },
  chipActive: { backgroundColor: colors.accent },
  chipText: { ...typography.body },
  chipTextActive: { color: colors.white },
  divider: { height: 1, backgroundColor: colors.border },
  empty: { ...typography.body, textAlign: "center", marginTop: spacing.xl, color: colors.textSecondary },
});
