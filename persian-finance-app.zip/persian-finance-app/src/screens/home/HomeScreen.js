import React, { useMemo, useState } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import ChartBar from "../../components/ChartBar";
import TransactionRow from "../../components/TransactionRow";
import { useApp } from "../../context/AppContext";
import { sumIncomeExpense, dailyTotals } from "../../utils/mockData";
import { formatToman } from "../../utils/format";

const MONTHS = ["شهریور", "مهر", "آبان"];

export default function HomeScreen({ navigation }) {
  const { transactions } = useApp();
  const [monthIndex, setMonthIndex] = useState(MONTHS.length - 1);

  const { income, expense, net } = useMemo(() => sumIncomeExpense(transactions), [transactions]);
  const chartData = useMemo(() => dailyTotals(transactions, 14), [transactions]);

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <View style={styles.header}>
        <View>
          <Text style={styles.hello}>سلام 👋</Text>
          <Text style={styles.headerTitle}>خلاصه مالی این ماه</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate("Search")} style={styles.searchBtn}>
          <Text style={{ fontSize: 18 }}>🔍</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.monthSwitch}>
        {MONTHS.map((m, i) => (
          <TouchableOpacity key={m} onPress={() => setMonthIndex(i)} style={[styles.monthChip, monthIndex === i && styles.monthChipActive]}>
            <Text style={[styles.monthText, monthIndex === i && styles.monthTextActive]}>{m}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Card style={styles.summaryCard} padded={false}>
        <View style={styles.summaryInner}>
          <Text style={styles.netLabel}>مانده خالص</Text>
          <Text style={typography.amountLg}>{formatToman(net)}</Text>
          <View style={styles.summaryRow}>
            <View style={styles.summaryCol}>
              <Text style={styles.summaryColLabel}>درآمد</Text>
              <Text style={[styles.summaryColValue, { color: colors.textSuccess }]}>{formatToman(income, { withSuffix: false })}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.summaryCol}>
              <Text style={styles.summaryColLabel}>خرج</Text>
              <Text style={[styles.summaryColValue, { color: colors.textDanger }]}>{formatToman(expense, { withSuffix: false })}</Text>
            </View>
          </View>
        </View>
      </Card>

      <Card style={{ marginTop: spacing.md }}>
        <Text style={styles.sectionTitle}>روند هزینه ۱۴ روز اخیر</Text>
        <ChartBar data={chartData} />
      </Card>

      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionTitle}>آخرین تراکنش‌ها</Text>
        <TouchableOpacity onPress={() => navigation.navigate("Search")}>
          <Text style={styles.seeAll}>مشاهده همه</Text>
        </TouchableOpacity>
      </View>

      <Card>
        {transactions.slice(0, 6).map((t, i) => (
          <React.Fragment key={t.id}>
            <TransactionRow transaction={t} />
            {i < 5 && <View style={styles.rowDivider} />}
          </React.Fragment>
        ))}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md },
  header: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginTop: spacing.md },
  hello: { ...typography.body, color: colors.textSecondary, textAlign: "right" },
  headerTitle: { ...typography.h1, textAlign: "right" },
  searchBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: colors.cardWhite, alignItems: "center", justifyContent: "center" },
  monthSwitch: { flexDirection: "row-reverse", marginTop: spacing.md, gap: 8 },
  monthChip: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: radius.pill, backgroundColor: colors.cardWhite },
  monthChipActive: { backgroundColor: colors.primary },
  monthText: { ...typography.body },
  monthTextActive: { color: colors.white },
  summaryCard: { marginTop: spacing.md, backgroundColor: colors.primaryDark, overflow: "hidden" },
  summaryInner: { padding: spacing.lg },
  netLabel: { color: "rgba(255,255,255,0.7)", ...typography.caption, textAlign: "right" },
  summaryRow: { flexDirection: "row-reverse", marginTop: spacing.md },
  summaryCol: { flex: 1 },
  summaryColLabel: { color: "rgba(255,255,255,0.6)", ...typography.caption, textAlign: "right" },
  summaryColValue: { ...typography.title, textAlign: "right", marginTop: 2 },
  divider: { width: 1, backgroundColor: "rgba(255,255,255,0.15)", marginHorizontal: spacing.md },
  sectionTitle: { ...typography.h2, textAlign: "right", marginBottom: spacing.sm },
  sectionHeaderRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginTop: spacing.lg, marginBottom: spacing.sm },
  seeAll: { color: colors.accent, ...typography.body },
  rowDivider: { height: 1, backgroundColor: colors.border },
});
