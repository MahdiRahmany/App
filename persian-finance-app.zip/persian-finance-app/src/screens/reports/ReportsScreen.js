import React, { useMemo, useState } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import ChartDonut from "../../components/ChartDonut";
import { useApp } from "../../context/AppContext";
import { groupByCategory, getCategory, sumIncomeExpense } from "../../utils/mockData";
import { formatToman } from "../../utils/format";

export default function ReportsScreen() {
  const { transactions } = useApp();
  const [period, setPeriod] = useState("monthly");

  const grouped = useMemo(() => groupByCategory(transactions), [transactions]);
  const donutData = grouped.map((g) => ({ ...g, color: getCategory(g.categoryId).color }));
  const { income, expense } = useMemo(() => sumIncomeExpense(transactions), [transactions]);

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.pageTitle}>گزارش‌ها</Text>

      <View style={styles.segment}>
        {[
          { key: "daily", label: "روزانه" },
          { key: "monthly", label: "ماهانه" },
        ].map((opt) => (
          <TouchableOpacity
            key={opt.key}
            style={[styles.segmentItem, period === opt.key && styles.segmentItemActive]}
            onPress={() => setPeriod(opt.key)}
          >
            <Text style={[styles.segmentText, period === opt.key && styles.segmentTextActive]}>{opt.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Card style={{ alignItems: "center", marginTop: spacing.md }}>
        <ChartDonut data={donutData} />
        <View style={styles.legendWrap}>
          {donutData.map((d) => {
            const cat = getCategory(d.categoryId);
            return (
              <View key={d.categoryId} style={styles.legendRow}>
                <View style={[styles.dot, { backgroundColor: cat.color }]} />
                <Text style={styles.legendLabel}>{cat.name}</Text>
                <Text style={styles.legendValue}>{formatToman(d.total, { withSuffix: false })}</Text>
              </View>
            );
          })}
        </View>
      </Card>

      <Text style={styles.sectionTitle}>پرهزینه‌ترین‌ها</Text>
      <Card padded={false}>
        {donutData.slice(0, 5).map((d, i) => {
          const cat = getCategory(d.categoryId);
          return (
            <View key={d.categoryId} style={[styles.topRow, i > 0 && styles.topRowBorder]}>
              <Text style={styles.rank}>{i + 1}</Text>
              <Text style={styles.topIcon}>{cat.icon}</Text>
              <Text style={styles.topName}>{cat.name}</Text>
              <Text style={styles.topValue}>{formatToman(d.total, { withSuffix: false })}</Text>
            </View>
          );
        })}
      </Card>

      <Text style={styles.sectionTitle}>ویجت خلاصه سریع</Text>
      <View style={styles.widgetRow}>
        <Card style={styles.widgetCard}>
          <Text style={styles.widgetLabel}>درآمد کل</Text>
          <Text style={[styles.widgetValue, { color: colors.textSuccess }]}>{formatToman(income, { withSuffix: false })}</Text>
        </Card>
        <Card style={styles.widgetCard}>
          <Text style={styles.widgetLabel}>هزینه کل</Text>
          <Text style={[styles.widgetValue, { color: colors.textDanger }]}>{formatToman(expense, { withSuffix: false })}</Text>
        </Card>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md },
  pageTitle: { ...typography.h1, textAlign: "right", marginTop: spacing.md },
  segment: { flexDirection: "row-reverse", backgroundColor: colors.cardWhite, borderRadius: radius.pill, padding: 4, marginTop: spacing.md },
  segmentItem: { flex: 1, paddingVertical: 10, borderRadius: radius.pill, alignItems: "center" },
  segmentItemActive: { backgroundColor: colors.accent },
  segmentText: { ...typography.body },
  segmentTextActive: { color: colors.white, fontFamily: "Vazirmatn_700Bold" },
  legendWrap: { width: "100%", marginTop: spacing.md, gap: 8 },
  legendRow: { flexDirection: "row-reverse", alignItems: "center" },
  dot: { width: 10, height: 10, borderRadius: 5, marginStart: 8 },
  legendLabel: { ...typography.body, flex: 1, textAlign: "right" },
  legendValue: { ...typography.caption },
  sectionTitle: { ...typography.h2, textAlign: "right", marginTop: spacing.lg, marginBottom: spacing.sm },
  topRow: { flexDirection: "row-reverse", alignItems: "center", padding: spacing.md },
  topRowBorder: { borderTopWidth: 1, borderTopColor: colors.border },
  rank: { ...typography.caption, width: 20, textAlign: "center" },
  topIcon: { fontSize: 16, marginHorizontal: 8 },
  topName: { ...typography.body, flex: 1, textAlign: "right" },
  topValue: { ...typography.title, fontSize: 13 },
  widgetRow: { flexDirection: "row-reverse", gap: spacing.md },
  widgetCard: { flex: 1, alignItems: "center" },
  widgetLabel: { ...typography.caption },
  widgetValue: { ...typography.title, marginTop: 4 },
});
