import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import { useApp } from "../../context/AppContext";
import { categories } from "../../utils/mockData";

export default function AddBudgetScreen({ navigation }) {
  const { upsertBudget } = useApp();
  const [categoryId, setCategoryId] = useState(categories[0].id);
  const [limit, setLimit] = useState("");

  const handleSave = async () => {
    if (!limit) return;
    await upsertBudget({
      id: `b_${categoryId}_${Date.now()}`,
      categoryId,
      limit: Number(limit),
      spent: 0,
    });
    navigation.goBack();
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ بازگشت</Text>
        </TouchableOpacity>
        <Text style={styles.title}>بودجه جدید</Text>
      </View>

      <Text style={styles.label}>انتخاب دسته</Text>
      <View style={styles.catsWrap}>
        {categories
          .filter((c) => c.id !== "income")
          .map((c) => (
            <TouchableOpacity
              key={c.id}
              style={[styles.catChip, categoryId === c.id && styles.catChipActive]}
              onPress={() => setCategoryId(c.id)}
            >
              <Text style={{ fontSize: 16 }}>{c.icon}</Text>
              <Text style={[styles.catChipText, categoryId === c.id && styles.catChipTextActive]}>{c.name}</Text>
            </TouchableOpacity>
          ))}
      </View>

      <Text style={styles.label}>سقف بودجه ماهانه (تومان)</Text>
      <TextInput
        style={styles.input}
        keyboardType="number-pad"
        placeholder="مثلاً 2000000"
        value={limit}
        onChangeText={setLimit}
        textAlign="right"
      />

      <TouchableOpacity style={styles.primaryBtn} onPress={handleSave}>
        <Text style={styles.primaryBtnText}>ذخیره بودجه</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md, paddingTop: 56 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.lg },
  back: { color: colors.accent, ...typography.body },
  title: { ...typography.h2 },
  label: { ...typography.caption, textAlign: "right", marginBottom: spacing.sm },
  catsWrap: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, marginBottom: spacing.lg },
  catChip: { flexDirection: "row-reverse", alignItems: "center", gap: 6, paddingVertical: 8, paddingHorizontal: 12, borderRadius: radius.pill, backgroundColor: colors.cardWhite },
  catChipActive: { backgroundColor: colors.accent },
  catChipText: { ...typography.body },
  catChipTextActive: { color: colors.white },
  input: { backgroundColor: colors.cardWhite, borderRadius: radius.card, padding: spacing.md, ...typography.body, marginBottom: spacing.lg },
  primaryBtn: { backgroundColor: colors.accent, paddingVertical: 16, borderRadius: radius.pill, alignItems: "center" },
  primaryBtnText: { ...typography.title, color: colors.white },
});
