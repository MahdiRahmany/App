import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import ProgressBar from "../../components/ProgressBar";
import FloatingButton from "../../components/FloatingButton";
import { useApp } from "../../context/AppContext";
import { getCategory } from "../../utils/mockData";
import { formatToman } from "../../utils/format";

export default function BudgetScreen({ navigation }) {
  const { budgets } = useApp();

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView contentContainerStyle={{ padding: spacing.md, paddingBottom: 100 }}>
        <Text style={styles.pageTitle}>بودجه‌بندی</Text>
        <Text style={styles.pageSubtitle}>پیگیری مصرف بودجه هر دسته در ماه جاری</Text>

        {budgets.map((b) => {
          const cat = getCategory(b.categoryId);
          const pct = b.spent / b.limit;
          const isOver = pct > 1;
          return (
            <Card key={b.id} style={{ marginTop: spacing.md }}>
              <View style={styles.row}>
                <View style={[styles.iconWrap, { backgroundColor: cat.color + "22" }]}>
                  <Text style={{ fontSize: 18 }}>{cat.icon}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.catName}>{cat.name}</Text>
                  <Text style={[styles.statusText, isOver && { color: colors.textDanger }]}>
                    {isOver ? "بودجه رد شده!" : `${formatToman(b.limit - b.spent, { withSuffix: false })} باقی‌مانده`}
                  </Text>
                </View>
                <Text style={styles.amounts}>
                  {formatToman(b.spent, { withSuffix: false })} / {formatToman(b.limit, { withSuffix: false })}
                </Text>
              </View>
              <View style={{ marginTop: spacing.sm }}>
                <ProgressBar pct={pct} />
              </View>
            </Card>
          );
        })}
      </ScrollView>
      <FloatingButton onPress={() => navigation.navigate("AddBudget")} />
    </View>
  );
}

const styles = StyleSheet.create({
  pageTitle: { ...typography.h1, textAlign: "right", marginTop: spacing.md },
  pageSubtitle: { ...typography.body, textAlign: "right", color: colors.textSecondary, marginTop: 4 },
  row: { flexDirection: "row-reverse", alignItems: "center" },
  iconWrap: { width: 40, height: 40, borderRadius: radius.sm, alignItems: "center", justifyContent: "center", marginStart: spacing.sm },
  catName: { ...typography.title, textAlign: "right" },
  statusText: { ...typography.caption, textAlign: "right", marginTop: 2 },
  amounts: { ...typography.caption },
});
