import React, { useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Alert, Share } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import { exportAllData, importAllData } from "../../utils/storage";

export default function BackupScreen({ navigation }) {
  const [lastExport, setLastExport] = useState(null);

  const handleExport = async () => {
    const json = await exportAllData();
    setLastExport(json);
    try {
      // در حالت واقعی روی موبایل از expo-file-system + expo-sharing برای ذخیره فایل JSON استفاده کن
      await Share.share({ message: json, title: "پشتیبان اپ مالی من" });
    } catch (e) {
      Alert.alert("خروجی JSON آماده شد", "می‌تونی این متن رو در فایل ذخیره کنی.");
    }
  };

  const handleImport = async () => {
    if (!lastExport) {
      Alert.alert("فایلی برای بازیابی پیدا نشد", "ابتدا باید یک فایل پشتیبان انتخاب کنی (در نسخه واقعی: expo-document-picker).");
      return;
    }
    await importAllData(lastExport);
    Alert.alert("بازیابی موفق", "اطلاعات با موفقیت بازیابی شد.");
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ بازگشت</Text>
        </TouchableOpacity>
        <Text style={styles.title}>پشتیبان‌گیری آفلاین</Text>
      </View>

      <Card>
        <Text style={styles.cardTitle}>خروجی گرفتن از اطلاعات</Text>
        <Text style={styles.cardBody}>
          یک فایل JSON شامل تمام تراکنش‌ها، بودجه‌ها و دسته‌بندی‌ها می‌سازه که کاملاً محلی و بدون نیاز به اینترنت
          ذخیره می‌شه.
        </Text>
        <TouchableOpacity style={styles.primaryBtn} onPress={handleExport}>
          <Text style={styles.primaryBtnText}>گرفتن خروجی JSON</Text>
        </TouchableOpacity>
      </Card>

      <Card style={{ marginTop: spacing.md }}>
        <Text style={styles.cardTitle}>بازیابی از فایل پشتیبان</Text>
        <Text style={styles.cardBody}>فایل JSON قبلی رو انتخاب کن تا اطلاعات به همون حالت برگرده.</Text>
        <TouchableOpacity style={styles.secondaryBtn} onPress={handleImport}>
          <Text style={styles.secondaryBtnText}>انتخاب فایل و بازیابی</Text>
        </TouchableOpacity>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md, paddingTop: 56 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  back: { color: colors.accent, ...typography.body },
  title: { ...typography.h2 },
  cardTitle: { ...typography.title, textAlign: "right", marginBottom: spacing.sm },
  cardBody: { ...typography.body, textAlign: "right", color: colors.textSecondary, lineHeight: 20, marginBottom: spacing.md },
  primaryBtn: { backgroundColor: colors.accent, paddingVertical: 14, borderRadius: radius.pill, alignItems: "center" },
  primaryBtnText: { color: colors.white, ...typography.title, fontSize: 14 },
  secondaryBtn: { backgroundColor: colors.background, paddingVertical: 14, borderRadius: radius.pill, alignItems: "center", borderWidth: 1, borderColor: colors.border },
  secondaryBtnText: { color: colors.primary, ...typography.title, fontSize: 14 },
});
