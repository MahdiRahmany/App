import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";

const ITEMS = [
  { key: "Categories", icon: "🏷️", label: "مدیریت دسته‌بندی‌ها" },
  { key: "Backup", icon: "☁️", label: "پشتیبان‌گیری و بازیابی" },
];

export default function SettingsScreen({ navigation }) {
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.pageTitle}>تنظیمات</Text>

      <Card padded={false} style={{ marginTop: spacing.md }}>
        {ITEMS.map((item, i) => (
          <TouchableOpacity
            key={item.key}
            style={[styles.row, i > 0 && styles.rowBorder]}
            onPress={() => navigation.navigate(item.key)}
          >
            <Text style={styles.chevron}>‹</Text>
            <Text style={styles.label}>{item.label}</Text>
            <Text style={styles.icon}>{item.icon}</Text>
          </TouchableOpacity>
        ))}
      </Card>

      <Text style={styles.version}>نسخه ۱.۰.۰</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md },
  pageTitle: { ...typography.h1, textAlign: "right", marginTop: spacing.md },
  row: { flexDirection: "row-reverse", alignItems: "center", padding: spacing.md },
  rowBorder: { borderTopWidth: 1, borderTopColor: colors.border },
  icon: { fontSize: 18, marginStart: spacing.sm },
  label: { ...typography.body, flex: 1, textAlign: "right" },
  chevron: { ...typography.body, color: colors.textSecondary, transform: [{ scaleX: -1 }] },
  version: { ...typography.caption, textAlign: "center", marginTop: spacing.xl },
});
