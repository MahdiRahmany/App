import React, { useState } from "react";
import { View, Text, TextInput, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import { useApp } from "../../context/AppContext";

const EMOJIS = ["🍔", "🚕", "🧾", "🎬", "🛍️", "💊", "🏠", "📚", "✈️", "🐾"];

export default function CategoriesScreen({ navigation }) {
  const { userCategories, upsertCategory } = useApp();
  const [name, setName] = useState("");
  const [emoji, setEmoji] = useState(EMOJIS[0]);

  const handleAdd = async () => {
    if (!name.trim()) return;
    await upsertCategory({ id: `cat_${Date.now()}`, name: name.trim(), icon: emoji, color: "#8A8A99" });
    setName("");
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ بازگشت</Text>
        </TouchableOpacity>
        <Text style={styles.title}>مدیریت دسته‌بندی</Text>
      </View>

      <ScrollView>
        <Card>
          <Text style={styles.label}>افزودن دسته جدید</Text>
          <View style={styles.emojiRow}>
            {EMOJIS.map((e) => (
              <TouchableOpacity key={e} style={[styles.emojiChip, emoji === e && styles.emojiChipActive]} onPress={() => setEmoji(e)}>
                <Text style={{ fontSize: 16 }}>{e}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput
            style={styles.input}
            placeholder="نام دسته را وارد کن..."
            value={name}
            onChangeText={setName}
            textAlign="right"
          />
          <TouchableOpacity style={styles.addBtn} onPress={handleAdd}>
            <Text style={styles.addBtnText}>افزودن دسته</Text>
          </TouchableOpacity>
        </Card>

        <Text style={styles.sectionTitle}>دسته‌های فعلی</Text>
        <Card padded={false}>
          {userCategories.map((c, i) => (
            <View key={c.id} style={[styles.catRow, i > 0 && styles.catRowBorder]}>
              <Text style={{ fontSize: 16 }}>{c.icon}</Text>
              <Text style={styles.catName}>{c.name}</Text>
            </View>
          ))}
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md, paddingTop: 56 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  back: { color: colors.accent, ...typography.body },
  title: { ...typography.h2 },
  label: { ...typography.caption, textAlign: "right", marginBottom: spacing.sm },
  emojiRow: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, marginBottom: spacing.md },
  emojiChip: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" },
  emojiChipActive: { backgroundColor: colors.accent + "33" },
  input: { backgroundColor: colors.background, borderRadius: radius.card, padding: spacing.md, ...typography.body, marginBottom: spacing.md },
  addBtn: { backgroundColor: colors.accent, paddingVertical: 12, borderRadius: radius.pill, alignItems: "center" },
  addBtnText: { color: colors.white, ...typography.title, fontSize: 14 },
  sectionTitle: { ...typography.h2, textAlign: "right", marginTop: spacing.lg, marginBottom: spacing.sm },
  catRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, padding: spacing.md },
  catRowBorder: { borderTopWidth: 1, borderTopColor: colors.border },
  catName: { ...typography.body },
});
