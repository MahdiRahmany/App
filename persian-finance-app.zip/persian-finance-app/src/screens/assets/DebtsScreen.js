import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import { mockPeople } from "../../utils/mockData";
import { formatToman } from "../../utils/format";

export default function DebtsScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ بازگشت</Text>
        </TouchableOpacity>
        <Text style={styles.title}>طلب و بدهی</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {mockPeople.map((p) => {
          const isOwedToMe = p.direction === "owedToMe";
          return (
            <Card key={p.id} style={{ marginTop: spacing.md }}>
              <View style={styles.row}>
                <View style={[styles.avatar, { backgroundColor: p.avatarColor }]}>
                  <Text style={styles.avatarText}>{p.name[0]}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{p.name}</Text>
                  <Text style={[styles.balance, { color: isOwedToMe ? colors.textSuccess : colors.textDanger }]}>
                    {isOwedToMe ? "از او طلب داری" : "به او بدهکاری"} · {formatToman(Math.abs(p.balance), { withSuffix: false })}
                  </Text>
                </View>
                <TouchableOpacity style={[styles.actionBtn, { backgroundColor: isOwedToMe ? colors.textSuccess : colors.accent }]}>
                  <Text style={styles.actionText}>{isOwedToMe ? "دریافت" : "پرداخت"}</Text>
                </TouchableOpacity>
              </View>
            </Card>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md, paddingTop: 56 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  back: { color: colors.accent, ...typography.body },
  title: { ...typography.h2 },
  row: { flexDirection: "row-reverse", alignItems: "center" },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center", marginStart: spacing.sm },
  avatarText: { color: colors.white, ...typography.title },
  name: { ...typography.title, textAlign: "right", fontSize: 14 },
  balance: { ...typography.caption, textAlign: "right", marginTop: 2 },
  actionBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: radius.pill },
  actionText: { color: colors.white, ...typography.caption, fontFamily: "Vazirmatn_500Medium" },
});
