import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import { mockDueDates } from "../../utils/mockData";
import { formatToman, formatJalaliDate, toFaDigits } from "../../utils/format";

function daysUntil(date) {
  const diff = Math.ceil((date - new Date()) / (1000 * 60 * 60 * 24));
  return diff;
}

const TYPE_ICON = { check: "📄", insurance: "🛡️" };

export default function DueDatesScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ بازگشت</Text>
        </TouchableOpacity>
        <Text style={styles.title}>سررسید و چک</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {mockDueDates.map((d) => {
          const days = daysUntil(d.dueDate);
          const isSoon = days <= 5;
          return (
            <Card key={d.id} style={{ marginTop: spacing.md }}>
              <View style={styles.row}>
                <Text style={styles.icon}>{TYPE_ICON[d.type]}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.title2}>{d.title}</Text>
                  <Text style={styles.date}>{formatJalaliDate(d.dueDate)}</Text>
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={styles.amount}>{formatToman(d.amount, { withSuffix: false })}</Text>
                  <View style={[styles.countdown, { backgroundColor: isSoon ? colors.textDanger + "22" : colors.border }]}>
                    <Text style={[styles.countdownText, { color: isSoon ? colors.textDanger : colors.textSecondary }]}>
                      {days >= 0 ? `${toFaDigits(days)} روز مانده` : "سررسید گذشته"}
                    </Text>
                  </View>
                </View>
              </View>
            </Card>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md, paddingTop: 56 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  back: { color: colors.accent, ...typography.body },
  title: { ...typography.h2 },
  row: { flexDirection: "row-reverse", alignItems: "center" },
  icon: { fontSize: 22, marginStart: spacing.sm },
  title2: { ...typography.title, textAlign: "right", fontSize: 14 },
  date: { ...typography.caption, textAlign: "right", marginTop: 2 },
  amount: { ...typography.title, fontSize: 13 },
  countdown: { marginTop: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill },
  countdownText: { ...typography.caption, fontSize: 11 },
});
