import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import ChartLine from "../../components/ChartLine";
import { mockAssets, assetHistory } from "../../utils/mockData";
import { formatToman, toFaDigits } from "../../utils/format";

export default function AssetsScreen({ navigation }) {
  const totalValue = mockAssets.reduce((s, a) => s + a.valueToman, 0);

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.pageTitle}>دارایی‌ها</Text>

      <Card style={styles.heroCard} padded={false}>
        <View style={{ padding: spacing.lg }}>
          <Text style={styles.heroLabel}>ارزش کل پرتفوی</Text>
          <Text style={typography.amountLg}>{formatToman(totalValue)}</Text>
          <View style={{ marginTop: spacing.md }}>
            <ChartLine data={assetHistory} width={300} height={110} />
          </View>
        </View>
      </Card>

      <View style={styles.linksRow}>
        <TouchableOpacity style={styles.linkCard} onPress={() => navigation.navigate("Loans")}>
          <Text style={styles.linkIcon}>🏦</Text>
          <Text style={styles.linkText}>قسط و وام</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.linkCard} onPress={() => navigation.navigate("Debts")}>
          <Text style={styles.linkIcon}>🤝</Text>
          <Text style={styles.linkText}>طلب و بدهی</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.linkCard} onPress={() => navigation.navigate("DueDates")}>
          <Text style={styles.linkIcon}>📅</Text>
          <Text style={styles.linkText}>سررسید و چک</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>دارایی‌های غیرنقدی</Text>
      {mockAssets.map((a) => (
        <Card key={a.id} style={{ marginTop: spacing.sm }}>
          <View style={styles.assetRow}>
            <View style={styles.assetIconWrap}>
              <Text style={{ fontSize: 18 }}>{a.type === "gold" ? "🥇" : "🪙"}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.assetName}>{a.name}</Text>
              <Text style={styles.assetAmount}>{a.amount}</Text>
            </View>
            <View style={{ alignItems: "flex-end" }}>
              <Text style={styles.assetValue}>{formatToman(a.valueToman, { withSuffix: false })}</Text>
              <Text style={[styles.assetChange, { color: a.changePct >= 0 ? colors.textSuccess : colors.textDanger }]}>
                {a.changePct >= 0 ? "+" : ""}
                {toFaDigits(a.changePct)}٪
              </Text>
            </View>
          </View>
        </Card>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md },
  pageTitle: { ...typography.h1, textAlign: "right", marginTop: spacing.md },
  heroCard: { marginTop: spacing.md, backgroundColor: colors.primaryDark, alignItems: "center", overflow: "hidden" },
  heroLabel: { color: "rgba(255,255,255,0.7)", ...typography.caption, textAlign: "right" },
  linksRow: { flexDirection: "row-reverse", gap: spacing.sm, marginTop: spacing.md },
  linkCard: { flex: 1, backgroundColor: colors.cardWhite, borderRadius: radius.card, alignItems: "center", paddingVertical: spacing.md },
  linkIcon: { fontSize: 22, marginBottom: 6 },
  linkText: { ...typography.caption, fontFamily: "Vazirmatn_500Medium" },
  sectionTitle: { ...typography.h2, textAlign: "right", marginTop: spacing.lg, marginBottom: spacing.sm },
  assetRow: { flexDirection: "row-reverse", alignItems: "center" },
  assetIconWrap: { width: 40, height: 40, borderRadius: radius.sm, backgroundColor: colors.background, alignItems: "center", justifyContent: "center", marginStart: spacing.sm },
  assetName: { ...typography.title, textAlign: "right", fontSize: 14 },
  assetAmount: { ...typography.caption, textAlign: "right", marginTop: 2 },
  assetValue: { ...typography.title, fontSize: 13 },
  assetChange: { ...typography.caption, marginTop: 2 },
});
