import React, { useState } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { colors, typography, spacing, radius } from "../../theme/theme";
import Card from "../../components/Card";
import { mockLoans } from "../../utils/mockData";
import { formatToman, formatJalaliDate } from "../../utils/format";

const STATUS_LABEL = { late: "عقب‌افتاده", upcoming: "نزدیک سررسید", ok: "به‌روز" };
const STATUS_COLOR = { late: colors.textDanger, upcoming: colors.accent, ok: colors.textSuccess };

export default function LoansScreen({ navigation }) {
  const [direction, setDirection] = useState("payable");
  const list = mockLoans.filter((l) => l.direction === direction);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>‹ بازگشت</Text>
        </TouchableOpacity>
        <Text style={styles.title}>قسط و وام</Text>
      </View>

      <View style={styles.segment}>
        {[
          { key: "payable", label: "پرداختی" },
          { key: "receivable", label: "دریافتی" },
        ].map((opt) => (
          <TouchableOpacity
            key={opt.key}
            style={[styles.segmentItem, direction === opt.key && styles.segmentItemActive]}
            onPress={() => setDirection(opt.key)}
          >
            <Text style={[styles.segmentText, direction === opt.key && styles.segmentTextActive]}>{opt.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {list.map((l) => (
          <Card key={l.id} style={{ marginTop: spacing.md }}>
            <View style={styles.rowTop}>
              <Text style={styles.loanTitle}>{l.title}</Text>
              <View style={[styles.statusBadge, { backgroundColor: STATUS_COLOR[l.status] + "22" }]}>
                <Text style={[styles.statusText, { color: STATUS_COLOR[l.status] }]}>{STATUS_LABEL[l.status]}</Text>
              </View>
            </View>
            <View style={styles.rowBottom}>
              <View>
                <Text style={styles.label}>مانده کل</Text>
                <Text style={styles.value}>{formatToman(l.remaining, { withSuffix: false })}</Text>
              </View>
              <View>
                <Text style={styles.label}>قسط بعدی</Text>
                <Text style={styles.value}>{formatToman(l.nextInstallment, { withSuffix: false })}</Text>
              </View>
              <View>
                <Text style={styles.label}>سررسید</Text>
                <Text style={styles.value}>{formatJalaliDate(l.dueDate)}</Text>
              </View>
            </View>
          </Card>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md, paddingTop: 56 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  back: { color: colors.accent, ...typography.body },
  title: { ...typography.h2 },
  segment: { flexDirection: "row-reverse", backgroundColor: colors.cardWhite, borderRadius: radius.pill, padding: 4 },
  segmentItem: { flex: 1, paddingVertical: 10, borderRadius: radius.pill, alignItems: "center" },
  segmentItemActive: { backgroundColor: colors.primary },
  segmentText: { ...typography.body },
  segmentTextActive: { color: colors.white },
  rowTop: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  loanTitle: { ...typography.title, textAlign: "right" },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill },
  statusText: { ...typography.caption, fontFamily: "Vazirmatn_500Medium" },
  rowBottom: { flexDirection: "row-reverse", justifyContent: "space-between", marginTop: spacing.md },
  label: { ...typography.caption, textAlign: "right" },
  value: { ...typography.title, fontSize: 13, textAlign: "right", marginTop: 4 },
});
