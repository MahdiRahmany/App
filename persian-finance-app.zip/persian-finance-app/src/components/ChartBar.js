import React from "react";
import { View, StyleSheet } from "react-native";
import Svg, { Rect } from "react-native-svg";
import { colors } from "../theme/theme";

// data: [{ label, total }]  -> نمودار میله‌ای روند روزانه هزینه
export default function ChartBar({ data, height = 140, barColor = colors.accent }) {
  const max = Math.max(...data.map((d) => d.total), 1);
  const width = Math.max(data.length * 22, 280);
  const barWidth = (width / data.length) * 0.5;
  const gap = (width / data.length) * 0.5;

  return (
    <View style={styles.wrap}>
      <Svg width={width} height={height}>
        {data.map((d, i) => {
          const barHeight = (d.total / max) * (height - 10);
          const x = i * (barWidth + gap) + gap / 2;
          const y = height - barHeight;
          return (
            <Rect
              key={i}
              x={x}
              y={y}
              width={barWidth}
              height={Math.max(barHeight, 2)}
              rx={4}
              fill={barColor}
              opacity={d.total === 0 ? 0.15 : 1}
            />
          );
        })}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: "center" },
});
