import React from "react";
import { View } from "react-native";
import Svg, { Polyline, Circle, Defs, LinearGradient, Stop, Polygon } from "react-native-svg";
import { colors } from "../theme/theme";

// data: [{ valueMillion }]
export default function ChartLine({ data, width = 300, height = 120, color = colors.accent }) {
  const values = data.map((d) => d.valueMillion);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;
  const stepX = width / (values.length - 1);

  const points = values
    .map((v, i) => {
      const x = i * stepX;
      const y = height - ((v - min) / range) * (height - 10) - 5;
      return `${x},${y}`;
    })
    .join(" ");

  const fillPoints = `0,${height} ${points} ${width},${height}`;

  return (
    <View>
      <Svg width={width} height={height}>
        <Defs>
          <LinearGradient id="fillGrad" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor={color} stopOpacity="0.25" />
            <Stop offset="1" stopColor={color} stopOpacity="0" />
          </LinearGradient>
        </Defs>
        <Polygon points={fillPoints} fill="url(#fillGrad)" />
        <Polyline points={points} fill="none" stroke={color} strokeWidth={3} strokeLinejoin="round" strokeLinecap="round" />
        {values.map((v, i) => {
          const x = i * stepX;
          const y = height - ((v - min) / range) * (height - 10) - 5;
          return i === values.length - 1 ? (
            <Circle key={i} cx={x} cy={y} r={5} fill={color} />
          ) : null;
        })}
      </Svg>
    </View>
  );
}
