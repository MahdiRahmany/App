import React from "react";
import { View, StyleSheet } from "react-native";
import Svg, { Circle, G } from "react-native-svg";
import { colors, typography } from "../theme/theme";
import { Text } from "react-native";
import { formatCompactToman } from "../utils/format";

// data: [{ categoryId, total, color }]
export default function ChartDonut({ data, size = 180, strokeWidth = 22, centerLabel }) {
  const total = data.reduce((s, d) => s + d.total, 0) || 1;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  let cumulative = 0;

  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size}>
        <G rotation={-90} originX={size / 2} originY={size / 2}>
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={colors.border}
            strokeWidth={strokeWidth}
            fill="none"
          />
          {data.map((d, i) => {
            const fraction = d.total / total;
            const dashLength = fraction * circumference;
            const dashOffset = circumference - (cumulative / total) * circumference;
            cumulative += d.total;
            return (
              <Circle
                key={i}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                stroke={d.color}
                strokeWidth={strokeWidth}
                strokeDasharray={`${dashLength} ${circumference - dashLength}`}
                strokeDashoffset={dashOffset}
                strokeLinecap="butt"
                fill="none"
              />
            );
          })}
        </G>
      </Svg>
      <View style={[StyleSheet.absoluteFillObject, styles.centerWrap]}>
        <Text style={styles.centerCaption}>مجموع هزینه</Text>
        <Text style={styles.centerValue}>{centerLabel || formatCompactToman(total)}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  centerWrap: { alignItems: "center", justifyContent: "center" },
  centerCaption: { ...typography.caption },
  centerValue: { ...typography.title, marginTop: 2 },
});
