import React from "react";
import { TouchableOpacity, Text, StyleSheet } from "react-native";
import { colors, radius } from "../theme/theme";

export default function FloatingButton({ onPress, icon = "+" }) {
  return (
    <TouchableOpacity style={styles.fab} onPress={onPress} activeOpacity={0.85}>
      <Text style={styles.icon}>{icon}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  fab: {
    position: "absolute",
    bottom: 24,
    left: 24, // در RTL دکمه شناور سمت چپ-پایین معمول‌تره ولی قابل تغییره
    width: 56,
    height: 56,
    borderRadius: radius.pill,
    backgroundColor: colors.accent,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: colors.accent,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 6,
  },
  icon: { color: colors.white, fontSize: 28, marginTop: -2 },
});
