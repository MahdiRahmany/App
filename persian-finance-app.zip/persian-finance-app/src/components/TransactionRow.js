import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { colors, typography, spacing, radius } from "../theme/theme";
import { formatToman, formatJalaliDate } from "../utils/format";
import { getCategory } from "../utils/mockData";

export default function TransactionRow({ transaction }) {
  const category = getCategory(transaction.categoryId);
  const isIncome = transaction.amount > 0;

  return (
    <View style={styles.row}>
      <View style={[styles.iconWrap, { backgroundColor: category.color + "22" }]}>
        <Text style={styles.icon}>{category.icon}</Text>
      </View>

      <View style={styles.middle}>
        <Text style={styles.title} numberOfLines={1}>
          {transaction.title}
        </Text>
        <Text style={styles.subtitle}>
          {category.name} · {formatJalaliDate(transaction.date)}
          {transaction.source === "sms" ? " · پیامک بانکی" : " · ثبت دستی"}
        </Text>
      </View>

      <Text style={[styles.amount, { color: isIncome ? colors.textSuccess : colors.textDanger }]}>
        {isIncome ? "+" : ""}
        {formatToman(transaction.amount, { withSuffix: false })}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row-reverse",
    alignItems: "center",
    paddingVertical: spacing.sm,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
    marginStart: spacing.sm,
  },
  icon: { fontSize: 18 },
  middle: { flex: 1, marginEnd: spacing.sm },
  title: { ...typography.title, fontSize: 14, textAlign: "right" },
  subtitle: { ...typography.caption, textAlign: "right", marginTop: 2 },
  amount: { ...typography.title, fontSize: 14, textAlign: "left" },
});
