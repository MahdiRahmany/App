import React from "react";
import { View, StyleSheet } from "react-native";
import { colors, radius, spacing, shadowStyle } from "../theme/theme";

export default function Card({ children, style, padded = true }) {
  return <View style={[styles.card, padded && styles.padding, style]}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.cardWhite,
    borderRadius: radius.card,
    ...shadowStyle,
  },
  padding: {
    padding: spacing.md,
  },
});
