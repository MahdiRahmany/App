import React from "react";
import { View, StyleSheet } from "react-native";
import { colors, radius } from "../theme/theme";

// pct: 0..1+  (اگر از ۱ بیشتر بشه یعنی بودجه رد شده -> رنگ قرمز)
export default function ProgressBar({ pct, height = 8 }) {
  const clamped = Math.min(pct, 1);
  const isOver = pct > 1;
  return (
    <View style={[styles.track, { height, borderRadius: height / 2 }]}>
      <View
        style={[
          styles.fill,
          {
            width: `${clamped * 100}%`,
            height,
            borderRadius: height / 2,
            backgroundColor: isOver ? colors.textDanger : colors.accent,
          },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    width: "100%",
    backgroundColor: colors.border,
    overflow: "hidden",
  },
  fill: {},
});
