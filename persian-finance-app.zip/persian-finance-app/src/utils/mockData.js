// mockData.js — داده‌های نمونه فارسی برای زنده کردن تمام صفحات (بدون بک‌اند واقعی)

export const categories = [
  { id: "food", name: "خوراک", icon: "🍔", color: "#FF6B47" },
  { id: "transport", name: "حمل‌ونقل", icon: "🚕", color: "#3D5AFE" },
  { id: "bills", name: "قبض", icon: "🧾", color: "#8E24AA" },
  { id: "fun", name: "تفریح", icon: "🎬", color: "#00897B" },
  { id: "shopping", name: "خرید", icon: "🛍️", color: "#EF6C00" },
  { id: "health", name: "درمان", icon: "💊", color: "#D81B60" },
  { id: "home", name: "خانه", icon: "🏠", color: "#546E7A" },
  { id: "income", name: "درآمد", icon: "💰", color: "#2E7D32" },
];

const merchantByCategory = {
  food: ["دیجی‌کالا فود", "اسنپ فود - رستوران گیله‌مرد", "سوپرمارکت رفاه", "کافه لمیز", "نانوایی سنگک محله"],
  transport: ["اسنپ", "تپسی", "پمپ بنزین شهید بهشتی", "مترو تهران - شارژ کارت بلیت"],
  bills: ["پرداخت قبض برق", "قبض آب شهری", "شارژ ایرانسل", "اینترنت مخابرات"],
  fun: ["سینما پردیس کوروش", "فیلیمو - اشتراک ماهانه", "شهربازی ارم"],
  shopping: ["دیجی‌کالا", "ترب - پوشاک", "فروشگاه زنجیره‌ای افق کوروش"],
  health: ["داروخانه دکتر شریعتی", "کلینیک دندانپزشکی مهر"],
  home: ["فروشگاه لوازم خانگی الکترواستور", "اجاره ماهانه منزل"],
  income: ["واریز حقوق شرکت", "پورسانت فریلنسری", "واریز از علی محمدی"],
};

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function daysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}

export function generateTransactions(count = 40) {
  const list = [];
  for (let i = 0; i < count; i++) {
    const isIncome = Math.random() < 0.12;
    const categoryId = isIncome ? "income" : pick(categories.filter((c) => c.id !== "income").map((c) => c.id));
    const amount = isIncome
      ? Math.round((Math.random() * 8_000_000 + 2_000_000) / 1000) * 1000
      : Math.round((Math.random() * 900_000 + 15_000) / 1000) * 1000;
    list.push({
      id: `tx_${i}`,
      title: pick(merchantByCategory[categoryId]),
      categoryId,
      amount: isIncome ? amount : -amount,
      date: daysAgo(Math.floor(Math.random() * 30)),
      source: Math.random() < 0.7 ? "sms" : "manual",
    });
  }
  return list.sort((a, b) => b.date - a.date);
}

export const mockTransactions = generateTransactions(45);

export const mockBudgets = [
  { id: "b1", categoryId: "food", limit: 4_000_000, spent: 3_150_000 },
  { id: "b2", categoryId: "transport", limit: 1_200_000, spent: 980_000 },
  { id: "b3", categoryId: "fun", limit: 800_000, spent: 820_000 },
  { id: "b4", categoryId: "shopping", limit: 2_500_000, spent: 1_100_000 },
  { id: "b5", categoryId: "bills", limit: 1_500_000, spent: 640_000 },
];

export const mockAssets = [
  { id: "a1", name: "طلای آب‌شده", type: "gold", amount: "۱۸.۵ گرم", valueToman: 42_500_000, changePct: 2.1 },
  { id: "a2", name: "تتر (USDT)", type: "crypto", amount: "۳۵۰", valueToman: 24_800_000, changePct: -0.4 },
  { id: "a3", name: "بیت‌کوین", type: "crypto", amount: "۰.۰۱۲", valueToman: 18_200_000, changePct: 3.6 },
  { id: "a4", name: "سکه بهار آزادی", type: "gold", amount: "۲ عدد", valueToman: 76_000_000, changePct: 1.2 },
];

export const assetHistory = [38, 41, 40, 44, 47, 46, 49, 52, 55, 58, 60, 61.5].map((v, i) => ({
  month: i,
  valueMillion: v,
}));

export const mockLoans = [
  { id: "l1", direction: "payable", title: "وام بانک ملت", remaining: 32_000_000, nextInstallment: 2_100_000, dueDate: daysAgo(-5), status: "upcoming" },
  { id: "l2", direction: "payable", title: "قسط خودرو", remaining: 58_000_000, nextInstallment: 4_800_000, dueDate: daysAgo(-2), status: "late" },
  { id: "l3", direction: "receivable", title: "وام قرض‌الحسنه به برادر", remaining: 15_000_000, nextInstallment: 1_500_000, dueDate: daysAgo(-12), status: "ok" },
];

export const mockPeople = [
  { id: "p1", name: "علی محمدی", avatarColor: "#3D5AFE", balance: 1_250_000, direction: "owedToMe" },
  { id: "p2", name: "سارا احمدی", avatarColor: "#D81B60", balance: -800_000, direction: "iOwe" },
  { id: "p3", name: "محمد رضایی", avatarColor: "#00897B", balance: 3_400_000, direction: "owedToMe" },
  { id: "p4", name: "رضا کریمی", avatarColor: "#EF6C00", balance: -450_000, direction: "iOwe" },
];

export const mockDueDates = [
  { id: "d1", title: "چک شماره ۱۲۴۵۶۷", amount: 12_000_000, dueDate: daysAgo(-3), type: "check" },
  { id: "d2", title: "سررسید بیمه شخص ثالث", amount: 3_800_000, dueDate: daysAgo(-9), type: "insurance" },
  { id: "d3", title: "چک شماره ۹۹۸۸۷", amount: 6_500_000, dueDate: daysAgo(-20), type: "check" },
];

export function getCategory(id) {
  return categories.find((c) => c.id === id) || categories[0];
}

export function sumIncomeExpense(transactions) {
  let income = 0;
  let expense = 0;
  transactions.forEach((t) => {
    if (t.amount > 0) income += t.amount;
    else expense += Math.abs(t.amount);
  });
  return { income, expense, net: income - expense };
}

export function groupByCategory(transactions) {
  const map = {};
  transactions
    .filter((t) => t.amount < 0)
    .forEach((t) => {
      map[t.categoryId] = (map[t.categoryId] || 0) + Math.abs(t.amount);
    });
  return Object.entries(map)
    .map(([categoryId, total]) => ({ categoryId, total }))
    .sort((a, b) => b.total - a.total);
}

export function dailyTotals(transactions, days = 14) {
  const buckets = new Array(days).fill(0).map((_, i) => ({ dayIndex: days - 1 - i, total: 0 }));
  const today = new Date();
  transactions.forEach((t) => {
    const diff = Math.floor((today - t.date) / (1000 * 60 * 60 * 24));
    if (diff >= 0 && diff < days && t.amount < 0) {
      buckets[days - 1 - diff].total += Math.abs(t.amount);
    }
  });
  return buckets;
}
