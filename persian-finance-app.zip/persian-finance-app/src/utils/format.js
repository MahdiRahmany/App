// format.js — تبدیل اعداد به فارسی + جداکننده هزارگان تومان

const enToFaDigitsMap = { 0: "۰", 1: "۱", 2: "۲", 3: "۳", 4: "۴", 5: "۵", 6: "۶", 7: "۷", 8: "۸", 9: "۹" };

export function toFaDigits(input) {
  return String(input).replace(/[0-9]/g, (d) => enToFaDigitsMap[d]);
}

export function formatToman(amount, { withSuffix = true } = {}) {
  const isNegative = amount < 0;
  const abs = Math.abs(Math.round(amount));
  const withCommas = abs.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const fa = toFaDigits(withCommas);
  const sign = isNegative ? "-" : "";
  return `${sign}${fa}${withSuffix ? " تومان" : ""}`;
}

export function formatCompactToman(amount) {
  const abs = Math.abs(amount);
  if (abs >= 1_000_000_000) return `${toFaDigits((amount / 1_000_000_000).toFixed(1))} میلیارد`;
  if (abs >= 1_000_000) return `${toFaDigits((amount / 1_000_000).toFixed(1))} میلیون`;
  if (abs >= 1_000) return `${toFaDigits((amount / 1_000).toFixed(0))} هزار`;
  return toFaDigits(amount);
}

const faMonths = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

const faWeekdaysShort = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

// یک تبدیل ساده و تقریبی میلادی->شمسی صرفاً برای نمایش mock (بدون وابستگی خارجی)
export function toJalaliApprox(date) {
  const gy = date.getFullYear();
  const gm = date.getMonth() + 1;
  const gd = date.getDate();
  let jy;
  const gy2 = gm > 2 ? gy + 1 : gy;
  const days =
    355666 +
    365 * gy +
    Math.floor((gy2 + 3) / 4) -
    Math.floor((gy2 + 99) / 100) +
    Math.floor((gy2 + 399) / 400) +
    gd +
    [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334][gm - 1];
  jy = -1595 + 33 * Math.floor(days / 12053);
  let rem = days % 12053;
  jy += 4 * Math.floor(rem / 1461);
  rem %= 1461;
  if (rem > 365) {
    jy += Math.floor((rem - 1) / 365);
    rem = (rem - 1) % 365;
  }
  let jm, jd;
  if (rem < 186) {
    jm = 1 + Math.floor(rem / 31);
    jd = 1 + (rem % 31);
  } else {
    jm = 7 + Math.floor((rem - 186) / 30);
    jd = 1 + ((rem - 186) % 30);
  }
  return { jy, jm, jd };
}

export function formatJalaliDate(date, { withWeekday = false } = {}) {
  const { jy, jm, jd } = toJalaliApprox(date);
  const weekday = withWeekday ? `${faWeekdaysShort[date.getDay()]} ` : "";
  return `${weekday}${toFaDigits(jd)} ${faMonths[jm - 1]}`;
}

export function formatJalaliDateFull(date) {
  const { jy, jm, jd } = toJalaliApprox(date);
  return `${toFaDigits(jd)} ${faMonths[jm - 1]} ${toFaDigits(jy)}`;
}
