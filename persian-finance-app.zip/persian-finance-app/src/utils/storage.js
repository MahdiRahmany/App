// storage.js — لایه ساده روی AsyncStorage برای ذخیره‌سازی آفلاین

import AsyncStorage from "@react-native-async-storage/async-storage";

const KEYS = {
  ONBOARDING_DONE: "@finance/onboarding_done",
  PIN: "@finance/pin",
  BIOMETRIC_ENABLED: "@finance/biometric_enabled",
  REMINDER: "@finance/reminder",
  TRANSACTIONS: "@finance/transactions",
  BUDGETS: "@finance/budgets",
  CATEGORIES: "@finance/categories",
};

export async function getItem(key, fallback = null) {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    console.warn("storage.getItem failed", key, e);
    return fallback;
  }
}

export async function setItem(key, value) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.warn("storage.setItem failed", key, e);
    return false;
  }
}

export async function exportAllData() {
  const entries = await Promise.all(
    Object.values(KEYS).map(async (k) => [k, await AsyncStorage.getItem(k)])
  );
  const payload = Object.fromEntries(entries.filter(([, v]) => v !== null));
  return JSON.stringify(payload, null, 2);
}

export async function importAllData(jsonString) {
  const payload = JSON.parse(jsonString);
  await Promise.all(
    Object.entries(payload).map(([k, v]) => AsyncStorage.setItem(k, v))
  );
  return true;
}

export default KEYS;
